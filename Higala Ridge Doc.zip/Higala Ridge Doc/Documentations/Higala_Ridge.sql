==================================================
DATABASE CREATION
==================================================

CREATE DATABASE pos_system;
USE pos_system;


==================================================
CATEGORIES TABLE
==================================================

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL UNIQUE
);


==================================================
PRODUCTS TABLE
==================================================

CREATE TABLE products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock_quantity INT NOT NULL DEFAULT 0,
    description VARCHAR(255) DEFAULT NULL,
    is_available TINYINT(1) NOT NULL DEFAULT 1,
    image_path VARCHAR(500) DEFAULT NULL,

    CONSTRAINT fk_products_categories
        FOREIGN KEY (category_id)
        REFERENCES categories(category_id)
);


==================================================
STAFF TABLE
==================================================

CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    cashier_name VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    position VARCHAR(30) NOT NULL DEFAULT 'Cashier',
    contact VARCHAR(30) DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    active TINYINT(1) NOT NULL DEFAULT 1
);


==================================================
CUSTOMER ORDERS TABLE
==================================================

CREATE TABLE customer_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(30) DEFAULT NULL UNIQUE,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) DEFAULT NULL,
    order_status VARCHAR(30) DEFAULT 'Pending',
    order_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    customer_name VARCHAR(100) DEFAULT NULL,
    payment_reference VARCHAR(100) DEFAULT NULL,
    payment_status VARCHAR(30) DEFAULT 'Pending Verification',
    completed_by VARCHAR(100) DEFAULT NULL,
    hidden_from_sales TINYINT(1) NOT NULL DEFAULT 0
);


==================================================
ORDERED ITEMS TABLE (ASSOCIATIVE JUNCTION TABLE)
==================================================

CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (order_id)
        REFERENCES customer_orders(id),
    
    FOREIGN KEY (product_id)
        REFERENCES products(product_id)
);
 

-- ============================================================
-- 7. REPORTING VIEW
-- ============================================================

CREATE VIEW sales_report AS
SELECT
    id AS order_id,
    order_number,
    customer_name,
    total_amount,
    payment_method,
    order_status,
    payment_status,
    order_date,
    completed_by
FROM customer_orders
WHERE order_status = 'Completed'
  AND hidden_from_sales = 0;
