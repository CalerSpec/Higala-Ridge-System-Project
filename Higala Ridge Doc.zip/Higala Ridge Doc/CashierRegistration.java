import java.awt.*;
import javax.swing.*;

public class CashierRegistration extends JFrame {

    private final JTextField nameField = new JTextField();
    private final JPasswordField passwordField = new JPasswordField();
    private final JPasswordField confirmPasswordField = new JPasswordField();
    private final JTextField contactField = new JTextField();

    private final StaffManager staffManager = new StaffManager();

    // Used to refresh the Admin staff table after registration.
    private final Runnable onRegistered;

    public CashierRegistration() {
        this(null);
    }

    public CashierRegistration(Runnable onRegistered) {
        super("Cashier Registration");

        this.onRegistered = onRegistered;

        setSize(450, 380);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        getContentPane().setBackground(new Color(232, 255, 242));

        JLabel title = new JLabel(
                "REGISTER CASHIER",
                SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setForeground(new Color(7, 94, 70));
        title.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));

        add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(4, 2, 10, 12));
        form.setBackground(new Color(232, 255, 242));
        form.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));

        form.add(new JLabel("Cashier Name:"));
        form.add(nameField);

        form.add(new JLabel("Password:"));
        form.add(passwordField);

        form.add(new JLabel("Confirm Password:"));
        form.add(confirmPasswordField);

        form.add(new JLabel("Contact Number:"));
        form.add(contactField);

        add(form, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout());
        buttons.setBackground(new Color(232, 255, 242));

        JButton registerButton = new JButton("Register");
        JButton clearButton = new JButton("Clear");

        registerButton.setBackground(new Color(7, 94, 70));
        registerButton.setForeground(Color.WHITE);

        clearButton.setBackground(Color.WHITE);
        clearButton.setForeground(new Color(7, 94, 70));

        registerButton.addActionListener(e -> registerCashier());
        clearButton.addActionListener(e -> clearFields());

        buttons.add(registerButton);
        buttons.add(clearButton);

        add(buttons, BorderLayout.SOUTH);
    }

    private void registerCashier() {

    String name = nameField.getText().trim();
    String password = new String(passwordField.getPassword());
    String confirmPassword =
            new String(confirmPasswordField.getPassword());
    String contact = contactField.getText().trim();

    if (name.isEmpty()
            || password.isEmpty()
            || confirmPassword.isEmpty()
            || contact.isEmpty()) {

        JOptionPane.showMessageDialog(
                this,
                "Please fill in all fields."
        );
        return;
    }

    if (password.length() < 8) {
        JOptionPane.showMessageDialog(
                this,
                "Password must contain at least 8 characters."
        );
        return;
    }

    if (!password.equals(confirmPassword)) {
        JOptionPane.showMessageDialog(
                this,
                "Passwords do not match."
        );
        return;
    }

    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Register " + name + " as a cashier?",
            "Confirm Registration",
            JOptionPane.YES_NO_OPTION
    );

    if (confirm != JOptionPane.YES_OPTION) {
        return;
    }

    
boolean success = false;

try {
    success = staffManager.registerCashier(name, password, contact);
} catch (java.sql.SQLException ex) {
    JOptionPane.showMessageDialog(
            this,
            "Database error: " + ex.getMessage(),
            "Registration Error",
            JOptionPane.ERROR_MESSAGE
    );
    return;
}

if (success) {
    JOptionPane.showMessageDialog(
            this,
            "Cashier registered successfully!"
    );

    clearFields();

    if (onRegistered != null) {
        onRegistered.run();
    }
} else {
    JOptionPane.showMessageDialog(
            this,
            "Registration failed. The cashier name may already exist.",
            "Registration Error",
            JOptionPane.ERROR_MESSAGE
    );
}


    if (success) {

        JOptionPane.showMessageDialog(
                this,
                "Cashier registered successfully!\n"
                + "You can now start your cashier shift."
        );

        // Refresh the Admin staff list, if a callback was provided.
        if (onRegistered != null) {
            onRegistered.run();
        }

        // Close registration and open the cashier shift setup.
        dispose();

        HigalaCashierApp.startForCashier(name);

    } else {

        JOptionPane.showMessageDialog(
                this,
                "Registration failed.\n"
                + "The cashier name may already exist, "
                + "or the database rejected the registration.",
                "Registration Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    private void clearFields() {
        nameField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        contactField.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
                new CashierRegistration().setVisible(true)
        );
    }
}
