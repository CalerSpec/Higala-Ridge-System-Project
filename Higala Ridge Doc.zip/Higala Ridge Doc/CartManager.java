import java.util.ArrayList;

public class CartManager {

    public static ArrayList<String> cartItems = new ArrayList<>();
    public static ArrayList<Double> cartPrices = new ArrayList<>();

    public static void addItem(String item, double price, int quantity, String flavor) {
        String itemDescription = item + " | Qty: " + quantity + (flavor.isEmpty() ? "" : " | Flavor: " + flavor);

        double totalPrice = price * quantity;

        cartItems.add(itemDescription);
        cartPrices.add(totalPrice);
    }
}
