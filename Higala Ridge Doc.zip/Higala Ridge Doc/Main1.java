import java.awt.*;
import javax.swing.*;

public class Main1 extends JFrame {

    private final Color FOREST_CODE = new Color(7, 94, 70);
    private final Color MINT_FOG = new Color(232, 255, 242);
    private final Color DARK_OLIVE = new Color(45, 46, 41);
    private final Color WHITE = Color.WHITE;

    public Main1() {

        setTitle("Higala Ridge");
        setSize(600, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // ==========================================
        // MAIN BACKGROUND
        // ==========================================

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_FOG);


        // ==========================================
        // UPPER SECTION
        // ==========================================

        JPanel upperPanel = new JPanel(new BorderLayout());
        upperPanel.setBackground(FOREST_CODE);
        upperPanel.setPreferredSize(new Dimension(1000, 200));

        JPanel lowerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        lowerPanel.setBackground(MINT_FOG);
        lowerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(MINT_FOG);

        JPanel greetingPanel = new JPanel(new GridLayout(2,1));
        greetingPanel.setBackground(MINT_FOG);

        // ==========================================
        // COMPANY LOGO
        // ==========================================

        ImageIcon orig = new ImageIcon("C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Higala Ridge Logo.png");
        Image image = orig.getImage();
        Image resized = image.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        ImageIcon newImage = new ImageIcon(resized);

        JLabel logo = new JLabel(newImage);
        logo.setHorizontalAlignment(JLabel.CENTER);

        upperPanel.add(logo, BorderLayout.CENTER);


        // ==========================================
        // WELCOME SECTION
        // ==========================================

        JLabel welcomeLabel = new JLabel("Welcome to Higala Ridge!");
        welcomeLabel.setForeground(FOREST_CODE);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 30));
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        welcomeLabel.setVerticalAlignment(JLabel.CENTER);
        
        JLabel belowLabel = new JLabel(" Nature   •   Adventure   •   Dining");
        belowLabel.setForeground(FOREST_CODE);
        belowLabel.setFont(new Font("Arial", Font.BOLD, 15));
        belowLabel.setHorizontalAlignment(JLabel.CENTER);
        belowLabel.setVerticalAlignment(JLabel.CENTER);

        greetingPanel.add(welcomeLabel);
        greetingPanel.add(belowLabel);

        centerPanel.add(greetingPanel);

        JButton proceedButton = new JButton("Proceed");

        proceedButton.setBackground(MINT_FOG);
        proceedButton.setForeground(FOREST_CODE);
        proceedButton.setFont(new Font("Arial", Font.BOLD, 18));
        proceedButton.setFocusPainted(false);

        lowerPanel.add(proceedButton);

        proceedButton.addActionListener(e -> {
            new FoodCategories();
            dispose();
        });

        mainPanel.add(upperPanel, BorderLayout.NORTH);
        mainPanel.add(lowerPanel, BorderLayout.SOUTH);
        mainPanel.add(centerPanel, BorderLayout.CENTER);

        add(mainPanel);

        setVisible(true);
    }


    public static void main(String[] args) {
        new Main1();
    }
}