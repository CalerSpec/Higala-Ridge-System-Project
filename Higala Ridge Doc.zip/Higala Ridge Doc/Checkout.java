import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.swing.*;

public class Checkout extends JFrame {

    private final Color FOREST_CODE = new Color(7, 94, 70);
    private final Color MINT_FOG = new Color(232, 255, 242);

    private final HigalaStore store = new HigalaStore();

    
private int getQuantity(String item) {

    try {
        String quantityText = null;

        int start = item.lastIndexOf("Quantity:");

        if (start != -1) {
            quantityText = item.substring(start + 9).trim();
        } else {
            start = item.lastIndexOf("Qty:");

            if (start != -1) {
                quantityText = item.substring(start + 4).trim();
            }
        }

        if (quantityText == null) {
            return 1;
        }

        // Ignore any remaining text after the quantity.
        int end = quantityText.indexOf("|");

        if (end != -1) {
            quantityText = quantityText.substring(0, end).trim();
        }

        int quantity = Integer.parseInt(quantityText);

        return quantity > 0 ? quantity : 1;

    } catch (NumberFormatException e) {
        return 1;
    }
}

    private String saveOrder(double total, String paymentMethod, String customerName, String paymentReference) {

    String orderNumber = null;
    Map<String, Integer> quantities = new LinkedHashMap<>();

    for (int i = 0; i < CartManager.cartItems.size(); i++) {
        String item = CartManager.cartItems.get(i);

        // Get the product name before the "|" separator.
        String productName = item.split("\\|", 2)[0].trim();

        int quantity = getQuantity(item);

        quantities.merge(productName, quantity, Integer::sum);
    }

    boolean stockDeducted = false;
    String orderSql = "INSERT INTO customer_orders " + "(customer_name, total_amount, payment_method, " + "payment_reference, payment_status) " + "VALUES (?, ?, ?, ?, ?)";
    String productIdSql = "SELECT product_id FROM products WHERE product_name = ?";
    String itemSql = "INSERT INTO order_items " + "(order_id, product_id, product_name, quantity, price) " + "VALUES (?, ?, ?, ?, ?)";

    try (Connection conn =
            DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new SQLException(
                "Database connection failed."
            );
        }

        conn.setAutoCommit(false);

        try {
            String stockError = store.deductStock(quantities);

            if (stockError != null) {
                conn.rollback();

                JOptionPane.showMessageDialog(this, "Unable to place order:\n" + stockError);

                return null;
            }

            stockDeducted = true;
            int orderId;

            // Save the main order
            try (PreparedStatement ps =
                    conn.prepareStatement(
                        orderSql,
                        Statement.RETURN_GENERATED_KEYS)) {

                ps.setString(1, customerName);
                ps.setDouble(2, total);
                ps.setString(3, paymentMethod);

                if (paymentReference == null || paymentReference.trim().isEmpty()) {
                    ps.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    ps.setString(4, paymentReference.trim());
                }

                ps.setString(5, "Pending Verification");
                ps.executeUpdate();

                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (!rs.next()) {
                        throw new SQLException(
                            "Order ID was not generated."
                        );
                    }

                    orderId = rs.getInt(1);
                }
            }

            // Generate a unique order number
            orderNumber = String.format(
                "HR-%06d", orderId
            );

            String updateSql =
                "UPDATE customer_orders "
              + "SET order_number = ? WHERE id = ?";

            try (PreparedStatement ps =
                    conn.prepareStatement(updateSql)) {

                ps.setString(1, orderNumber);
                ps.setInt(2, orderId);
                ps.executeUpdate();
            }

            // Save every item in the cart
            
            // Save every item in the cart
            try (
                PreparedStatement lookupPs =
                    conn.prepareStatement(productIdSql);

                PreparedStatement ps =
                    conn.prepareStatement(itemSql)
            ) {

                for (int i = 0;
                     i < CartManager.cartItems.size(); i++) {

                    String item =
                        CartManager.cartItems.get(i);

                    // Extract the product name before "|".
                    String productName =
                        item.split("\\|", 2)[0].trim();

                    double itemTotal =
                        CartManager.cartPrices.get(i);

                    int quantity = getQuantity(item);

                    // Find the product ID.
                    lookupPs.setString(1, productName);

                    int productId;

                    try (ResultSet rs =
                            lookupPs.executeQuery()) {

                        if (!rs.next()) {
                            throw new SQLException(
                                "Product not found in database: "
                                + productName
                            );
                        }

                        productId =
                            rs.getInt("product_id");

                        // Ensure the name identifies one product.
                        if (rs.next()) {
                            throw new SQLException(
                                "Duplicate product names found: "
                                + productName
                            );
                        }
                    }

                    // Calculate the unit price.
                    double unitPrice =
                        itemTotal / quantity;

                    // Save the order item and its product ID.
                    ps.setInt(1, orderId);
                    ps.setInt(2, productId);
                    ps.setString(3, item);
                    ps.setInt(4, quantity);
                    ps.setDouble(5, unitPrice);

                    ps.addBatch();
                }

                ps.executeBatch();
            }

            // Save everything together
            conn.commit();

        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }

    } catch (SQLException e) {

        if (stockDeducted) {
            try {
                store.updateItems(list -> {
                    for (Map.Entry<String, Integer> entry : quantities.entrySet()) {
                        for (HigalaStore.Item item : list) {
                            if (item.name.equalsIgnoreCase(entry.getKey())) {
                                item.stock += entry.getValue();
                                break;
                            }
                        }
                    }
                });
            } catch (RuntimeException restoreError) {
                JOptionPane.showMessageDialog(this, "The order failed, and stock restoration also failed. " + "Please check the inventory");
            }
        }
        JOptionPane.showMessageDialog(
            this,
            "Failed to save order: " + e.getMessage()
        );

        return null;
    }

    return orderNumber;
}

    public Checkout() {

        setTitle("Checkout");
        setSize(550, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_FOG);
        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        // =========================
        // TITLE
        // =========================

        JLabel title = new JLabel("CHECKOUT");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(FOREST_CODE);
        title.setHorizontalAlignment(JLabel.CENTER);
        title.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0)
    );
        mainPanel.add(title, BorderLayout.NORTH);

        // =========================
        // CENTER PANEL
        // =========================

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBackground(MINT_FOG);

        // =========================
        // ORDER SUMMARY
        // =========================

        JLabel orderTitle = new JLabel("ORDER SUMMARY");
        orderTitle.setFont(new Font("Arial", Font.BOLD, 18));
        orderTitle.setForeground(FOREST_CODE);
        orderTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

    
        centerPanel.add(orderTitle);
        centerPanel.add(Box.createVerticalStrut(10));

        JPanel orderPanel = new JPanel();
        orderPanel.setLayout(new BoxLayout(orderPanel, BoxLayout.Y_AXIS));
        orderPanel.setBackground(Color.WHITE);
        orderPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        double total = 0;

        for (int i = 0; i < CartManager.cartItems.size(); i++) {

            String item = CartManager.cartItems.get(i);
            double price = CartManager.cartPrices.get(i);

            JLabel itemLabel = new JLabel(
                item + "     ₱" + String.format("%.2f", price)
            );

            itemLabel.setFont(
                new Font("Arial", Font.PLAIN, 15)
            );

            orderPanel.add(itemLabel);
            orderPanel.add(Box.createVerticalStrut(8));

            total += price;
        }

        final double orderTotal = total;

        // Make only the product list scrollable
        JScrollPane orderScroll = new JScrollPane(orderPanel);

        orderScroll.setPreferredSize(new Dimension(450, 130));
        orderScroll.setMinimumSize(new Dimension(450, 130));
        orderScroll.setMaximumSize(new Dimension(450, 130));

        orderScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        orderScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        orderScroll.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(orderScroll);

        centerPanel.add(Box.createVerticalStrut(20));

        // =========================
        // CUSTOMER INFORMATION
        // =========================

        JLabel customerTitle = new JLabel("CUSTOMER INFORMATION");
        customerTitle.setFont(new Font("Arial", Font.BOLD, 18));
        customerTitle.setForeground(FOREST_CODE);
        customerTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(customerTitle);
        centerPanel.add(Box.createVerticalStrut(10));

        // Name
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField nameField = new JTextField();
        nameField.setMaximumSize(new Dimension(250, 35));
        nameField.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(nameLabel);
        centerPanel.add(nameField);

        centerPanel.add(Box.createVerticalStrut(10));

        // Address
        JLabel orderNumberLabel = new JLabel("Order Number:");
        orderNumberLabel.setFont(new Font("Arial", Font.BOLD, 14));
        orderNumberLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextField orderField = new JTextField("Auto-Generated");
        orderField.setEditable(false);
        orderField.setMaximumSize(new Dimension(250, 35));
        orderField.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(orderNumberLabel);
        centerPanel.add(orderField);

        centerPanel.add(Box.createVerticalStrut(10));

        // Payment
        JLabel paymentLabel = new JLabel("Payment Method:");
        paymentLabel.setFont(new Font("Arial", Font.BOLD, 14));
        paymentLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        String[] paymentMethods = {
            "Cash Upfront",
            "GCash",
            "Credit/Debit Card"
        };

        JComboBox<String> paymentBox = new JComboBox<>(paymentMethods);
        paymentBox.setMaximumSize(new Dimension(250, 35));
        paymentBox.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(paymentLabel);
        centerPanel.add(paymentBox);

        centerPanel.add(Box.createVerticalStrut(10));

        JLabel referenceLabel = new JLabel("Payment Reference Code:");
        referenceLabel.setFont(new Font("Arial", Font.BOLD, 14));
        referenceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JTextField referenceField = new JTextField();
        referenceField.setMaximumSize(new Dimension(250, 35));
        referenceField.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(referenceLabel);
        centerPanel.add(referenceField);

        boolean showReferences = !"Cash Upfront".equals(paymentBox.getSelectedItem());

        referenceLabel.setVisible(showReferences);
        referenceField.setVisible(showReferences);

        paymentBox.addActionListener(e -> {
            boolean needsReference = !"Cash Upfront".equals(paymentBox.getSelectedItem());
            referenceLabel.setVisible(needsReference);
            referenceField.setVisible(needsReference);

            centerPanel.revalidate();
            centerPanel.repaint();
        });

        // TOTAL
        JLabel totalLabel = new JLabel("TOTAL: ₱" + String.format("%.2f", orderTotal));

        totalLabel.setFont(new Font("Arial", Font.BOLD, 22));

        totalLabel.setForeground(FOREST_CODE);
        totalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        centerPanel.add(totalLabel);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        JButton placeOrderButton = new JButton("PLACE ORDER");
        placeOrderButton.setFont(new Font("Arial", Font.BOLD, 16));
        placeOrderButton.setBackground(FOREST_CODE);
        placeOrderButton.setForeground(MINT_FOG);
        placeOrderButton.setFocusPainted(false);
        placeOrderButton.setPreferredSize(new Dimension(200, 45));

        placeOrderButton.addActionListener(e -> {

            if (nameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your name.");
                return;
            }

            if (CartManager.cartItems.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Your cart is empty.");
                return;
            }

            String customerName = nameField.getText().trim();
            String paymentMethod = (String) paymentBox.getSelectedItem();
            String paymentReference = referenceField.getText().trim();

            if (!"Cash Upfront".equals(paymentMethod) && paymentReference.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter your payment reference code.");
                return;
            }

            String orderNumber = saveOrder(orderTotal, paymentMethod, customerName, paymentReference);

            // Continue only if saving succeeded
            
            if (orderNumber != null) {

                // Keep a copy of the order before clearing the cart.
                java.util.List<String> orderedItems = new java.util.ArrayList<>(CartManager.cartItems);
                java.util.List<Double> orderedPrices = new java.util.ArrayList<>(CartManager.cartPrices);

                // Clear the cart for the next customer.
                CartManager.cartItems.clear();
                CartManager.cartPrices.clear();

                // Close checkout.
                dispose();

                // Open the order confirmation screen.
                new OrderConfirmation(orderNumber, customerName, paymentMethod, orderTotal, orderedItems, orderedPrices);
            }

        });

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(MINT_FOG);
        bottomPanel.add(placeOrderButton);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }
}