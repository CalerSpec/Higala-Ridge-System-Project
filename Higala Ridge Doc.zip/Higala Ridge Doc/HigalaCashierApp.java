import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class HigalaCashierApp extends JFrame {

    // ---------- Look ----------
    // private final Color HEADER_GREEN = Color.RED;
    private static final Color HEADER_GREEN = new Color(0x2E6B34);
    private static final Color SIDEBAR_GREEN = new Color(0x2A5A2E);
    private static final Color DARK_GREEN = new Color(0x1E4D2B);
    private static final Color CONTENT_BG = new Color(0xECEFF1);
    // private final Color NAV_GRAY = Color.YELLOW;
    private static final Color NAV_GRAY = new Color(0xC9CDC9);
    // private final Color ITEM_GREEN = Color.RED;
    private static final Color ITEM_GREEN = new Color(0x3F8A48);
    private static final Color PAY_CASH = new Color(0x2E7D32);
    private static final Color PAY_CARD = new Color(0x1565C0);
    private static final Color PAY_GCASH = new Color(0x6A1B9A);
    private static final Color WARN = new Color(0xC62828);
    private static final Color MUTED = new Color(0x607D8B);

    private static final String CUR = "PHP ";
    private static final double LOW_CASH = 500;
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter SHORT_TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    // ---------- Shared Store ----------
    // Uses the SAME HigalaStore as the Admin application.
    private final HigalaStore store = new HigalaStore();

    // ---------- Models ----------
    enum PayMethod {
        CASH("Cash"), CARD("Card"), GCASH("Gcash");

        private final String label;

        PayMethod(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    enum OrderStatus {
        PENDING("Pending"),
        PREPARING("Preparing"),
        READY("Ready"),
        COMPLETED("Completed");

        private final String label;

        OrderStatus(String label) {
            this.label = label;
        }

        OrderStatus next() {
            return this == COMPLETED ? COMPLETED : values()[ordinal() + 1];
        }

        @Override
        public String toString() {
            return label;
        }
    }

    static class LineItem {
        final String name;
        final double price;
        int qty;

        LineItem(String name, double price, int qty) {
            this.name = name;
            this.price = price;
            this.qty = qty;
        }

        double total() {
            return price * qty;
        }
    }

    // One slice of an order for one preparation table
    // (SNACKS / DESSERT / DRINKS)
    static class Ticket {
        final String category;
        final List<LineItem> items = new ArrayList<>();
        OrderStatus status = OrderStatus.PENDING;

        Ticket(String category) {
            this.category = category;
        }

        String summary() {
            StringBuilder sb = new StringBuilder();

            for (LineItem li : items) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(li.name).append(" x").append(li.qty);
            }

            return sb.toString();
        }
    }

    static class Order {
        final int id;
        final LocalDateTime time = LocalDateTime.now();
        final List<LineItem> items;
        final double total;
        final PayMethod method;
        final List<Ticket> tickets = new ArrayList<>();
        boolean refunded = false;

        Order(int id, List<LineItem> items, double total, PayMethod method) {
            this.id = id;
            this.items = items;
            this.total = total;
            this.method = method;
        }

        String summary() {
            StringBuilder sb = new StringBuilder();

            for (LineItem li : items) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(li.name).append(" x").append(li.qty);
            }

            return sb.toString();
        }

        // The order is only as far along as its slowest preparation table.
        OrderStatus status() {
            if (tickets.isEmpty()) return OrderStatus.COMPLETED;

            OrderStatus min = OrderStatus.COMPLETED;

            for (Ticket t : tickets) {
                if (t.status.ordinal() < min.ordinal()) {
                    min = t.status;
                }
            }

            return min;
        }

        String statusText() {
            return refunded ? "Refunded" : status().toString();
        }
    }

    // ENCAPSULATION == Cannot be accessed easily and prevents invalid input and blockers.
    // ---------- State ----------
    // category name -> (item name -> price)
    private final Map<String, Map<String, Double>> categories = new LinkedHashMap<>();

    // item name -> price
    private final Map<String, Double> catalog = new LinkedHashMap<>();

    // item name -> category                                                                                                                                                                                                                                                                         
    private final Map<String, String> itemCategory = new LinkedHashMap<>();

    private final List<LineItem> cart = new ArrayList<>();
    private final List<Order> orders = new ArrayList<>();

    private final String cashierName;
    private final String registerNo;
    private final double openingFloat;
    private final LocalDateTime shiftStart = LocalDateTime.now();

    private double cashIn = 0;
    private double cashOut = 0;
    private int voidedItems = 0;
    private double voidedAmount = 0;

    // Will be replaced by the next receipt number from HigalaStore.
    private int nextId = 1001;

    // ---------- Components ----------
    private final CardLayout cards = new CardLayout();
    private final JPanel pages = new JPanel(cards);
    private final Map<String, JButton> navButtons = new LinkedHashMap<>();

    private final DefaultTableModel cartModel = readOnlyModel("Item", "Qty", "Price", "Total");
    private final DefaultTableModel ordersModel = readOnlyModel("Order #", "Time", "Items", "Total", "Payment", "Status");
    private final DefaultTableModel salesModel = readOnlyModel("Order #", "Time", "Items", "Total", "Payment", "Status");
    
    private final Map<String, DefaultTableModel> onlineModels = new LinkedHashMap<>();
    private final Map<String, JTable> onlineTables = new LinkedHashMap<>();
    private final Map<Integer, String[]> onlineDetails = new LinkedHashMap<>();
    private boolean onlineSelAdjusting = false;
    private boolean walkInSelAdjusting = false;
    
    private JTable cartTable, ordersTable, salesTable;

    private final Map<String, DefaultTableModel> stationModels = new LinkedHashMap<>();

    private final Map<String, JTable> stationTables = new LinkedHashMap<>();

    private JLabel cartTotalLabel;

    private JLabel dSales, dOrders, dAvg, dPending, dRefunds, dDrawer, dAlert;
    private JLabel sTotal, sCash, sCard, sGcash, sRefunds, sVoids;

    HigalaCashierApp(String cashierName, double openingFloat) {
        super("Higala Ridge - Cashier");

        this.cashierName = cashierName;
        this.registerNo = "1";
        this.openingFloat = openingFloat;

        // Load the inventory from the shared HigalaStore.
        loadCatalog();

        // Load existing sales so receipt numbers continue correctly.
        loadExistingSales();

        setLayout(new BorderLayout());

        add(buildHeader(), BorderLayout.NORTH);
        add(buildSidebar(), BorderLayout.WEST);

        pages.add(buildDashboardPage(), "DASHBOARD");
        pages.add(buildOrdersPage(), "ORDERS");
        pages.add(buildPreparationPage(), "PREPARATION");
        pages.add(buildSalesPage(), "SALES");
        pages.add(buildCustomerOrdersPage(), "CUSTOMER ORDERS");

        JPanel content = new JPanel(new BorderLayout());
        content.setBackground(HEADER_GREEN);
        content.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 10));
        content.add(pages, BorderLayout.CENTER);

        add(content, BorderLayout.CENTER);

        showPage("DASHBOARD");
        refreshAll();

        setSize(1280, 780);
        setMinimumSize(new Dimension(1100, 680));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                confirmExit();
            }
        });
    }

    // =====================================================================
    // Shared inventory
    // =====================================================================

    private void addItem(String category, String name, double price) {
        categories
                .computeIfAbsent(category, k -> new LinkedHashMap<>())
                .put(name, price);

        catalog.put(name, price);
        itemCategory.put(name, category);
    }

    /**
     * Loads the CURRENT inventory from HigalaStore.
     *
     * The Admin application can add, remove, rename, change price,
     * or change stock, and the Cashier will see those products here.
     */
    private void loadCatalog() {
        categories.clear();
        catalog.clear();
        itemCategory.clear();

        List<HigalaStore.Item> items = store.loadItems();

        for (HigalaStore.Item item : items) {
            if (item.category == null || item.name == null) continue;

            addItem(
                    item.category,
                    item.name,
                    item.price
            );
        }

        // Ensure the three normal categories exist even if one is empty.
        for (String category : HigalaStore.CATEGORIES) {
            categories.computeIfAbsent(category, k -> new LinkedHashMap<>());
        }
    }

    /**
     * Loads existing sales from HigalaStore.
     *
     * This is primarily used to continue receipt numbering and to make
     * already-saved transactions visible in the cashier's sales screen.
     */
    private void loadExistingSales() {
        List<HigalaStore.Sale> savedSales = store.loadSales();

        int highest = 1000;

        for (HigalaStore.Sale s : savedSales) {
            highest = Math.max(highest, s.receipt);

            PayMethod method = parsePayMethod(s.method);

            if (method == null) continue;

            List<LineItem> items = parseSaleItems(s.items);

            Order order = new Order(
                    s.receipt,
                    items,
                    s.total,
                    method
            );

            order.refunded = s.refunded;

            buildTickets(order);

            // Saved sales are already completed from the cashier's point
            // of view. Their preparation tickets are therefore completed.
            for (Ticket t : order.tickets) {
                t.status = OrderStatus.COMPLETED;
            }

            orders.add(order);
        }

        nextId = Math.max(1001, highest + 1);
    }

    private PayMethod parsePayMethod(String method) {
        if (method == null) return null;

        for (PayMethod p : PayMethod.values()) {
            if (p.toString().equalsIgnoreCase(method)) {
                return p;
            }
        }

        return null;
    }

    /**
     * HigalaStore saves sale items as a single text field.
     *
     * Expected format from this cashier:
     * Item x2, Another Item x1
     */
    private List<LineItem> parseSaleItems(String text) {
        List<LineItem> result = new ArrayList<>();

        if (text == null || text.trim().isEmpty()) {
            return result;
        }

        String[] parts = text.split(", ");

        for (String part : parts) {
            int marker = part.lastIndexOf(" x");

            if (marker <= 0) continue;

            String name = part.substring(0, marker).trim();
            String qtyText = part.substring(marker + 2).trim();

            try {
                int qty = Integer.parseInt(qtyText);

                Double price = catalog.get(name);

                if (price == null) {
                    // If the product no longer exists in the current menu,
                    // calculate a zero-price placeholder rather than crashing.
                    price = 0.0;
                }

                if (qty > 0) {
                    result.add(new LineItem(name, price, qty));
                }
            } catch (NumberFormatException ignored) {
            }
        }

        return result;
    }

    // =====================================================================
    // UI building
    // =====================================================================

    private JComponent buildHeader() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(HEADER_GREEN);
        p.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
        p.setPreferredSize(new Dimension(0, 110));

        File logoFile = new File("logo.png");

        JLabel logo = new JLabel();
        logo.setPreferredSize(new Dimension(96, 90));

        if (logoFile.exists()) {
            Image img = new ImageIcon(logoFile.getPath())
                    .getImage()
                    .getScaledInstance(90, 90, Image.SCALE_SMOOTH);

            logo.setIcon(new ImageIcon(img));
        }

        p.add(logo, BorderLayout.WEST);

        JLabel title = new JLabel(
                "HIGALA RIDGE - CASHIER",
                SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 38));
        title.setForeground(Color.WHITE);

        p.add(title, BorderLayout.CENTER);

        JLabel clock = new JLabel();
        clock.setForeground(Color.WHITE);
        clock.setFont(new Font("Arial", Font.PLAIN, 13));
        clock.setPreferredSize(new Dimension(96, 90));
        clock.setHorizontalAlignment(SwingConstants.RIGHT);

        javax.swing.Timer t = new javax.swing.Timer(
                1000,
                e -> clock.setText(
                        "<html><div style='text-align:right'>"
                                + LocalDateTime.now().format(TIME_FMT)
                                + "</div></html>"
                )
        );

        t.setInitialDelay(0);
        t.start();

        p.add(clock, BorderLayout.EAST);

        return p;
    }

    private JComponent buildSidebar() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(SIDEBAR_GREEN);
        p.setBorder(BorderFactory.createEmptyBorder(24, 16, 16, 16));
        p.setPreferredSize(new Dimension(250, 0));

        JLabel t = new JLabel("CASHIER");
        t.setFont(new Font("Arial", Font.BOLD, 30));
        t.setForeground(Color.WHITE);
        t.setAlignmentX(Component.CENTER_ALIGNMENT);

        p.add(t);
        p.add(Box.createVerticalStrut(34));

        for (String name :
                new String[]{"DASHBOARD", "ORDERS", "ONLINE ORDERS", "WALK-IN ORDERS", "SALES"}) {

            JButton b = button(
                    name,
                    NAV_GRAY,
                    DARK_GREEN,
                    18
            );

            b.setAlignmentX(Component.CENTER_ALIGNMENT);
            b.setPreferredSize(new Dimension(210, 62));
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));

            b.addActionListener(e -> {
                if (name.equals("ONLINE ORDERS")) {
                        showPage("CUSTOMER ORDERS");
                } else if (name.equals("WALK-IN ORDERS")) {
                        showPage("PREPARATION");
                } else {
                        showPage(name);
                }
            });

            navButtons.put(name, b);

            p.add(b);
            p.add(Box.createVerticalStrut(18));
        }

        p.add(Box.createVerticalGlue());

        JLabel info = new JLabel(
                "<html><div style='text-align:center'>"
                        + cashierName
                        + "<br>Register "
                        + registerNo
                        + "<br>Shift since "
                        + shiftStart.format(DATE_FMT)
                        + "</div></html>"
        );

        info.setForeground(new Color(0xCFE3D0));
        info.setFont(new Font("Arial", Font.PLAIN, 12));
        info.setAlignmentX(Component.CENTER_ALIGNMENT);

        p.add(info);

        return p;
    }

    private JComponent buildCustomerOrdersPage() {

    JPanel p = page();

    p.add(pageTitle("ONLINE ORDERS"), BorderLayout.NORTH);

    JPanel row = new JPanel(
            new GridLayout(1, categories.size(), 12, 12)
    );

    row.setOpaque(false);
    row.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));

    for (String cat : categories.keySet()) {

        DefaultTableModel model = readOnlyModel(
                "#", "Time", "Items", "Receipt", "Payment", "Status"
        );

        JTable table = new JTable(model);
        styleTable(table);

        // Extra columns: let the table scroll sideways instead of
        // squeezing everything.
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        table.getColumnModel().getColumn(0).setPreferredWidth(44);
        table.getColumnModel().getColumn(1).setPreferredWidth(52);
        table.getColumnModel().getColumn(2).setPreferredWidth(170);
        table.getColumnModel().getColumn(3).setPreferredWidth(90);
        table.getColumnModel().getColumn(4).setPreferredWidth(130);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);

        onlineModels.put(cat, model);
        onlineTables.put(cat, table);

        // Only one row can be selected across all three tables.
        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || onlineSelAdjusting) return;
            if (table.getSelectedRow() < 0) return;

            onlineSelAdjusting = true;

            for (JTable other : onlineTables.values()) {
                if (other != table) other.clearSelection();
            }

            onlineSelAdjusting = false;
        });

        JLabel header = new JLabel(cat, SwingConstants.CENTER);
        header.setOpaque(true);
        header.setBackground(DARK_GREEN);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Arial", Font.BOLD, 18));
        header.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        JButton next = actionButton(
                "Update Status",
                ITEM_GREEN,
                Color.WHITE,
                e -> advanceOnlineStation(cat)
        );

        next.setPreferredSize(new Dimension(0, 50));

        JPanel col = new JPanel(new BorderLayout(0, 6));
        col.setOpaque(false);
        col.add(header, BorderLayout.NORTH);
        col.add(new JScrollPane(table), BorderLayout.CENTER);
        col.add(next, BorderLayout.SOUTH);

        row.add(col);
    }

    p.add(row, BorderLayout.CENTER);

    // Bottom bar
    JPanel bottom = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 10, 10)
    );

    bottom.setOpaque(false);

    JButton refresh = actionButton(
            "Refresh Orders", NAV_GRAY, DARK_GREEN,
            e -> refreshOnlineStations()
    );

    JButton receipt = actionButton(
            "View Receipt", PAY_CARD, Color.WHITE,
            e -> showOnlineReceipt()
    );

    JButton paid = actionButton(
            "Mark Paid", PAY_CASH, Color.WHITE,
            e -> markOnlinePaid()
    );

    JButton cancel = actionButton(
            "Cancel Order", PAY_GCASH, Color.WHITE,
            e -> cancelOnlineOrder()
    );

    JButton delete = actionButton(
            "Delete Order", WARN, Color.WHITE,
            e -> deleteOnlineOrder()
    );

    for (JButton b : new JButton[]{refresh, receipt, paid, cancel, delete}) {
        b.setPreferredSize(new Dimension(170, 46));
        bottom.add(b);
    }

    p.add(bottom, BorderLayout.SOUTH);

    return p;
}

private void refreshOnlineStations() {

    int keepId = selectedOnlineId();

    for (DefaultTableModel model : onlineModels.values()) {
        model.setRowCount(0);
    }

    onlineDetails.clear();

    String orderSql =
            "SELECT id, order_number, customer_name, order_date, "
          + "total_amount, payment_method, payment_reference, "
          + "payment_status, order_status "
          + "FROM customer_orders ORDER BY id DESC";

    String itemSql =
            "SELECT order_id, product_name, quantity FROM order_items";

    try (Connection conn = DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        // 1. All items, grouped by order id.
        Map<Integer, List<String[]>> itemsByOrder = new LinkedHashMap<>();

        try (PreparedStatement ps = conn.prepareStatement(itemSql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                itemsByOrder
                        .computeIfAbsent(rs.getInt("order_id"),
                                k -> new ArrayList<>())
                        .add(new String[] {
                            rs.getString("product_name"),
                            String.valueOf(rs.getInt("quantity"))
                        });
            }
        }

        // 2. All orders.
        try (PreparedStatement ps = conn.prepareStatement(orderSql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                int id = rs.getInt("id");

                java.sql.Timestamp ts = rs.getTimestamp("order_date");

                String time = ts == null
                        ? "N/A" : ts.toLocalDateTime().format(SHORT_TIME);

                String date = ts == null
                        ? "N/A" : ts.toLocalDateTime().format(DATE_FMT);

                String ref = rs.getString("payment_reference");
                if (ref == null || ref.trim().isEmpty()) ref = "-";

                String payStatus = rs.getString("payment_status");
                if (payStatus == null) payStatus = "-";

                String status = rs.getString("order_status");
                if (status == null) status = "Pending";

                // Split this order's items by category.
                Map<String, List<String>> byCat = new LinkedHashMap<>();
                List<String> all = new ArrayList<>();

                List<String[]> items = itemsByOrder.get(id);

                if (items != null) {
                    for (String[] it : items) {
                        String text = it[0] + " x" + it[1];
                        all.add(text);

                        byCat.computeIfAbsent(
                                onlineStationFor(it[0]),
                                k -> new ArrayList<>()
                        ).add(text);
                    }
                }

                if (byCat.isEmpty()) {
                    String first = onlineModels.keySet().iterator().next();
                    byCat.put(first, new ArrayList<>(
                            java.util.Collections.singletonList("No items")));
                    all.add("No items");
                }

                for (Map.Entry<String, List<String>> en : byCat.entrySet()) {
                    onlineModels.get(en.getKey()).addRow(new Object[] {
                        id,
                        time,
                        String.join(", ", en.getValue()),
                        ref,
                        payStatus,
                        status
                    });
                }

                onlineDetails.put(id, new String[] {
                    rs.getString("order_number"),
                    rs.getString("customer_name"),
                    String.join(", ", all),
                    money(rs.getDouble("total_amount")),
                    rs.getString("payment_method"),
                    ref,
                    payStatus,
                    status,
                    date
                });
            }
        }

    } catch (SQLException e) {
        warn("Failed to load online orders:\n" + e.getMessage());
    }

    if (keepId > 0) {
        for (String cat : onlineTables.keySet()) {
            reselect(onlineTables.get(cat), onlineModels.get(cat), keepId);
        }
    }
}

private String onlineStationFor(String rawName) {

    String fallback = onlineModels.keySet().iterator().next();

    if (rawName == null) return fallback;

    // "Burger | Qty: 1" -> "Burger"
    String clean = rawName.split("\\|")[0].trim().toLowerCase();

    String category = null;

    // Exact match against the cashier's menu.
    for (Map.Entry<String, String> en : itemCategory.entrySet()) {
        if (en.getKey().trim().equalsIgnoreCase(clean)) {
            category = en.getValue();
            break;
        }
    }

    // Looser match: one name contains the other.
    if (category == null) {
        for (Map.Entry<String, String> en : itemCategory.entrySet()) {
            String menu = en.getKey().trim().toLowerCase();
            if (!menu.isEmpty()
                    && (clean.contains(menu) || menu.contains(clean))) {
                category = en.getValue();
                break;
            }
        }
    }

    if (category == null) return fallback;

    for (String station : onlineModels.keySet()) {
        if (station.equalsIgnoreCase(category)) return station;
    }

    return fallback;
}

private int selectedOnlineId() {

    for (Map.Entry<String, JTable> en : onlineTables.entrySet()) {

        JTable table = en.getValue();
        int row = table.getSelectedRow();

        if (row < 0) continue;

        int modelRow = table.convertRowIndexToModel(row);

        return (Integer) onlineModels.get(en.getKey())
                .getValueAt(modelRow, 0);
    }

    return -1;
}

private void advanceOnlineStation(String category) {

    JTable table = onlineTables.get(category);
    DefaultTableModel model = onlineModels.get(category);

    int row = table.getSelectedRow();

    if (row < 0) {
        info("Select an order in the " + category + " table first.");
        return;
    }

    int modelRow = table.convertRowIndexToModel(row);

    int id = (Integer) model.getValueAt(modelRow, 0);
    String current = String.valueOf(model.getValueAt(modelRow, 5));

    if ("Cancelled".equalsIgnoreCase(current)) {
        info("This order was cancelled.");
        return;
    }

    OrderStatus status = null;

    for (OrderStatus s : OrderStatus.values()) {
        if (s.toString().equalsIgnoreCase(current)) {
            status = s;
            break;
        }
    }

    if (status == null) {
        warn("Unknown order status: " + current);
        return;
    }

    if (status == OrderStatus.COMPLETED) {
        info("This order is already completed.");
        return;
    }

    if (updateOnlineStatus(id, status.next().toString())) {
        refreshOnlineStations();
        refreshStats();
    }
}

private void showOnlineReceipt() {

    int id = selectedOnlineId();

    if (id < 0) {
        info("Select an order first.");
        return;
    }

    String[] d = onlineDetails.get(id);

    if (d == null) {
        warn("Order details not found. Press Refresh Orders.");
        return;
    }

    StringBuilder sb = new StringBuilder();

    sb.append("HIGALA RIDGE\n");
    sb.append("Online Order ").append(d[0]).append('\n');
    sb.append(d[8]).append('\n');
    sb.append("Customer: ").append(d[1]).append('\n');
    sb.append("------------------------------------------\n");

    for (String item : d[2].split(", ")) {
        sb.append(item).append('\n');
    }

    sb.append("------------------------------------------\n");

    sb.append(String.format("%-20s %21s%n", "TOTAL", d[3]));
    sb.append(String.format("%-20s %21s%n", "Payment method", d[4]));
    sb.append(String.format("%-20s %21s%n", "Payment reference", d[5]));
    sb.append(String.format("%-20s %21s%n", "Payment status", d[6]));
    sb.append(String.format("%-20s %21s%n", "Order status", d[7]));

    sb.append("\nThank you!\n");

    JTextArea area = new JTextArea(sb.toString());
    area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
    area.setEditable(false);

    showReceiptDialog("Receipt " + d[0], area);
}

private void markOnlinePaid() {

    int id = selectedOnlineId();

    if (id < 0) {
        info("Select an order first.");
        return;
    }

    String[] d = onlineDetails.get(id);

    int ok = JOptionPane.showConfirmDialog(
            this,
            "Mark order " + (d == null ? "#" + id : d[0])
                    + " as PAID?\nPayment reference: "
                    + (d == null ? "-" : d[5]),
            "Mark paid",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
    );

    if (ok != JOptionPane.YES_OPTION) return;

    String sql = "UPDATE customer_orders SET payment_status = ? WHERE id = ?";

    try (Connection conn = DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "Paid");
            ps.setInt(2, id);

            if (ps.executeUpdate() > 0) {
                refreshOnlineStations();
            } else {
                warn("Order not found.");
            }
        }

    } catch (SQLException e) {
        warn("Failed to update payment status:\n" + e.getMessage());
    }
}

private void cancelOnlineOrder() {

    int id = selectedOnlineId();

    if (id < 0) {
        info("Select an order first.");
        return;
    }

    int ok = JOptionPane.showConfirmDialog(
            this,
            "Cancel online order #" + id + "?",
            "Cancel order",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (ok == JOptionPane.YES_OPTION
            && updateOnlineStatus(id, "Cancelled")) {

        refreshOnlineStations();
        refreshStats();
    }
}

private void deleteOnlineOrder() {

    int id = selectedOnlineId();

    if (id < 0) {
        info("Select an order first.");
        return;
    }

    String[] d = onlineDetails.get(id);

    int ok = JOptionPane.showConfirmDialog(
            this,
            "Permanently delete order "
                    + (d == null ? "#" + id : d[0])
                    + "?\nThis cannot be undone.",
            "Delete order",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (ok != JOptionPane.YES_OPTION) return;

    try (Connection conn = DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        conn.setAutoCommit(false);

        try (PreparedStatement items = conn.prepareStatement(
                "DELETE FROM order_items WHERE order_id = ?");
             PreparedStatement order = conn.prepareStatement(
                "DELETE FROM customer_orders WHERE id = ?")) {

            items.setInt(1, id);
            items.executeUpdate();

            order.setInt(1, id);
            int deleted = order.executeUpdate();

            if (deleted == 0) {
                conn.rollback();
                warn("Order not found.");
                return;
            }

            conn.commit();

        } catch (SQLException e) {
            conn.rollback();
            throw e;
        }

        refreshOnlineStations();
        refreshStats();

    } catch (SQLException e) {
        warn("Failed to delete order:\n" + e.getMessage());
    }
}

private boolean updateOnlineStatus(int orderId, String newStatus) {

    boolean completed = "Completed".equalsIgnoreCase(newStatus);

    String sql = completed
            ? "UPDATE customer_orders SET order_status = ?, "
              + "completed_by = ? WHERE id = ?"
            : "UPDATE customer_orders SET order_status = ? "
              + "WHERE id = ?";

    try (Connection conn = DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newStatus);

            if (completed) {
                ps.setString(2, cashierName);
                ps.setInt(3, orderId);
            } else {
                ps.setInt(2, orderId);
            }

            if (ps.executeUpdate() > 0) {
                return true;
            }

            warn("Order not found.");
            return false;
        }

    } catch (SQLException e) {
        warn("Failed to update order status:\n" + e.getMessage());
        return false;
    }
}

    private JComponent buildDashboardPage() {
        JPanel p = page();

        p.add(
                pageTitle("CASHIER DASHBOARD"),
                BorderLayout.NORTH
        );

        JPanel grid = new JPanel(new GridLayout(2, 3, 16, 16));
        grid.setOpaque(false);
        grid.setBorder(
                BorderFactory.createEmptyBorder(24, 40, 10, 40)
        );

        dSales = addStat(grid, "TOTAL SALES", ITEM_GREEN);
        dOrders = addStat(grid, "PAID ORDERS", ITEM_GREEN);
        dAvg = addStat(grid, "AVERAGE ORDER", ITEM_GREEN);
        dPending = addStat(grid, "ORDERS NOT YET COMPLETED", PAY_CARD);
        dRefunds = addStat(grid, "REFUNDS", WARN);
        dDrawer = addStat(grid, "EXPECTED CASH IN DRAWER", PAY_GCASH);

        p.add(grid, BorderLayout.CENTER);

        JPanel south = new JPanel();
        south.setOpaque(false);
        south.setLayout(new BoxLayout(south, BoxLayout.Y_AXIS));
        south.setBorder(
                BorderFactory.createEmptyBorder(0, 0, 40, 0)
        );

        south.add(
                centered(
                        "Welcome to the Cashier System, "
                                + cashierName
                                + ".",
                        20,
                        Color.DARK_GRAY
                )
        );

        south.add(Box.createVerticalStrut(12));

        south.add(
                centered(
                        "You can manage orders, update order status, and view sales.",
                        20,
                        Color.DARK_GRAY
                )
        );

        south.add(Box.createVerticalStrut(14));

        dAlert = centered(" ", 16, WARN);

        south.add(dAlert);

        p.add(south, BorderLayout.SOUTH);

        return p;
    }

    private int selectedWalkInId() {

    for (Map.Entry<String, JTable> en : stationTables.entrySet()) {

        JTable table = en.getValue();
        int row = table.getSelectedRow();

        if (row < 0) continue;

        return (Integer) stationModels.get(en.getKey())
                .getValueAt(table.convertRowIndexToModel(row), 0);
    }

    return -1;
}

private Order walkInById(int id) {

    for (Order o : orders) {
        if (o.id == id) return o;
    }

    return null;
}

private void showWalkInReceipt() {

    int id = selectedWalkInId();

    if (id < 0) {
        info("Select an order first.");
        return;
    }

    Order o = walkInById(id);

    if (o == null) {
        warn("Order not found. Press Refresh Orders.");
        return;
    }

    showReceipt(o, null, 0);
}

private void cancelWalkInOrder() {

    int id = selectedWalkInId();

    if (id < 0) {
        info("Select an order first.");
        return;
    }

    Order o = walkInById(id);

    if (o == null) return;

    if (o.refunded) {
        info("This order was already cancelled/refunded.");
        return;
    }

    int ok = JOptionPane.showConfirmDialog(
            this,
            "Cancel and refund order #" + o.id
                    + " (" + money(o.total)
                    + ", paid by " + o.method + ")?",
            "Cancel order",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (ok != JOptionPane.YES_OPTION) return;

    if (!store.markRefunded(o.id)) {
        warn("The shared sales record for receipt #" + o.id
                + " could not be found.");
        return;
    }

    o.refunded = true;

    refreshAll();

    info(o.method == PayMethod.CASH
            ? "Refunded " + money(o.total)
                + ". Give the cash back to the customer."
            : "Refunded " + money(o.total)
                + " to the original payment method.");
}

private void deleteWalkInOrder() {

    int id = selectedWalkInId();

    if (id < 0) {
        info("Select an order first.");
        return;
    }

    Order o = walkInById(id);

    if (o == null) return;

    int ok = JOptionPane.showConfirmDialog(
            this,
            "Remove order #" + o.id + " from this list?\n"
                    + "This cannot be undone.",
            "Delete order",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (ok != JOptionPane.YES_OPTION) return;

    orders.remove(o);

    refreshAll();
}

    private JComponent buildOrdersPage() {
        JPanel p = page();

        p.add(
                pageTitle("ORDERS"),
                BorderLayout.NORTH
        );

        // --- category tabs ---
        CardLayout menuCards = new CardLayout();

        JPanel menuPages = new JPanel(menuCards);
        menuPages.setOpaque(false);

        JPanel tabs = new JPanel(
                new GridLayout(1, categories.size(), 6, 0)
        );

        tabs.setOpaque(false);
        tabs.setPreferredSize(new Dimension(0, 52));

        Map<String, JButton> tabButtons = new LinkedHashMap<>();

        for (Map.Entry<String, Map<String, Double>> cat :
                categories.entrySet()) {

            String catName = cat.getKey();

            JPanel grid = new JPanel(
                    new GridLayout(0, 3, 8, 8)
            );

            grid.setOpaque(false);

            for (Map.Entry<String, Double> en :
                    cat.getValue().entrySet()) {

                String name = en.getKey();

                JButton b = button(
                        "<html><div style='text-align:center'>"
                                + name
                                + "<br>"
                                + money(en.getValue())
                                + "</div></html>",
                        ITEM_GREEN,
                        Color.WHITE,
                        14
                );

                b.setPreferredSize(new Dimension(120, 76));

                b.addActionListener(e -> addToCart(name));

                grid.add(b);
            }

            JPanel gridWrap = new JPanel(new BorderLayout());
            gridWrap.setOpaque(false);
            gridWrap.setBorder(
                    BorderFactory.createEmptyBorder(8, 6, 6, 6)
            );

            gridWrap.add(grid, BorderLayout.NORTH);

            JScrollPane scroll = new JScrollPane(gridWrap);
            scroll.setBorder(BorderFactory.createEmptyBorder());
            scroll.setOpaque(false);
            scroll.getViewport().setOpaque(false);
            scroll.getVerticalScrollBar().setUnitIncrement(16);

            menuPages.add(scroll, catName);

            JButton tab = button(
                    catName,
                    NAV_GRAY,
                    DARK_GREEN,
                    16
            );

            tab.addActionListener(e -> {
                menuCards.show(menuPages, catName);

                for (Map.Entry<String, JButton> tb :
                        tabButtons.entrySet()) {

                    boolean on = tb.getKey().equals(catName);

                    tb.getValue().setBackground(
                            on ? DARK_GREEN : NAV_GRAY
                    );

                    tb.getValue().setForeground(
                            on ? Color.WHITE : DARK_GREEN
                    );
                }
            });

            tabButtons.put(catName, tab);
            tabs.add(tab);
        }

        if (!tabButtons.isEmpty()) {
            tabButtons.values().iterator().next().doClick();
        }

        JPanel itemsScroll = new JPanel(
                new BorderLayout(0, 6)
        );

        itemsScroll.setOpaque(false);
        itemsScroll.setBorder(
                titled("Choose a category, then tap an item")
        );

        itemsScroll.add(tabs, BorderLayout.NORTH);
        itemsScroll.add(menuPages, BorderLayout.CENTER);

        // --- current order ---
        cartTable = new JTable(cartModel);
        styleTable(cartTable);

        JScrollPane cartScroll = new JScrollPane(cartTable);

        cartTotalLabel = new JLabel(
                "TOTAL: " + money(0),
                SwingConstants.RIGHT
        );

        cartTotalLabel.setFont(
                new Font("Arial", Font.BOLD, 26)
        );

        cartTotalLabel.setForeground(DARK_GREEN);
        cartTotalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel edit = new JPanel(
                new GridLayout(1, 4, 6, 6)
        );

        edit.setOpaque(false);

        edit.add(
                actionButton(
                        "+ Qty",
                        NAV_GRAY,
                        DARK_GREEN,
                        e -> changeQty(1)
                )
        );

        edit.add(
                actionButton(
                        "- Qty",
                        NAV_GRAY,
                        DARK_GREEN,
                        e -> changeQty(-1)
                )
        );

        edit.add(
                actionButton(
                        "Void Item",
                        NAV_GRAY,
                        DARK_GREEN,
                        e -> voidSelected()
                )
        );

        edit.add(
                actionButton(
                        "Clear",
                        NAV_GRAY,
                        DARK_GREEN,
                        e -> clearCart()
                )
        );

        JPanel pay = new JPanel(
                new GridLayout(1, 3, 6, 6)
        );

        pay.setOpaque(false);

        pay.add(
                actionButton(
                        "CASH",
                        PAY_CASH,
                        Color.WHITE,
                        e -> pay(PayMethod.CASH)
                        
                )
        );

        pay.add(
                actionButton(
                        "CARD",
                        PAY_CARD,
                        Color.WHITE,
                        e -> pay(PayMethod.CARD)
                )
        );

        pay.add(
                actionButton(
                        "GCASH",
                        PAY_GCASH,
                        Color.WHITE,
                        e -> pay(PayMethod.GCASH)
                )
        );

        pay.setPreferredSize(new Dimension(0, 60));

        JPanel cartSouth = new JPanel();

        cartSouth.setOpaque(false);
        cartSouth.setLayout(
                new BoxLayout(cartSouth, BoxLayout.Y_AXIS)
        );

        JPanel totalRow = new JPanel(new BorderLayout());
        totalRow.setOpaque(false);
        totalRow.add(cartTotalLabel, BorderLayout.CENTER);

        cartSouth.add(totalRow);
        cartSouth.add(Box.createVerticalStrut(6));
        cartSouth.add(edit);
        cartSouth.add(Box.createVerticalStrut(8));
        cartSouth.add(pay);

        JPanel cartPanel = new JPanel(
                new BorderLayout(0, 6)
        );

        cartPanel.setOpaque(false);
        cartPanel.setBorder(titled("Current order"));
        cartPanel.add(cartScroll, BorderLayout.CENTER);
        cartPanel.add(cartSouth, BorderLayout.SOUTH);

        JPanel center = new JPanel(
                new GridLayout(1, 2, 12, 12)
        );

        center.setOpaque(false);
        center.add(itemsScroll);
        center.add(cartPanel);

        p.add(center, BorderLayout.CENTER);

        // --- orders list ---
        ordersTable = new JTable(ordersModel);
        styleTable(ordersTable);

        JScrollPane ordersScroll = new JScrollPane(ordersTable);

        JPanel orderBtns = new JPanel(
                new GridLayout(0, 1, 6, 6)
        );

        orderBtns.setOpaque(false);

        JButton advanceAll = actionButton(
                "<html><div style='text-align:center'>"
                        + "Update Status<br>(all tables)"
                        + "</div></html>",
                ITEM_GREEN,
                Color.WHITE,
                e -> advanceStatus()
        );

        advanceAll.setToolTipText(
                "Moves every preparation table of this order one step forward. "
                        + "Use the PREPARATION page to update one table at a time."
        );

        orderBtns.add(advanceAll);

        orderBtns.add(
                actionButton(
                        "Refund",
                        WARN,
                        Color.WHITE,
                        e -> refund()
                )
        );

        orderBtns.setPreferredSize(
                new Dimension(170, 0)
        );

        JPanel ordersPanel = new JPanel(
                new BorderLayout(8, 0)
        );

        ordersPanel.setOpaque(false);
        ordersPanel.setBorder(
                titled(
                        "Recent orders (select one to update its status or refund it)"
                )
        );

        ordersPanel.add(
                ordersScroll,
                BorderLayout.CENTER
        );

        ordersPanel.add(
                orderBtns,
                BorderLayout.EAST
        );

        ordersPanel.setPreferredSize(
                new Dimension(0, 210)
        );

        p.add(
                ordersPanel,
                BorderLayout.SOUTH
        );

        return p;
    }


    private JComponent buildPreparationPage() {

    JPanel p = page();

    p.add(pageTitle("WALK-IN ORDERS"), BorderLayout.NORTH);

    JPanel row = new JPanel(
            new GridLayout(1, categories.size(), 12, 12)
    );

    row.setOpaque(false);
    row.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));

    for (String cat : categories.keySet()) {

        DefaultTableModel model = readOnlyModel(
                "#", "Time", "Items", "Receipt", "Payment", "Status"
        );

        JTable table = new JTable(model);
        styleTable(table);

        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        table.getColumnModel().getColumn(0).setPreferredWidth(44);
        table.getColumnModel().getColumn(1).setPreferredWidth(52);
        table.getColumnModel().getColumn(2).setPreferredWidth(170);
        table.getColumnModel().getColumn(3).setPreferredWidth(90);
        table.getColumnModel().getColumn(4).setPreferredWidth(130);
        table.getColumnModel().getColumn(5).setPreferredWidth(90);

        stationModels.put(cat, model);
        stationTables.put(cat, table);

        // Only one row can be selected across all three tables.
        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting() || walkInSelAdjusting) return;
            if (table.getSelectedRow() < 0) return;

            walkInSelAdjusting = true;

            for (JTable other : stationTables.values()) {
                if (other != table) other.clearSelection();
            }

            walkInSelAdjusting = false;
        });

        JLabel header = new JLabel(cat, SwingConstants.CENTER);
        header.setOpaque(true);
        header.setBackground(DARK_GREEN);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Arial", Font.BOLD, 18));
        header.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        JButton next = actionButton(
                "Update Status",
                ITEM_GREEN,
                Color.WHITE,
                e -> advanceStation(cat)
        );

        next.setPreferredSize(new Dimension(0, 50));

        JPanel col = new JPanel(new BorderLayout(0, 6));
        col.setOpaque(false);
        col.add(header, BorderLayout.NORTH);
        col.add(new JScrollPane(table), BorderLayout.CENTER);
        col.add(next, BorderLayout.SOUTH);

        row.add(col);
    }

    p.add(row, BorderLayout.CENTER);

    // Bottom bar (same as Online Orders)
    JPanel bottom = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 10, 10)
    );

    bottom.setOpaque(false);

    JButton refresh = actionButton(
            "Refresh Orders", NAV_GRAY, DARK_GREEN,
            e -> refreshAll()
    );

    JButton receipt = actionButton(
            "View Receipt", PAY_CARD, Color.WHITE,
            e -> showWalkInReceipt()
    );

    JButton cancel = actionButton(
            "Cancel Order", PAY_GCASH, Color.WHITE,
            e -> cancelWalkInOrder()
    );

    JButton delete = actionButton(
            "Delete Order", WARN, Color.WHITE,
            e -> deleteWalkInOrder()
    );

    for (JButton b : new JButton[]{refresh, receipt, cancel, delete}) {
        b.setPreferredSize(new Dimension(170, 46));
        bottom.add(b);
    }

    p.add(bottom, BorderLayout.SOUTH);

    return p;
}

    private JComponent buildSalesPage() {
        JPanel p = page();

        p.add(
                pageTitle("SALES"),
                BorderLayout.NORTH
        );

        JPanel grid = new JPanel(
                new GridLayout(2, 3, 14, 14)
        );

        grid.setOpaque(false);
        grid.setBorder(
                BorderFactory.createEmptyBorder(
                        8, 30, 12, 30
                )
        );

        grid.setPreferredSize(
                new Dimension(0, 200)
        );

        sTotal = addStat(
                grid,
                "TOTAL SALES",
                ITEM_GREEN
        );

        sCash = addStat(
                grid,
                "CASH",
                PAY_CASH
        );

        sCard = addStat(
                grid,
                "CARD",
                PAY_CARD
        );

        sGcash = addStat(
                grid,
                "GCASH",
                PAY_GCASH
        );

        sRefunds = addStat(
                grid,
                "REFUNDS",
                WARN
        );

        sVoids = addStat(
                grid,
                "VOIDED ITEMS",
                MUTED
        );

        salesTable = new JTable(salesModel);
        styleTable(salesTable);

        JScrollPane scroll = new JScrollPane(salesTable);

        scroll.setBorder(
                titled("All transactions this shift")
        );

        JPanel middle = new JPanel(
                new BorderLayout()
        );

        middle.setOpaque(false);

        middle.add(
                grid,
                BorderLayout.NORTH
        );

        middle.add(
                scroll,
                BorderLayout.CENTER
        );

        p.add(
                middle,
                BorderLayout.CENTER
        );

        JPanel btns = new JPanel(
                new FlowLayout(
                        FlowLayout.CENTER,
                        14,
                        10
                )
        );

        btns.setOpaque(false);

        JButton in = actionButton(
                "Cash In",
                PAY_CASH,
                Color.WHITE,
                e -> cashMove(true)
        );

        JButton out = actionButton(
                "Cash Out",
                PAY_CARD,
                Color.WHITE,
                e -> cashMove(false)
        );

        JButton close = actionButton(
                "Close Shift",
                WARN,
                Color.WHITE,
                e -> closeShift()
        );

        for (JButton b :
                new JButton[]{in, out, close}) {

            b.setPreferredSize(
                    new Dimension(190, 52)
            );

            btns.add(b);
        }

        p.add(
                btns,
                BorderLayout.SOUTH
        );

        return p;
    }

    // =====================================================================
    // UI helpers
    // =====================================================================

    
private void showPage(String name) {

    cards.show(pages, name);

    for (Map.Entry<String, JButton> en : navButtons.entrySet()) {

        boolean selected = en.getKey().equals(name);

        en.getValue().setBackground(
                selected ? Color.WHITE : NAV_GRAY
        );

        en.getValue().setForeground(DARK_GREEN);
    }

    // Reload customer orders whenever this page is opened.
    if (name.equals("CUSTOMER ORDERS")) {
        refreshOnlineStations();
    }

    if (name.equals("SALES")) {
        refreshOrders();
        refreshStats();
    }
}

    private static JPanel page() {
        JPanel p = new JPanel(
                new BorderLayout()
        );

        p.setBackground(CONTENT_BG);

        p.setBorder(
                BorderFactory.createEmptyBorder(
                        6, 14, 8, 14
                )
        );

        return p;
    }

    private static JLabel pageTitle(String text) {
        JLabel l = new JLabel(
                text,
                SwingConstants.CENTER
        );

        l.setFont(
                new Font("Arial", Font.BOLD, 34)
        );

        l.setForeground(DARK_GREEN);

        l.setBorder(
                BorderFactory.createEmptyBorder(
                        12, 0, 10, 0
                )
        );

        return l;
    }

    private static JLabel centered(
            String text,
            int size,
            Color color) {

        JLabel l = new JLabel(
                text,
                SwingConstants.CENTER
        );

        l.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        size
                )
        );

        l.setForeground(color);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);

        return l;
    }

    private static javax.swing.border.Border titled(
            String text) {

        return BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(
                        new Color(0xB0BEC5)
                ),
                text
        );
    }

    private static JButton button(
            String text,
            Color bg,
            Color fg,
            int size) {

        JButton b = new JButton(text);

        b.setBackground(bg);
        b.setForeground(fg);

        b.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        size
                )
        );

        b.setFocusPainted(false);
        b.setOpaque(true);

        b.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );

        return b;
    }

    private static JButton actionButton(
            String text,
            Color bg,
            Color fg,
            java.awt.event.ActionListener l) {

        JButton b = button(
                text,
                bg,
                fg,
                15
        );

        b.addActionListener(l);

        return b;
    }

    private static JLabel addStat(
            JPanel parent,
            String title,
            Color accent) {

        JPanel card = new JPanel(
                new BorderLayout()
        );

        card.setBackground(Color.WHITE);

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(
                                0, 6, 0, 0, accent
                        ),
                        BorderFactory.createEmptyBorder(
                                10, 14, 10, 14
                        )
                )
        );

        JLabel t = new JLabel(title);

        t.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        t.setForeground(MUTED);

        JLabel v = new JLabel("-");

        v.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        v.setForeground(DARK_GREEN);

        card.add(t, BorderLayout.NORTH);
        card.add(v, BorderLayout.CENTER);

        parent.add(card);

        return v;
    }

    private static void styleTable(JTable t) {
        t.setRowHeight(28);
        t.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        14
                )
        );

        t.getTableHeader().setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        t.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        t.setFillsViewportHeight(true);
    }

    // POLYMORPHISM == Flexible, Reusable and Non-repetitive through method overriding.
    private static DefaultTableModel readOnlyModel(
            String... cols) {

        return new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(
                    int r,
                    int c) {

                return false;
            }
        };
    }

    private static String money(double v) {
        return String.format(
                "%s%,.2f",
                CUR,
                v
        );
    }

    private static Double parseMoney(String s) {
        try {
            double v = Double.parseDouble(
                    s.trim().replace(",", "")
            );

            return v < 0 ? null : v;

        } catch (NumberFormatException |
                 NullPointerException e) {

            return null;
        }
    }

    private void info(String msg) {
        JOptionPane.showMessageDialog(
                this,
                msg,
                "Cashier",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private void warn(String msg) {
        JOptionPane.showMessageDialog(
                this,
                msg,
                "Cashier",
                JOptionPane.WARNING_MESSAGE
        );
    }

    // =====================================================================
    // Actions
    // =====================================================================

    private void addToCart(String name) {

        Double price = catalog.get(name);

        if (price == null) {
            warn(
                    "\"" + name
                            + "\" is no longer available in inventory."
            );

            // Refresh from Admin's current inventory.
            loadCatalog();
            return;
        }

        int row = -1;

        for (int i = 0; i < cart.size(); i++) {

            if (cart.get(i).name.equals(name)) {

                cart.get(i).qty++;
                row = i;

                break;
            }
        }

        if (row < 0) {

            cart.add(
                    new LineItem(
                            name,
                            price,
                            1
                    )
            );

            row = cart.size() - 1;
        }

        refreshCart();

        if (row >= 0 && row < cartTable.getRowCount()) {
            cartTable.setRowSelectionInterval(row, row);
        }
    }

    private void changeQty(int delta) {

        int row = cartTable.getSelectedRow();

        if (row < 0) {
            info(
                    "Select an item in the current order first."
            );

            return;
        }

        LineItem li = cart.get(row);

        if (delta > 0) {

            li.qty++;

        } else {

            voidedItems++;
            voidedAmount += li.price;

            li.qty--;

            if (li.qty <= 0) {
                cart.remove(row);
            }
        }

        refreshCart();
        refreshStats();

        if (row < cart.size()) {
            cartTable.setRowSelectionInterval(row, row);
        }
    }

    private void voidSelected() {

        int row = cartTable.getSelectedRow();

        if (row < 0) {
            info(
                    "Select an item in the current order first."
            );

            return;
        }

        LineItem li = cart.remove(row);

        voidedItems += li.qty;
        voidedAmount += li.total();

        refreshCart();
        refreshStats();
    }

    private void clearCart() {

        if (cart.isEmpty()) return;

        int ok = JOptionPane.showConfirmDialog(
                this,
                "Clear the whole order?",
                "Clear order",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
        );

        if (ok == JOptionPane.YES_OPTION) {

            cart.clear();
            refreshCart();
        }
    }

    private void pay(PayMethod method) {

        System.out.println("PAY METHOD STARTED");

        if (cart.isEmpty()) {
            info(
                    "The order is empty. Tap an item to add it first."
            );

            return;
        }

        /*
         * Refresh the inventory immediately before payment.
         * This allows the cashier to see changes made by Admin
         * before the stock is deducted.
         */
        loadCatalog();

        /*
         * Re-check every cart item against the current inventory.
         */
        Map<String, Integer> quantities =
                new LinkedHashMap<>();

        for (LineItem li : cart) {

            if (!catalog.containsKey(li.name)) {

                warn(
                        "\"" + li.name
                                + "\" was removed from the menu by Admin."
                );

                loadCatalog();
                return;
            }

            quantities.merge(
                    li.name,
                    li.qty,
                    Integer::sum
            );
        }

        /*
         * deductStock() performs the actual all-or-nothing
         * inventory check while HigalaStore is locked.
         *
         * IMPORTANT:
         * We do this only AFTER payment is confirmed below.
         */

        double total = cartTotal();

        Double tendered = null;
        double change = 0;

        if (method == PayMethod.CASH) {

            while (true) {

                String s = JOptionPane.showInputDialog(
                        this,
                        "Total due: "
                                + money(total)
                                + "\nCash received:",
                        "Cash payment",
                        JOptionPane.QUESTION_MESSAGE
                );

                if (s == null) return;

                Double v = parseMoney(s);

                if (v == null) {
                    warn(
                            "Please enter a valid amount."
                    );

                    continue;
                }

                if (v < total) {

                    warn(
                            "Not enough. Short by "
                                    + money(total - v)
                    );

                    continue;
                }

                tendered = v;
                change = v - total;

                break;
            }

        } else {

            int ok = JOptionPane.showConfirmDialog(
                    this,
                    "Charge "
                            + money(total)
                            + " to "
                            + method
                            + "?\nClick OK once the payment is approved.",
                    method + " payment",
                    JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE
            );

            if (ok != JOptionPane.OK_OPTION) {
                return;
            }
        }

        /*
         * Payment has now been confirmed.
         *
         * Deduct inventory atomically.
         */
        String stockError =
                store.deductStock(quantities);

        if (stockError != null) {

            warn(
                    "Payment was NOT completed.\n\n"
                            + stockError
                            + "\n\nPlease check the current inventory."
            );

            // The Admin may have changed stock while this order
            // was being entered.
            loadCatalog();

            return;
        }

        /*
         * Get the receipt number from HigalaStore.
         *
         * The temporary local ID is replaced with the actual
         * shared-store receipt number.
         */
        List<LineItem> finalItems =
                new ArrayList<>();

        for (LineItem li : cart) {
            finalItems.add(
                    new LineItem(
                            li.name,
                            li.price,
                            li.qty
                    )
            );
        }

        HigalaStore.Sale sale =
                new HigalaStore.Sale(
                        LocalDateTime.now(),
                        cashierName,
                        registerNo,
                        orderSummary(finalItems),
                        total,
                        method.toString()
                );

        int receipt = store.addSale(sale);

        nextId = Math.max(
                nextId,
                receipt + 1
        );

        Order o = new Order(
                receipt,
                finalItems,
                total,
                method
        );

        orders.add(o);

        buildTickets(o);

        cart.clear();

        refreshAll();

        showReceipt(
                o,
                tendered,
                change
        );
    }

    private static String orderSummary(
            List<LineItem> items) {

        StringBuilder sb = new StringBuilder();

        for (LineItem li : items) {

            if (sb.length() > 0) {
                sb.append(", ");
            }

            sb.append(li.name)
                    .append(" x")
                    .append(li.qty);
        }

        return sb.toString();
    }

    private void showReceipt(
            Order o,
            Double tendered,
            double change) {

        StringBuilder sb = new StringBuilder();

        sb.append("HIGALA RIDGE\n");

        sb.append("Order #")
                .append(o.id)
                .append("   ")
                .append(o.time.format(DATE_FMT))
                .append('\n');

        sb.append("Cashier: ")
                .append(cashierName)
                .append("   Register ")
                .append(registerNo)
                .append('\n');

        sb.append("------------------------------------------\n");

        for (LineItem li : o.items) {

            sb.append(
                    String.format(
                            "%-16s x%-3d %16s%n",
                            li.name,
                            li.qty,
                            money(li.total())
                    )
            );
        }

        sb.append("------------------------------------------\n");

        sb.append(
                String.format(
                        "%-22s %19s%n",
                        "TOTAL",
                        money(o.total)
                )
        );

        sb.append(
                String.format(
                        "%-22s %19s%n",
                        "Paid by",
                        o.method
                )
        );

        if (tendered != null) {

            sb.append(
                    String.format(
                            "%-22s %19s%n",
                            "Cash received",
                            money(tendered)
                    )
            );

            sb.append(
                    String.format(
                            "%-22s %19s%n",
                            "Change",
                            money(change)
                    )
            );
        }

        sb.append("\nThank you!\n");

        JTextArea area =
                new JTextArea(
                        sb.toString()
                );

        area.setFont(
                new Font(
                        Font.MONOSPACED,
                        Font.PLAIN,
                        13
                )
        );

        area.setEditable(false);

        showReceiptDialog("Receipt #" + o.id, area);
    }

    private void showReceiptDialog(String title, JTextArea area) {

    JButton print = new JButton("Print");
    JButton close = new JButton("Close");

    JOptionPane pane = new JOptionPane(
            new JScrollPane(area),
            JOptionPane.PLAIN_MESSAGE,
            JOptionPane.DEFAULT_OPTION,
            null,
            new Object[]{print, close},
            close
    );

    JDialog dialog = pane.createDialog(this, title);

    print.addActionListener(e -> {
        try {
            area.print();
        } catch (java.awt.print.PrinterException ex) {
            warn("Could not print the receipt:\n" + ex.getMessage());
        }
    });

    close.addActionListener(e -> dialog.dispose());

    dialog.setVisible(true);
}

    private Order selectedOrder(
            JTable table,
            DefaultTableModel model) {

        int row = table.getSelectedRow();

        if (row < 0) {
            info(
                    "Select an order in the table first."
            );

            return null;
        }

        int modelRow =
                table.convertRowIndexToModel(row);

        int id =
                (Integer) model.getValueAt(
                        modelRow,
                        0
                );

        for (Order o : orders) {

            if (o.id == id) {
                return o;
            }
        }

        return null;
    }

    private void reselect(
            JTable table,
            DefaultTableModel model,
            int orderId) {

        for (int r = 0; r < model.getRowCount(); r++) {

            if ((Integer) model.getValueAt(r, 0)
                    == orderId) {

                table.setRowSelectionInterval(r, r);

                return;
            }
        }
    }

    private void advanceStatus() {

        Order o =
                selectedOrder(
                        ordersTable,
                        ordersModel
                );

        if (o == null) return;

        if (o.refunded) {
            info(
                    "This order was refunded."
            );

            return;
        }

        if (o.status() == OrderStatus.COMPLETED) {

            info(
                    "This order is already completed."
            );

            return;
        }

        for (Ticket t : o.tickets) {
            t.status = t.status.next();
        }

        refreshAll();

        reselect(
                ordersTable,
                ordersModel,
                o.id
        );
    }

    // Split a paid order into one ticket per category.
    private void buildTickets(Order o) {

        Map<String, Ticket> byCategory =
                new LinkedHashMap<>();

        for (LineItem li : o.items) {

            String cat =
                    itemCategory.getOrDefault(
                            li.name,
                            "OTHER"
                    );

            byCategory
                    .computeIfAbsent(
                            cat,
                            Ticket::new
                    )
                    .items
                    .add(li);
        }

        o.tickets.addAll(
                byCategory.values()
        );
    }

    // Moves one category ticket one step forward.
    private void advanceStation(String category) {

    JTable table = stationTables.get(category);
    DefaultTableModel model = stationModels.get(category);

    int row = table.getSelectedRow();

    if (row < 0) {
        info("Select an order in the " + category + " table first.");
        return;
    }

    int id = (Integer) model.getValueAt(
            table.convertRowIndexToModel(row), 0
    );

    for (Order o : orders) {

        if (o.id != id) continue;

        if (o.refunded) {
            info("This order was refunded.");
            return;
        }

        for (Ticket t : o.tickets) {

            if (!t.category.equals(category)) continue;

            if (t.status == OrderStatus.COMPLETED) {
                info("This " + category + " order is already completed.");
                return;
            }

            t.status = t.status.next();
        }

        break;
    }

    refreshAll();
}

    private void refund() {

        Order o =
                selectedOrder(
                        ordersTable,
                        ordersModel
                );

        if (o == null) return;

        if (o.refunded) {

            info(
                    "This order was already refunded."
            );

            return;
        }

        int ok =
                JOptionPane.showConfirmDialog(
                        this,
                        "Refund order #"
                                + o.id
                                + " ("
                                + money(o.total)
                                + ", paid by "
                                + o.method
                                + ")?",
                        "Refund",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

        if (ok != JOptionPane.YES_OPTION) {
            return;
        }

        /*
         * Mark the shared sale as refunded FIRST.
         * This keeps the Admin's sales records consistent.
         */
        boolean saved =
                store.markRefunded(o.id);

        if (!saved) {

            warn(
                    "The shared sales record for receipt #"
                            + o.id
                            + " could not be found."
            );

            return;
        }

        o.refunded = true;

        refreshAll();

        reselect(
                ordersTable,
                ordersModel,
                o.id
        );

        info(
                o.method == PayMethod.CASH
                        ? "Refunded "
                                + money(o.total)
                                + ". Give the cash back to the customer."
                        : "Refunded "
                                + money(o.total)
                                + " to the original payment method."
        );
    }

    private void cashMove(boolean in) {

        String s =
                JOptionPane.showInputDialog(
                        this,
                        in
                                ? "Cash in amount (add to drawer):"
                                : "Cash out amount (paid-out / drop):",
                        in
                                ? "Cash in"
                                : "Cash out",
                        JOptionPane.QUESTION_MESSAGE
                );

        if (s == null) return;

        Double v =
                parseMoney(s);

        if (v == null || v == 0) {

            warn(
                    "Please enter a valid amount."
            );

            return;
        }

        if (!in && v > expectedCash()) {

            warn(
                    "Not enough cash in the drawer."
            );

            return;
        }

        if (in) {
            cashIn += v;
        } else {
            cashOut += v;
        }

        refreshAll();

        info(
                (in
                        ? "Cash in recorded: "
                        : "Cash out recorded: ")
                        + money(v)
        );
    }

    private void closeShift() {

        int ok =
                JOptionPane.showConfirmDialog(
                        this,
                        "Close the shift and count the drawer?",
                        "Close shift",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE
                );

        if (ok != JOptionPane.YES_OPTION) {
            return;
        }

        double counted;

        while (true) {

            String s =
                    JOptionPane.showInputDialog(
                            this,
                            "Expected cash in drawer: "
                                    + money(expectedCash())
                                    + "\nCounted cash:",
                            "Count drawer",
                            JOptionPane.QUESTION_MESSAGE
                    );

            if (s == null) return;

            Double v =
                    parseMoney(s);

            if (v == null) {

                warn(
                        "Please enter a valid amount."
                );

                continue;
            }

            counted = v;

            break;
        }

        double diff =
                counted - expectedCash();

        String result =
                Math.abs(diff) < 0.005
                        ? "Balanced"
                        : diff > 0
                        ? "OVER by " + money(diff)
                        : "SHORT by " + money(-diff);

        double sales = 0;
        int count = 0;

        for (Order o : orders) {

            if (!o.refunded) {

                sales += o.total;
                count++;
            }
        }

        String summary =
                "END OF SHIFT\n\n"
                        + "Paid orders:   " + count + "\n"
                        + "Total sales:   " + money(sales) + "\n"
                        + "Expected cash: " + money(expectedCash()) + "\n"
                        + "Counted cash:  " + money(counted) + "\n"
                        + "Result:        " + result + "\n\n"
                        + "Goodbye, " + cashierName + "!";

        JTextArea area =
                new JTextArea(summary);

        area.setFont(
                new Font(
                        Font.MONOSPACED,
                        Font.PLAIN,
                        14
                )
        );

        area.setEditable(false);

        JOptionPane.showMessageDialog(
                this,
                area,
                "Shift closed",
                JOptionPane.INFORMATION_MESSAGE
        );

        dispose();
        System.exit(0);
    }

    private void confirmExit() {

        if (orders.isEmpty()) {
            System.exit(0);
        }

        int ok =
                JOptionPane.showConfirmDialog(
                        this,
                        "Exit without closing the shift?\n"
                                + "This session's orders are not saved.",
                        "Exit",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

        if (ok == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    // =====================================================================
    // Calculations & refresh
    // =====================================================================

    private double getTotalSalesFromDatabase() {
    String sql = "SELECT COALESCE(SUM(total_amount), 0) " +
                 "FROM customer_orders " +
                 "WHERE order_status = 'Completed'";

    try (java.sql.Connection conn = DatabaseConnection.getConnection();
         java.sql.PreparedStatement stmt = conn.prepareStatement(sql);
         java.sql.ResultSet rs = stmt.executeQuery()) {

        if (rs.next()) {
            return rs.getDouble(1);
        }

    } catch (java.sql.SQLException e) {
        e.printStackTrace();
    }

    return 0;
}

    private double cartTotal() {

        double t = 0;

        for (LineItem li : cart) {
            t += li.total();
        }

        return t;
    }

    private double expectedCash() {

        double cash = 0;

        for (Order o : orders) {

            if (!o.refunded
                    && o.method == PayMethod.CASH) {

                cash += o.total;
            }
        }

        return openingFloat
                + cash
                + cashIn
                - cashOut;
    }

    private void refreshAll() {
        loadCatalog();

        refreshCart();
        refreshOrders();
        refreshStations();
        refreshStats();
    }

    
private void refreshStations() {

    int keepId = selectedWalkInId();

    for (DefaultTableModel model : stationModels.values()) {
        model.setRowCount(0);
    }

    for (int i = orders.size() - 1; i >= 0; i--) {

        Order o = orders.get(i);

        for (Ticket t : o.tickets) {

            DefaultTableModel model = stationModels.get(t.category);

            if (model == null) continue;

            model.addRow(new Object[] {
                o.id,
                o.time.format(SHORT_TIME),
                t.summary(),
                "R-" + o.id,
                o.refunded ? "Refunded" : o.method + " - Paid",
                o.refunded ? "Refunded" : t.status.toString()
            });
        }
    }

    if (keepId > 0) {
        for (String cat : stationTables.keySet()) {
            reselect(stationTables.get(cat), stationModels.get(cat), keepId);
        }
    }
}


    private void refreshCart() {

        cartModel.setRowCount(0);

        for (LineItem li : cart) {

            cartModel.addRow(
                    new Object[]{
                            li.name,
                            li.qty,
                            money(li.price),
                            money(li.total())
                    }
            );
        }

        cartTotalLabel.setText(
                "TOTAL: " + money(cartTotal())
        );
    }

    
private void refreshOrders() {

    ordersModel.setRowCount(0);
    salesModel.setRowCount(0);

    int shown = 0;

    // 1. Load the cashier's existing transactions.
    for (int i = orders.size() - 1; i >= 0; i--) {

        Order o = orders.get(i);

        Object[] row = {
            o.id,
            o.time.format(TIME_FMT),
            o.summary(),
            money(o.total),
            o.method,
            o.statusText()
        };

        salesModel.addRow(row);

        if (shown++ < 15) {
            ordersModel.addRow(row);
        }
    }

    // 2. Load customer orders from the database.
    String sql =
            "SELECT co.order_number, co.order_date, "
          + "GROUP_CONCAT(CONCAT(oi.product_name, ' x', "
          + "oi.quantity) SEPARATOR ', ') AS items, "
          + "co.total_amount, co.payment_method, "
          + "co.order_status "
          + "FROM customer_orders co "
          + "LEFT JOIN order_items oi ON co.id = oi.order_id "
          + "GROUP BY co.id, co.order_number, co.order_date, "
          + "co.total_amount, co.payment_method, co.order_status "
          + "ORDER BY co.id DESC";

    try (Connection conn = DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new SQLException("Database connection failed.");
        }

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                String items = rs.getString("items");

                if (items == null || items.trim().isEmpty()) {
                    items = "No items";
                }

                java.sql.Timestamp timestamp =
                        rs.getTimestamp("order_date");

                String time = timestamp == null
                        ? "N/A"
                        : timestamp.toLocalDateTime().format(TIME_FMT);

                Object[] customerRow = {
                    rs.getString("order_number"),
                    time,
                    items,
                    money(rs.getDouble("total_amount")),
                    rs.getString("payment_method"),
                    rs.getString("order_status")
                };

                // Add the customer order to the same Sales table.
                salesModel.addRow(customerRow);
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Failed to load customer transactions:\n" + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    private void refreshStats() {

        int count = 0;
        int notDone = 0;
        int refundCount = 0;

        double totalSales = getTotalSalesFromDatabase();
        double sales = 0;
        double cash = 0;
        double card = 0;
        double Gcash = 0;
        double refundAmt = 0;

        for (Order o : orders) {

            if (o.refunded) {

                refundCount++;
                refundAmt += o.total;

                continue;
            }

            count++;
            sales += o.total;

            if (o.status() != OrderStatus.COMPLETED) {
                notDone++;
            }

            switch (o.method) {

                case CASH:
                    cash += o.total;
                    break;

                case CARD:
                    card += o.total;
                    break;

                default:
                    Gcash += o.total;
                    break;
            }
        }

        sales += totalSales;
        double avg =
                count == 0
                        ? 0
                        : sales / count;

        double drawer =
                expectedCash();

        dSales.setText(
                money(sales)
        );

        dOrders.setText(
                String.valueOf(count)
        );

        dAvg.setText(
                money(avg)
        );

        dPending.setText(
                String.valueOf(notDone)
        );

        dRefunds.setText(
                refundCount
                        + "  ("
                        + money(refundAmt)
                        + ")"
        );

        dDrawer.setText(
                money(drawer)
        );

        dAlert.setText(
                drawer < LOW_CASH
                        ? "ALERT: Low cash in drawer. "
                                + "Consider asking for change."
                        : " "
        );

        sTotal.setText(
                money(sales)
        );

        sCash.setText(
                money(cash)
        );

        sCard.setText(
                money(card)
        );

        sGcash.setText(
                money(Gcash)
        );

        sRefunds.setText(
                refundCount
                        + "  ("
                        + money(refundAmt)
                        + ")"
        );

        sVoids.setText(
                voidedItems
                        + "  ("
                        + money(voidedAmount)
                        + ")"
        );
    }

    public static void startForCashier(String cashierName) {
    HigalaCashierApp app = new HigalaCashierApp(cashierName, 1000);

    app.setVisible(true);
}

    // =====================================================================
    // Entry point
    // =====================================================================


    
    public static void main(String[] args) {

    try {
        UIManager.setLookAndFeel(
                UIManager.getCrossPlatformLookAndFeelClassName()
        );
    } catch (Exception ignored) {
    }

    SwingUtilities.invokeLater(() -> {

        String cashierName = "Cashier";
        double openingFloat = 1000;

        if (args.length >= 1 && !args[0].trim().isEmpty()) {
            cashierName = args[0].trim();
        }

        HigalaCashierApp app = new HigalaCashierApp(
                cashierName,
                openingFloat
        );

        app.setVisible(true);
    });
}
}
