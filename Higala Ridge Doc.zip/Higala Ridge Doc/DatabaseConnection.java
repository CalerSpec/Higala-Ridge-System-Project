import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/pos_system";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    public static Connection getConnection() {
        try {
            // ABSTRACTION == Hides complex processes that the system does.
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            // System.out.println("Database connected successfully!");
            return connection;
        } catch (SQLException e) {
            // System.out.println("Database connection failed!");
            e.printStackTrace();
            return null;
        }
    }
}