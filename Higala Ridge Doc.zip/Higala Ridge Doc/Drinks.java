import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

public class Drinks extends JPanel {

    private final Color FOREST_CODE = new Color(7, 94, 70);
    private final Color MINT_FOG = new Color(232, 255, 242);
    private final Color SOFT_CREAM = new Color(245, 245, 220);

    private JPanel productPanel;

    public Drinks() {

        // ==========================================
        // PRODUCT PANEL
        // ==========================================

        productPanel = new JPanel(new GridLayout(0, 3, 15, 20));
        productPanel.setBackground(MINT_FOG);

        loadProducts();

        // ==========================================
        // DRINK IMAGES
        // ==========================================

        String[] drinkFoods = {
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Coke Mismo.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Sprite Mismo.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Royal Mismo.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Royal 1.5L.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Mountain Dew.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Coke 1.5L.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Sprite 1.5L.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Nature Spring 1L.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Nature Spring 500ML.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Sting.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Cobra Energy Drink.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\C2 Apple.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Minute Maid Orange.png",
            "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Minute Maid Apple.png",
        };

        // ==========================================
        // PRODUCT NAMES
        // ==========================================

        String[] productNames = {
            "Coke Mismo",
            "Sprite Mismo",
            "Royal Mismo",
            "Royal 1.5L",
            "Mountain Dew",
            "Coke 1.5L",
            "Sprite 1.5L",
            "Nature Spring 1L",
            "Nature Spring 500ML",
            "Sting",
            "Cobra",
            "C2 Apple",
            "Minute Maid Orange",
            "Minute Maid Apple"
        };

        // ==========================================
        // PRODUCT PRICES
        // ==========================================

        double[] productValue = {
            30.00,
            30.00,
            30.00,
            80.00,
            30.00,
            80.00,
            80.00,
            25.00,
            10.00,
            30.00,
            30.00,
            20.00,
            15.00,
            15.00
        };

        // ==========================================
        // PRODUCT CARDS
        // ==========================================

        for (int i = 0; i < drinkFoods.length; i++) {

            JPanel productCard = new JPanel();

            productCard.setLayout(
                    new BoxLayout(productCard, BoxLayout.Y_AXIS)
            );

            productCard.setBackground(SOFT_CREAM);

            productCard.setBorder(
                    BorderFactory.createEmptyBorder(
                            8, 8, 8, 8
                    )
            );

            // ------------------------------------------
            // IMAGE
            // ------------------------------------------

        JLabel imageLabel = new JLabel();
        imageLabel.setPreferredSize(new Dimension(70, 70));
        imageLabel.setMinimumSize(new Dimension(70, 70));
        imageLabel.setMaximumSize(new Dimension(70, 70));
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        ImageIcon icon = new ImageIcon(drinkFoods[i]);

        if (icon.getIconWidth() > 0) {

        Image resized = icon.getImage().getScaledInstance(
            70, 70, Image.SCALE_SMOOTH
        );

        imageLabel.setIcon(new ImageIcon(resized));

        } else {
                System.out.println("Image not found: " + drinkFoods[i]);
        }

            // ------------------------------------------
            // NAME
            // ------------------------------------------

            JLabel nameLabel =
                    new JLabel(productNames[i]);

            nameLabel.setFont(
                    new Font("Arial", Font.BOLD, 12)
            );

            nameLabel.setAlignmentX(
                    Component.CENTER_ALIGNMENT
            );

            // ------------------------------------------
            // PRICE
            // ------------------------------------------

            JLabel priceLabel =
                    new JLabel(
                            "₱" + String.format(
                                    "%.2f",
                                    productValue[i]
                            )
                    );

            priceLabel.setFont(
                    new Font("Arial", Font.PLAIN, 12)
            );

            priceLabel.setAlignmentX(
                    Component.CENTER_ALIGNMENT
            );

            // ------------------------------------------
            // ADD TO CART BUTTON
            // ------------------------------------------

            JButton addButton =
                    new JButton("Add to Cart");

            addButton.setBackground(FOREST_CODE);
            addButton.setForeground(Color.WHITE);

            addButton.setFont(
                    new Font("Arial", Font.BOLD, 11)
            );

            addButton.setFocusPainted(false);

            addButton.setCursor(
                    Cursor.getPredefinedCursor(
                            Cursor.HAND_CURSOR
                    )
            );

            addButton.setAlignmentX(
                    Component.CENTER_ALIGNMENT
            );

            // Save current product information
            final String productName = productNames[i];
            final double productPrice = productValue[i];

            addButton.addActionListener(e ->
                    showProductOptions(
                            productName,
                            productPrice
                    )
            );

            // ------------------------------------------
            // ADD COMPONENTS TO CARD
            // ------------------------------------------

            productCard.add(imageLabel);

            productCard.add(
                    Box.createVerticalStrut(5)
            );

            productCard.add(nameLabel);

            productCard.add(
                    Box.createVerticalStrut(2)
            );

            productCard.add(priceLabel);

            productCard.add(
                    Box.createVerticalStrut(6)
            );

            productCard.add(addButton);

            productPanel.add(productCard);
        }

        // ==========================================
        // HEADER
        // ==========================================

        JPanel header =
                new JPanel(new BorderLayout());

        header.setBackground(MINT_FOG);

        // ------------------------------------------
        // TITLE
        // ------------------------------------------

        JLabel title =
                new JLabel("DRINKS");

        title.setFont(
                new Font("Arial", Font.BOLD, 28)
        );

        title.setForeground(FOREST_CODE);

        title.setHorizontalAlignment(
                SwingConstants.CENTER
        );

        // ------------------------------------------
        // CART BUTTON
        // ------------------------------------------

        JButton cartButton =
                new JButton("CART");

        cartButton.setFont(
                new Font("Arial", Font.BOLD, 15)
        );

        cartButton.setBackground(FOREST_CODE);
        cartButton.setForeground(Color.WHITE);
        cartButton.setFocusPainted(false);

        cartButton.setCursor(
                Cursor.getPredefinedCursor(
                        Cursor.HAND_CURSOR
                )
        );

        // Open Cart.java
        cartButton.addActionListener(e -> {
            new Cart();
        });

        // Title in center, cart on right
        header.add(
                title,
                BorderLayout.CENTER
        );

        header.add(
                cartButton,
                BorderLayout.EAST
        );

        // ==========================================
        // MAIN PANEL
        // ==========================================

        JPanel insidePanel =
                new JPanel(
                        new BorderLayout(0, 15)
                );

        insidePanel.setBackground(MINT_FOG);

        insidePanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 25, 20, 25
                )
        );

        insidePanel.add(
                header,
                BorderLayout.NORTH
        );

        // ------------------------------------------
        // SCROLLABLE PRODUCT AREA
        // ------------------------------------------
        
        class WidthTrackingPanel extends JPanel implements Scrollable {
                WidthTrackingPanel() { super(new BorderLayout()); }

                public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
                public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 16; }
                public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return 64; }
                public boolean getScrollableTracksViewportWidth() { return true; }
                public boolean getScrollableTracksViewportHeight() { return false; }
        }

JPanel wrapper = new WidthTrackingPanel();
wrapper.setBackground(MINT_FOG);
wrapper.add(productPanel, BorderLayout.NORTH);

JScrollPane scrollPane = new JScrollPane(
        wrapper,
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
);
scrollPane.setBorder(null);

        insidePanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        setLayout(new BorderLayout());

        add(
                insidePanel,
                BorderLayout.CENTER
        );
    }

    // =========================================================
// LOAD DRINKS FROM MYSQL
// =========================================================

private void loadProducts() {

    productPanel.removeAll();
    productPanel.setLayout(new GridLayout(0, 3, 15, 20));
    productPanel.setBackground(MINT_FOG);

    String sql =
            "SELECT product_id, product_name, price, image_path " +
            "FROM products " +
            "WHERE category_id = ? " +
            "AND is_available = 1 " +
            "AND stock_quantity > 0 " +
            "ORDER BY product_id";

    try (
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)
    ) {

        // Drinks category ID
        ps.setInt(1, 3);

        try (ResultSet rs = ps.executeQuery()) {

            boolean found = false;

            while (rs.next()) {

                found = true;

                int productId = rs.getInt("product_id");
                String productName = rs.getString("product_name");
                double productPrice = rs.getDouble("price");
                String imagePath = rs.getString("image_path");

                addProductCard(
                        productId,
                        productName,
                        productPrice,
                        imagePath
                );
            }

            if (!found) {
                JLabel emptyLabel = new JLabel(
                        "No drinks are currently available.",
                        SwingConstants.CENTER
                );

                emptyLabel.setFont(
                        new Font("Arial", Font.PLAIN, 16)
                );

                productPanel.setLayout(new BorderLayout());
                productPanel.add(emptyLabel, BorderLayout.CENTER);
            }
        }

    } catch (SQLException ex) {

        ex.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Unable to load drinks from the database.\n"
                        + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }

    productPanel.revalidate();
    productPanel.repaint();
}

// =========================================================
// PRODUCT CARD
// =========================================================

private void addProductCard(
        int productId,
        String productName,
        double productPrice,
        String imagePath) {

    JPanel productCard = new JPanel();

    productCard.setLayout(
            new BoxLayout(productCard, BoxLayout.Y_AXIS)
    );

    productCard.setBackground(SOFT_CREAM);

    productCard.setBorder(
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
    );

    // IMAGE
    JLabel imageLabel = new JLabel();
    imageLabel.setPreferredSize(new Dimension(70, 70));
    imageLabel.setMinimumSize(new Dimension(70, 70));
    imageLabel.setMaximumSize(new Dimension(70, 70));
    imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    if (imagePath != null && !imagePath.trim().isEmpty()) {

        ImageIcon icon = new ImageIcon(imagePath);

        if (icon.getIconWidth() > 0) {

            Image resized = icon.getImage().getScaledInstance(
                    70, 70, Image.SCALE_SMOOTH
            );

            imageLabel.setIcon(new ImageIcon(resized));

        } else {
            System.out.println("Image not found: " + imagePath);
        }
    }

    // NAME
    JLabel nameLabel = new JLabel(productName);
    nameLabel.setFont(new Font("Arial", Font.BOLD, 12));
    nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    // PRICE
    JLabel priceLabel = new JLabel(
            String.format("₱%.2f", productPrice)
    );

    priceLabel.setFont(new Font("Arial", Font.PLAIN, 12));
    priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

    // ADD TO CART
    JButton addButton = new JButton("Add to Cart");

    addButton.setBackground(FOREST_CODE);
    addButton.setForeground(Color.WHITE);
    addButton.setFont(new Font("Arial", Font.BOLD, 11));
    addButton.setFocusPainted(false);
    addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
    addButton.setCursor(
            Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
    );

    addButton.addActionListener(e ->
            addProductToCart(
                    productId,
                    productName,
                    productPrice
            )
    );

    productCard.add(imageLabel);
    productCard.add(Box.createVerticalStrut(5));
    productCard.add(nameLabel);
    productCard.add(Box.createVerticalStrut(2));
    productCard.add(priceLabel);
    productCard.add(Box.createVerticalStrut(6));
    productCard.add(addButton);

    productPanel.add(productCard);
}

// =========================================================
// CHECK PRODUCT BEFORE ADDING TO CART
// =========================================================

private void addProductToCart(
        int productId,
        String displayedName,
        double displayedPrice) {

    String sql =
            "SELECT product_name, price, stock_quantity, is_available " +
            "FROM products WHERE product_id = ?";

    try (
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)
    ) {

        ps.setInt(1, productId);

        try (ResultSet rs = ps.executeQuery()) {

            if (!rs.next()) {
                JOptionPane.showMessageDialog(
                        this,
                        "This drink no longer exists.",
                        "Product Unavailable",
                        JOptionPane.WARNING_MESSAGE
                );

                loadProducts();
                return;
            }

            String currentName = rs.getString("product_name");
            double currentPrice = rs.getDouble("price");
            int stock = rs.getInt("stock_quantity");
            boolean available = rs.getBoolean("is_available");

            if (!available || stock <= 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "This drink is unavailable or out of stock.",
                        "Product Unavailable",
                        JOptionPane.WARNING_MESSAGE
                );

                loadProducts();
                return;
            }

            if (!displayedName.equals(currentName)
                    || Double.compare(displayedPrice, currentPrice) != 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "This drink has been updated by the admin.\n"
                                + "The product list will refresh. Please select it again.",
                        "Product Updated",
                        JOptionPane.INFORMATION_MESSAGE
                );

                loadProducts();
                return;
            }

            showProductOptions(currentName, currentPrice);
        }

    } catch (SQLException ex) {

        ex.printStackTrace();

        JOptionPane.showMessageDialog(
                this,
                "Unable to verify the drink.\n" + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    // =========================================================
    // PRODUCT OPTIONS
    // =========================================================

    private void showProductOptions(
            String productName,
            double price) {

        JPanel panel = new JPanel();

        panel.setLayout(
                new BoxLayout(
                        panel,
                        BoxLayout.Y_AXIS
                )
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 10, 10, 10
                )
        );

        // ------------------------------------------
        // PRODUCT NAME
        // ------------------------------------------

        JLabel productLabel =
                new JLabel(productName);

        productLabel.setFont(
                new Font("Arial", Font.BOLD, 20)
        );

        productLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panel.add(productLabel);

        panel.add(
                Box.createVerticalStrut(15)
        );

        // ------------------------------------------
        // QUANTITY
        // ------------------------------------------

        JLabel quantityLabel =
                new JLabel("Quantity:");

        quantityLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        SpinnerNumberModel quantityModel =
                new SpinnerNumberModel(
                        1,
                        1,
                        99,
                        1
                );

        JSpinner quantitySpinner =
                new JSpinner(quantityModel);

        quantitySpinner.setMaximumSize(
                new Dimension(100, 30)
        );

        quantitySpinner.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panel.add(quantityLabel);

        panel.add(
                Box.createVerticalStrut(5)
        );

        panel.add(quantitySpinner);

        // ------------------------------------------
        // FLAVOR
        // ------------------------------------------
        // Drinks currently have no flavor selection.
        // If you need flavors later, add them here.
        // ------------------------------------------

        String flavor = "";

        // ------------------------------------------
        // SHOW DIALOG
        // ------------------------------------------

        int result =
                JOptionPane.showConfirmDialog(
                        this,
                        panel,
                        "Add to Cart",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.PLAIN_MESSAGE
                );

        // ------------------------------------------
        // ADD TO CARTMANAGER
        // ------------------------------------------

        if (result == JOptionPane.OK_OPTION) {

            int quantity =
                    (Integer) quantitySpinner.getValue();

            CartManager.addItem(
                    productName,
                    price,
                    quantity,
                    flavor
            );

            JOptionPane.showMessageDialog(
                    this,
                    quantity
                            + " x "
                            + productName
                            + "\n\nAdded to cart!",
                    "Cart",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }
}