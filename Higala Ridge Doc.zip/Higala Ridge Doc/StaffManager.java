import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class StaffManager {

    private static final int ITERATIONS = 65536;
    private static final int KEY_LENGTH = 256;
    private static final int SALT_LENGTH = 16;

    // Information returned after a successful login
    public static class StaffAccount {
        public int staffId;
        public String cashierName;
        public String position;
        public String contact;
        public boolean active;

        public StaffAccount(int staffId, String cashierName,
                            String position, String contact, boolean active) {
            this.staffId = staffId;
            this.cashierName = cashierName;
            this.position = position;
            this.contact = contact;
            this.active = active;
        }
    }

    // Hash a password before saving it to MySQL
    private String hashPassword(String password) throws Exception {
        byte[] salt = new byte[SALT_LENGTH];
        new SecureRandom().nextBytes(salt);

        PBEKeySpec spec = new PBEKeySpec(
            password.toCharArray(), salt, ITERATIONS, KEY_LENGTH
        );

        try {
            SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash = factory.generateSecret(spec).getEncoded();

            return "pbkdf2$" + ITERATIONS + "$"
                + Base64.getEncoder().encodeToString(salt) + "$"
                + Base64.getEncoder().encodeToString(hash);

        } finally {
            spec.clearPassword();
        }
    }

    // Verify the entered password against the stored hash
    private boolean verifyPassword(String password, String storedHash)
            throws Exception {

        String[] parts = storedHash.split("\\$");

        if (parts.length != 4 || !parts[0].equals("pbkdf2")) {
            return false;
        }

        int iterations = Integer.parseInt(parts[1]);
        byte[] salt = Base64.getDecoder().decode(parts[2]);
        byte[] expectedHash = Base64.getDecoder().decode(parts[3]);

        PBEKeySpec spec = new PBEKeySpec(
            password.toCharArray(), salt, iterations,
            expectedHash.length * 8
        );

        try {
            SecretKeyFactory factory =
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] actualHash = factory.generateSecret(spec).getEncoded();

            return java.security.MessageDigest.isEqual(
                expectedHash, actualHash
            );

        } finally {
            spec.clearPassword();
        }
    }

    // Register a new cashier
    // Returns true if registered, false if the username already exists
    public boolean registerCashier(String cashierName, String password, String contact)
            throws SQLException {

        if (cashierName == null || cashierName.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter a cashier username.");
        }

        if (password == null || password.length() < 8) {
            throw new IllegalArgumentException(
                "Password must contain at least 8 characters."
            );
        }

        String name = cashierName.trim();
        String passwordHash;

        try {
            passwordHash = hashPassword(password);
        } catch (Exception e) {
            throw new SQLException("Could not secure the password.", e);
        }

        String sql = "INSERT INTO staff "
            + "(cashier_name, password_hash, position, contact, active) "
            + "VALUES (?, ?, 'Cashier', ?, TRUE)";

        try (Connection conn = DatabaseConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Could not connect to the database.");
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, name);
                stmt.setString(2, passwordHash);
                stmt.setString(3,
                    contact == null || contact.trim().isEmpty()
                        ? null : contact.trim());

                stmt.executeUpdate();
                return true;
            }

        } catch (SQLIntegrityConstraintViolationException e) {
            return false;
        }
    }

    // Log in a cashier
    // Returns the account if successful; otherwise returns null
    public StaffAccount login(String cashierName, String password)
            throws SQLException {

        if (cashierName == null || password == null
                || cashierName.trim().isEmpty() || password.isEmpty()) {
            return null;
        }

        String sql = "SELECT staff_id, cashier_name, password_hash, "
            + "position, contact, active "
            + "FROM staff WHERE cashier_name = ? AND position = 'Cashier'";

        try (Connection conn = DatabaseConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Could not connect to the database.");
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, cashierName.trim());

                try (ResultSet rs = stmt.executeQuery()) {

                    if (!rs.next()) {
                        return null;
                    }

                    String storedHash = rs.getString("password_hash");

                    boolean passwordCorrect;
                    try {
                        passwordCorrect =
                            verifyPassword(password, storedHash);
                    } catch (Exception e) {
                        throw new SQLException(
                            "Could not verify the stored password.", e
                        );
                    }

                    if (!passwordCorrect || !rs.getBoolean("active")) {
                        return null;
                    }

                    return new StaffAccount(
                        rs.getInt("staff_id"),
                        rs.getString("cashier_name"),
                        rs.getString("position"),
                        rs.getString("contact"),
                        rs.getBoolean("active")
                    );
                }
            }
        }
    }

    // Load staff accounts for the Admin Staff table
    public List<StaffAccount> loadStaff() throws SQLException {

        List<StaffAccount> staffList = new ArrayList<>();

        String sql = "SELECT staff_id, cashier_name, position, contact, active "
            + "FROM staff ORDER BY staff_id";

        try (Connection conn = DatabaseConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Could not connect to the database.");
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    staffList.add(new StaffAccount(
                        rs.getInt("staff_id"),
                        rs.getString("cashier_name"),
                        rs.getString("position"),
                        rs.getString("contact"),
                        rs.getBoolean("active")
                    ));
                }
            }
        }

        return staffList;
    }

    // Activate or deactivate a staff account
    public boolean setActive(int staffId, boolean active)
            throws SQLException {

        String sql = "UPDATE staff SET active = ? WHERE staff_id = ? "
            + "AND position = 'Cashier'";

        try (Connection conn = DatabaseConnection.getConnection()) {

            if (conn == null) {
                throw new SQLException("Could not connect to the database.");
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setBoolean(1, active);
                stmt.setInt(2, staffId);

                return stmt.executeUpdate() > 0;
            }
        }
    }

    
    // Edit staff account details
    public boolean updateStaff(
            int staffId,
            String cashierName,
            String position,
            String contact) throws SQLException {

        if (cashierName == null || cashierName.trim().isEmpty()) {
            throw new IllegalArgumentException("Enter a staff name.");
        }

        String sql = "UPDATE staff SET cashier_name = ?, "
                + "position = ?, contact = ? WHERE staff_id = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) {
                throw new SQLException("Database connection failed.");
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, cashierName.trim());
                stmt.setString(2, position);
                stmt.setString(3,
                    contact == null || contact.trim().isEmpty()
                        ? null : contact.trim());
                stmt.setInt(4, staffId);

                return stmt.executeUpdate() > 0;
            }
        }
    }

    // Remove a staff account
    public boolean removeStaff(int staffId) throws SQLException {
        String sql = "DELETE FROM staff WHERE staff_id = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {
            if (conn == null) {
                throw new SQLException("Database connection failed.");
            }

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, staffId);
                return stmt.executeUpdate() > 0;
            }
        }
    }

    // Register staff with a selected role
    public boolean registerStaff(
            String name, String password, String role, String contact)
            throws SQLException {

        if (role == null ||
                !java.util.Arrays.asList(HigalaStore.ROLES).contains(role)) {
            throw new IllegalArgumentException("Select a valid staff role.");
        }

        if (!"Cashier".equals(role)) {
            throw new IllegalArgumentException(
                "This registration method currently supports Cashier accounts only."
            );
        }

        return registerCashier(name, password, contact);
    }

}
