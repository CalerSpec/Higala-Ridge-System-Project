        import java.awt.*;
        import java.awt.event.WindowAdapter;
        import java.awt.event.WindowEvent;
        import java.io.File;
        import java.io.FileWriter;
        import java.io.IOException;
        import java.io.PrintWriter;
        import java.time.LocalDate;
        import java.time.LocalDateTime;
        import java.time.format.DateTimeFormatter;
        import java.util.ArrayList;
        import java.util.Comparator;
        import java.util.LinkedHashMap;
        import java.util.List;
        import java.util.Map;
        import java.util.Properties;
        import javax.swing.*;
        import javax.swing.table.DefaultTableModel;


        public class HigalaAdminApp extends JFrame {

        private static final long serialVersionUID = 1L;

        // ================================================================
        // LOOK
        // ================================================================

        private static final Color HEADER_GREEN = new Color(0x2E6B34);
        private static final Color SIDEBAR_GREEN = new Color(0x2A5A2E);
        private static final Color DARK_GREEN = new Color(0x1E4D2B);
        private static final Color CONTENT_BG = new Color(0xECEFF1);
        private static final Color NAV_GRAY = new Color(0xC9CDC9);
        private static final Color ITEM_GREEN = new Color(0x3F8A48);

        private static final Color PAY_CASH = new Color(0x2E7D32);
        private static final Color PAY_CARD = new Color(0x1565C0);
        private static final Color PAY_GCASH = new Color(0x6A1B9A);

        private static final Color WARN = new Color(0xC62828);
        private static final Color AMBER = new Color(0xE65100);
        private static final Color MUTED = new Color(0x607D8B);

        private static final String CUR = "PHP ";

        private static final DateTimeFormatter TIME_FMT =
                DateTimeFormatter.ofPattern("HH:mm:ss");

        private static final DateTimeFormatter DATE_FMT =
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        // ================================================================
        // SHARED STORE
        // ================================================================

        private final HigalaStore store;

        private final List<HigalaStore.Item> items =
                new ArrayList<>();

        private final List<HigalaStore.Staff> staff =
                new ArrayList<>();

        private final List<HigalaStore.Sale> sales =
                new ArrayList<>();

        // Staff accounts are managed in MySQL; inventory and sales stay in CSV.
        private final StaffManager staffManager = new StaffManager();
        private final List<StaffManager.StaffAccount> databaseStaff =
                new ArrayList<>();

        private long lastStamp = 0;

        // ================================================================
        // SETTINGS
        // ================================================================

        private String businessName = "Higala Ridge";
        private int lowStockLevel = 10;

        // ================================================================
        // PAGE NAVIGATION
        // ================================================================

        private final CardLayout cards =
                new CardLayout();

        private final JPanel pages =
                new JPanel(cards);

        private final Map<String, JButton> navButtons =
                new LinkedHashMap<>();

        // ================================================================
        // TABLE MODELS
        // ================================================================

        private final DefaultTableModel itemsModel =
                readOnlyModel(
                        "Category",
                        "Item",
                        "Price",
                        "Stock",
                        "Status"
                );

        private final DefaultTableModel staffModel =
                readOnlyModel(
                        "Name",
                        "Role",
                        "Status"
                );

        private final DefaultTableModel salesModel =
                readOnlyModel(
                        "Receipt #",
                        "Date & time",
                        "Cashier",
                        "Items",
                        "Total",
                        "Payment",
                        "Status"
                );

        private final DefaultTableModel lowModel =
                readOnlyModel(
                        "Item",
                        "Category",
                        "Stock",
                        "Status"
                );

        private JTable itemsTable;
        private JTable staffTable;
        private JTable salesTable;
        private JTable lowTable;

        private JComboBox<String> periodBox;

        // ================================================================
        // DASHBOARD LABELS
        // ================================================================

        private JLabel dItems;
        private JLabel dLow;
        private JLabel dOut;
        private JLabel dStaff;
        private JLabel dToday;
        private JLabel dWeek;

        // ================================================================
        // SALES LABELS
        // ================================================================

        private JLabel sTotal;
        private JLabel sOrders;
        private JLabel sAvg;
        private JLabel sCash;
        private JLabel sCard;
        private JLabel sGcash;

        // ================================================================
        // SYSTEM
        // ================================================================

        private JTextField setName;
        private JTextField setLow;

        // ================================================================
        // CONSTRUCTOR
        // ================================================================

        public HigalaAdminApp() {
                this(new HigalaStore());
        }

        private double getCompletedCustomerSales() {
    double total = 0;

    String sql =
        "SELECT COALESCE(SUM(total_amount), 0) " +
        "FROM customer_orders " +
        "WHERE order_status = 'Completed'";

    try (
        java.sql.Connection conn =
            DatabaseConnection.getConnection();

        java.sql.PreparedStatement ps =
            conn.prepareStatement(sql);

        java.sql.ResultSet rs = ps.executeQuery()
    ) {
        if (rs.next()) {
            total = rs.getDouble(1);
        }
    } catch (java.sql.SQLException e) {
        e.printStackTrace();
    }

    return total;
}


private void updateDatabaseProduct(
        int productId,
        String newName,
        double newPrice,
        int newStock,
        int newCategoryId
) throws java.sql.SQLException {

    String sql =
            "UPDATE products " +
            "SET product_name = ?, price = ?, " +
            "stock_quantity = ?, category_id = ?, " +
            "is_available = ? " +
            "WHERE product_id = ?";

    try (java.sql.Connection conn =
                 DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new java.sql.SQLException(
                    "Database connection failed."
            );
        }

        try (java.sql.PreparedStatement ps =
                     conn.prepareStatement(sql)) {

            ps.setString(1, newName);
            ps.setDouble(2, newPrice);
            ps.setInt(3, newStock);
            ps.setInt(4, newCategoryId);
            ps.setInt(5, newStock > 0 ? 1 : 0);
            ps.setInt(6, productId);

            int updated = ps.executeUpdate();

            if (updated == 0) {
                throw new java.sql.SQLException(
                        "Product not found in MySQL. ID: " + productId
                );
            }
        }
    }
}




private int getCategoryId(String categoryName)
        throws java.sql.SQLException {

    String sql =
            "SELECT category_id FROM categories " +
            "WHERE category_name = ?";

    try (java.sql.Connection conn =
                 DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new java.sql.SQLException(
                    "Database connection failed."
            );
        }

        try (java.sql.PreparedStatement ps =
                     conn.prepareStatement(sql)) {

            ps.setString(1, categoryName);

            try (java.sql.ResultSet rs =
                         ps.executeQuery()) {

                if (rs.next()) {
                    return rs.getInt("category_id");
                }

                throw new java.sql.SQLException(
                        "Category not found: " + categoryName
                );
            }
        }
    }
}


private int getProductIdByName(String productName)
        throws java.sql.SQLException {

    String sql =
            "SELECT product_id FROM products " +
            "WHERE product_name = ?";

    try (java.sql.Connection conn =
                 DatabaseConnection.getConnection();
         java.sql.PreparedStatement ps =
                 conn.prepareStatement(sql)) {

        if (conn == null) {
            throw new java.sql.SQLException(
                    "Database connection failed."
            );
        }

        ps.setString(1, productName);

        try (java.sql.ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt("product_id");
            }

            throw new java.sql.SQLException(
                    "Product not found in MySQL: " + productName
            );
        }
    }
}




        public HigalaAdminApp(HigalaStore store) {
                super("Higala Ridge - Admin");

                this.store = store;

                loadSettings();

                setLayout(new BorderLayout());

                add(
                        buildHeader(),
                        BorderLayout.NORTH
                );

                add(
                        buildSidebar(),
                        BorderLayout.WEST
                );

                pages.add(
                        buildDashboardPage(),
                        "DASHBOARD"
                );

                pages.add(
                        buildInventoryPage(),
                        "INVENTORY"
                );

                pages.add(
                        buildStaffPage(),
                        "STAFF"
                );

                pages.add(
                        buildSalesPage(),
                        "SALES"
                );

                pages.add(
                        buildSystemPage(),
                        "SYSTEM"
                );

                JPanel content =
                        new JPanel(
                                new BorderLayout()
                        );

                content.setBackground(
                        HEADER_GREEN
                );

                content.setBorder(
                        BorderFactory.createEmptyBorder(
                                0,
                                0,
                                10,
                                10
                        )
                );

                content.add(
                        pages,
                        BorderLayout.CENTER
                );

                add(
                        content,
                        BorderLayout.CENTER
                );

                showPage("DASHBOARD");

                reloadFromStore();

                // ============================================================
                // Watch shared files
                // ============================================================

                setSize(
                        1280,
                        780
                );

                setMinimumSize(
                        new Dimension(
                                1100,
                                680
                        )
                );

                setLocationRelativeTo(null);

                setDefaultCloseOperation(
                        DO_NOTHING_ON_CLOSE
                );

                addWindowListener(
                        new WindowAdapter() {

                        @Override
                        public void windowClosing(
                                WindowEvent e) {

                                confirmExit();
                        }
                        }
                );
        }

        // ================================================================
        // SETTINGS
        // ================================================================

        private void loadSettings() {

                try {

                Properties p =
                        store.loadSettings();

                businessName =
                        p.getProperty(
                                "businessName",
                                businessName
                        );

                String low =
                        p.getProperty(
                                "lowStockLevel",
                                String.valueOf(lowStockLevel)
                        );

                try {
                        lowStockLevel =
                                Integer.parseInt(low);
                } catch (NumberFormatException ignored) {
                        lowStockLevel = 10;
                }

                } catch (RuntimeException ignored) {
                }
        }

        // ================================================================
        // SHARED DATA
        // ================================================================

        private void reloadFromStore() {

                try {

                List<HigalaStore.Item> loadedItems =
                        store.loadItems();

                List<HigalaStore.Sale> loadedSales =
                        store.loadSales();

                System.out.println("Admin data folder: " + store.dir());
                System.out.println("Sales loaded by Admin: " + loadedSales.size());

                sortItems(loadedItems);

                items.clear();
                items.addAll(loadedItems);

                // Staff accounts now come from MySQL instead of staff.csv.
                try {
                        List<StaffManager.StaffAccount> loadedDatabaseStaff =
                                staffManager.loadStaff();
                        databaseStaff.clear();
                        databaseStaff.addAll(loadedDatabaseStaff);
                } catch (Exception dbError) {
                        warn("Could not load staff accounts from MySQL:\n"
                                + safe(dbError.getMessage())
                                + "\nCheck DatabaseConnection and the staff table.");
                }

                sales.clear();
                sales.addAll(loadedSales);

                lastStamp = store.stamp();

                } catch (RuntimeException ex) {

                warn(
                        "Could not load shared data:\n"
                                + ex.getMessage()
                );

                return;
                }

                refreshAll();
        }

        
        private void reloadDatabaseStaff() {
                try {
                        databaseStaff.clear();
                        databaseStaff.addAll(staffManager.loadStaff());
                        refreshStaff();
                } catch (Exception ex) {
                        System.out.println("Could not refresh staff: " + ex.getMessage());
                }
        }


        // ================================================================
        // SORT INVENTORY
        // ================================================================

        private static void sortItems(
                List<HigalaStore.Item> list) {

                list.sort(
                        Comparator
                                .comparingInt(
                                        HigalaAdminApp::categoryOrder
                                )
                                .thenComparing(
                                        i -> safe(i.name)
                                )
                );
        }

        private static int categoryOrder(
                HigalaStore.Item item) {

                if (item == null ||
                        item.category == null) {
                return 99;
                }

                String c =
                        item.category.trim().toUpperCase();

                if (c.equals("SNACKS")) return 0;
                if (c.equals("DESSERT")) return 1;
                if (c.equals("DRINKS")) return 2;

                return 99;
        }

        // ================================================================
        // HEADER
        // ================================================================

        private JComponent buildHeader() {

                JPanel p =
                        new JPanel(
                                new BorderLayout()
                        );

                p.setBackground(
                        HEADER_GREEN
                );

                p.setBorder(
                        BorderFactory.createEmptyBorder(
                                8,
                                14,
                                8,
                                14
                        )
                );

                p.setPreferredSize(
                        new Dimension(
                                0,
                                110
                        )
                );

                File logoFile =
                        new File("logo.png");

                JLabel logo =
                        new JLabel();

                logo.setPreferredSize(
                        new Dimension(
                                96,
                                90
                        )
                );

                if (logoFile.exists()) {

                Image img =
                        new ImageIcon(
                                logoFile.getPath()
                        )
                                .getImage()
                                .getScaledInstance(
                                        90,
                                        90,
                                        Image.SCALE_SMOOTH
                                );

                logo.setIcon(
                        new ImageIcon(img)
                );
                }

                p.add(
                        logo,
                        BorderLayout.WEST
                );

                JLabel title =
                        new JLabel(
                                "HIGALA RIDGE - ADMIN",
                                SwingConstants.CENTER
                        );

                title.setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                38
                        )
                );

                title.setForeground(
                        Color.WHITE
                );

                p.add(
                        title,
                        BorderLayout.CENTER
                );

                JLabel clock =
                        new JLabel();

                clock.setForeground(
                        Color.WHITE
                );

                clock.setFont(
                        new Font(
                                "Arial",
                                Font.PLAIN,
                                13
                        )
                );

                clock.setPreferredSize(
                        new Dimension(
                                96,
                                90
                        )
                );

                clock.setHorizontalAlignment(
                        SwingConstants.RIGHT
                );

                javax.swing.Timer t =
                        new javax.swing.Timer(
                                1000,
                                e -> clock.setText(
                                        "<html><div style='text-align:right'>"
                                                + LocalDateTime.now()
                                                .format(TIME_FMT)
                                                + "</div></html>"
                                )
                        );

                t.setInitialDelay(0);
                t.start();

                p.add(
                        clock,
                        BorderLayout.EAST
                );

                return p;
        }

        // ================================================================
        // SIDEBAR
        // ================================================================

        private JComponent buildSidebar() {

                JPanel p =
                        new JPanel();

                p.setLayout(
                        new BoxLayout(
                                p,
                                BoxLayout.Y_AXIS
                        )
                );

                p.setBackground(
                        SIDEBAR_GREEN
                );

                p.setBorder(
                        BorderFactory.createEmptyBorder(
                                24,
                                16,
                                16,
                                16
                        )
                );

                p.setPreferredSize(
                        new Dimension(
                                250,
                                0
                        )
                );

                JLabel title =
                        new JLabel(
                                "ADMIN"
                        );

                title.setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                30
                        )
                );

                title.setForeground(
                        Color.WHITE
                );

                title.setAlignmentX(
                        Component.CENTER_ALIGNMENT
                );

                p.add(title);

                p.add(
                        Box.createVerticalStrut(
                                34
                        )
                );

                String[] navigation = {
                        "DASHBOARD",
                        "INVENTORY",
                        "STAFF",
                        "SALES",
                        "SYSTEM"
                };

                for (String name : navigation) {

                JButton b =
                        button(
                                name,
                                NAV_GRAY,
                                DARK_GREEN,
                                18
                        );

                b.setAlignmentX(
                        Component.CENTER_ALIGNMENT
                );

                b.setPreferredSize(
                        new Dimension(
                                210,
                                58
                        )
                );

                b.setMaximumSize(
                        new Dimension(
                                Integer.MAX_VALUE,
                                58
                        )
                );

                b.addActionListener(e -> showPage(name));

                navButtons.put(
                        name,
                        b
                );

                p.add(b);

                p.add(
                        Box.createVerticalStrut(
                                16
                        )
                );
                }

                p.add(
                        Box.createVerticalGlue()
                );

                JLabel info =
                        new JLabel(
                                "<html><div style='text-align:center'>"
                                        + escapeHtml(businessName)
                                        + "<br>Administrator"
                                        + "<br>Shared Store"
                                        + "</div></html>"
                        );

                info.setForeground(
                        new Color(
                                0xCFE3D0
                        )
                );

                info.setFont(
                        new Font(
                                "Arial",
                                Font.PLAIN,
                                12
                        )
                );

                info.setAlignmentX(
                        Component.CENTER_ALIGNMENT
                );

                p.add(info);

                return p;
        }

        // ================================================================
        // DASHBOARD
        // ================================================================

        private JComponent buildDashboardPage() {

                JPanel p = page();

                p.add(
                        pageTitle(
                                "ADMIN DASHBOARD"
                        ),
                        BorderLayout.NORTH
                );

                JPanel grid =
                        new JPanel(
                                new GridLayout(
                                        2,
                                        3,
                                        16,
                                        16
                                )
                        );

                grid.setOpaque(false);

                grid.setBorder(
                        BorderFactory.createEmptyBorder(
                                24,
                                40,
                                10,
                                40
                        )
                );

                dItems =
                        addStat(
                                grid,
                                "INVENTORY ITEMS",
                                ITEM_GREEN
                        );

                dLow =
                        addStat(
                                grid,
                                "LOW STOCK",
                                AMBER
                        );

                dOut =
                        addStat(
                                grid,
                                "OUT OF STOCK",
                                WARN
                        );

                dStaff =
                        addStat(
                                grid,
                                "ACTIVE STAFF",
                                PAY_CARD
                        );

                dToday =
                        addStat(
                                grid,
                                "TODAY'S SALES",
                                PAY_CASH
                        );

                dWeek =
                        addStat(
                                grid,
                                "LAST 7 DAYS SALES",
                                PAY_GCASH
                        );

                p.add(
                        grid,
                        BorderLayout.CENTER
                );

                JPanel south =
                        new JPanel();

                south.setOpaque(false);

                south.setLayout(
                        new BoxLayout(
                                south,
                                BoxLayout.Y_AXIS
                        )
                );

                south.setBorder(
                        BorderFactory.createEmptyBorder(
                                0,
                                0,
                                30,
                                0
                        )
                );

                south.add(
                        centered(
                                "Welcome to the Higala Ridge Admin System.",
                                20,
                                Color.DARK_GRAY
                        )
                );

                south.add(
                        Box.createVerticalStrut(
                                10
                        )
                );

                south.add(
                        centered(
                                "Use the menu on the left to manage inventory, staff, sales and system settings.",
                                16,
                                Color.DARK_GRAY
                        )
                );

                p.add(
                        south,
                        BorderLayout.SOUTH
                );

                return p;
        }

        // ================================================================
        // INVENTORY
        // ================================================================

        private JComponent buildInventoryPage() {

                JPanel p = page();

                p.add(
                        pageTitle(
                                "INVENTORY"
                        ),
                        BorderLayout.NORTH
                );

                itemsTable =
                        new JTable(itemsModel);

                styleTable(itemsTable);

                JScrollPane scroll =
                        new JScrollPane(itemsTable);

                scroll.setBorder(
                        titled("Current inventory")
                );

                JPanel buttons =
                        new JPanel(
                                new GridLayout(
                                        1,
                                        5,
                                        8,
                                        8
                                )
                        );

                buttons.setOpaque(false);

                buttons.add(
                        actionButton(
                                "Add Item",
                                ITEM_GREEN,
                                Color.WHITE,
                                e -> addInventoryItem()
                        )
                );

                buttons.add(
                        actionButton(
                                "Edit Item",
                                PAY_CARD,
                                Color.WHITE,
                                e -> editInventoryItem()
                        )
                );

                buttons.add(
                        actionButton(
                                "Restock",
                                PAY_CASH,
                                Color.WHITE,
                                e -> restockItem()
                        )
                );

                buttons.add(
                        actionButton(
                                "Delete",
                                WARN,
                                Color.WHITE,
                                e -> deleteInventoryItem()
                        )
                );

                buttons.add(
                        actionButton(
                                "Refresh",
                                NAV_GRAY,
                                DARK_GREEN,
                                e -> reloadFromStore()
                        )
                );

                buttons.setPreferredSize(
                        new Dimension(
                                0,
                                58
                        )
                );

                JPanel main =
                        new JPanel(
                                new BorderLayout(
                                        0,
                                        8
                                )
                        );

                main.setOpaque(false);

                main.add(
                        scroll,
                        BorderLayout.CENTER
                );

                main.add(
                        buttons,
                        BorderLayout.SOUTH
                );

                p.add(
                        main,
                        BorderLayout.CENTER
                );

                JPanel lowPanel =
                        new JPanel(
                                new BorderLayout()
                        );

                lowPanel.setOpaque(false);

                lowPanel.setPreferredSize(
                        new Dimension(
                                0,
                                185
                        )
                );

                lowTable =
                        new JTable(lowModel);

                styleTable(lowTable);

                lowPanel.setBorder(
                        titled(
                                "Low / out-of-stock items"
                        )
                );

                lowPanel.add(
                        new JScrollPane(lowTable),
                        BorderLayout.CENTER
                );

                p.add(
                        lowPanel,
                        BorderLayout.SOUTH
                );

                return p;
        }

        // ================================================================
        // STAFF
        // ================================================================

        private JComponent buildStaffPage() {

                JPanel p = page();

                p.add(
                        pageTitle(
                                "STAFF"
                        ),
                        BorderLayout.NORTH
                );

                staffTable =
                        new JTable(staffModel);

                styleTable(staffTable);

                JScrollPane scroll =
                        new JScrollPane(staffTable);

                scroll.setBorder(
                        titled(
                                "Cashier and staff accounts"
                        )
                );

                JPanel buttons =
                        new JPanel(
                                new GridLayout(
                                        1,
                                        5,
                                        8,
                                        8
                                )
                        );

                buttons.setOpaque(false);

                buttons.add(
                        actionButton(
                                "Add Staff",
                                ITEM_GREEN,
                                Color.WHITE,
                                e -> addStaff()
                        )
                );

                buttons.add(
                        actionButton(
                                "Edit Staff",
                                PAY_CARD,
                                Color.WHITE,
                                e -> editStaff()
                        )
                );

                buttons.add(
                        actionButton(
                                "Activate / Deactivate",
                                NAV_GRAY,
                                DARK_GREEN,
                                e -> toggleStaff()
                        )
                );

                buttons.add(
                        actionButton(
                                "Remove",
                                WARN,
                                Color.WHITE,
                                e -> removeStaff()
                        )
                );

                buttons.add(
                        actionButton(
                                "Refresh",
                                NAV_GRAY,
                                DARK_GREEN,
                                e -> reloadFromStore()
                        )
                );

                buttons.setPreferredSize(
                        new Dimension(
                                0,
                                58
                        )
                );

                JPanel main =
                        new JPanel(
                                new BorderLayout(
                                        0,
                                        8
                                )
                        );

                main.setOpaque(false);

                main.add(
                        scroll,
                        BorderLayout.CENTER
                );

                main.add(
                        buttons,
                        BorderLayout.SOUTH
                );

                p.add(
                        main,
                        BorderLayout.CENTER
                );

                return p;
        }

        // ================================================================
        // SALES
        // ================================================================

        private JComponent buildSalesPage() {

                JPanel p = page();

                p.add(
                        pageTitle(
                                "SALES"
                        ),
                        BorderLayout.NORTH
                );

                JPanel stats =
                        new JPanel(
                                new GridLayout(
                                        2,
                                        3,
                                        14,
                                        14
                                )
                        );

                stats.setOpaque(false);

                stats.setBorder(
                        BorderFactory.createEmptyBorder(
                                8,
                                30,
                                12,
                                30
                        )
                );

                stats.setPreferredSize(
                        new Dimension(
                                0,
                                200
                        )
                );

                sTotal =
                        addStat(
                                stats,
                                "TOTAL SALES",
                                ITEM_GREEN
                        );

                sOrders =
                        addStat(
                                stats,
                                "PAID ORDERS",
                                PAY_CASH
                        );

                sAvg =
                        addStat(
                                stats,
                                "AVERAGE ORDER",
                                PAY_CARD
                        );

                sCash =
                        addStat(
                                stats,
                                "CASH",
                                PAY_CASH
                        );

                sCard =
                        addStat(
                                stats,
                                "CARD",
                                PAY_CARD
                        );

                sGcash =
                        addStat(
                                stats,
                                "GCASH",
                                PAY_GCASH
                        );

                salesTable =
                        new JTable(salesModel);

                styleTable(salesTable);

                JScrollPane scroll =
                        new JScrollPane(salesTable);

                scroll.setBorder(
                        titled(
                                "Sales transactions"
                        )
                );

                JPanel middle =
                        new JPanel(
                                new BorderLayout()
                        );

                middle.setOpaque(false);

                middle.add(
                        stats,
                        BorderLayout.NORTH
                );

                middle.add(
                        scroll,
                        BorderLayout.CENTER
                );

                p.add(
                        middle,
                        BorderLayout.CENTER
                );

                JPanel bottom =
                        new JPanel(
                                new FlowLayout(
                                        FlowLayout.CENTER,
                                        12,
                                        10
                                )
                        );

                bottom.setOpaque(false);

                bottom.add(
                        new JLabel("Period:")
                );

                periodBox =
                        new JComboBox<>(
                                new String[]{
                                        "All",
                                        "Today",
                                        "This Week",
                                        "This Month"
                                }
                        );

                periodBox.setFont(
                        new Font(
                                "Arial",
                                Font.PLAIN,
                                14
                        )
                );

                periodBox.addActionListener(
                        e -> refreshSalesPage()
                );

                bottom.add(periodBox);

                JButton refresh = actionButton("Refresh", NAV_GRAY, DARK_GREEN, e -> reloadFromStore());
                refresh.setPreferredSize(new Dimension( 150, 50));

                bottom.add(refresh);

                JButton export = actionButton("Export CSV", ITEM_GREEN, Color.WHITE, e -> exportSales());
                export.setPreferredSize(new Dimension(150, 50));

                bottom.add(export);

                p.add(bottom, BorderLayout.SOUTH);

                return p;
        }

        // ================================================================
        // SYSTEM
        // ================================================================

        private JComponent buildSystemPage() {

                JPanel p = page();

                p.add(
                        pageTitle(
                                "SYSTEM"
                        ),
                        BorderLayout.NORTH
                );

                JPanel center = new JPanel(new GridLayout(0, 1, 10, 10));
                center.setOpaque(false);
                center.setBorder(BorderFactory.createEmptyBorder(30, 100, 30, 100));

                JPanel settings = new JPanel(new GridLayout(0, 2, 10, 10));
                settings.setBackground(Color.WHITE);
                settings.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(0xB0BEC5)),
                        BorderFactory.createEmptyBorder(20, 25, 20, 25)));

                JLabel nameLabel = new JLabel("Business name:");
                nameLabel.setFont(new Font("Arial", Font.BOLD, 15));

                setName =
                        new JTextField(
                                businessName
                        );

                setName.setFont(
                        new Font(
                                "Arial",
                                Font.PLAIN,
                                15
                        )
                );

                JLabel lowLabel =
                        new JLabel(
                                "Low-stock level:"
                        );

                lowLabel.setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                15
                        )
                );

                setLow =
                        new JTextField(
                                String.valueOf(
                                        lowStockLevel
                                )
                        );

                setLow.setFont(
                        new Font(
                                "Arial",
                                Font.PLAIN,
                                15
                        )
                );

                settings.add(nameLabel);
                settings.add(setName);

                settings.add(lowLabel);
                settings.add(setLow);

                center.add(settings);

                JButton saveSettings = actionButton("SAVE SETTINGS", ITEM_GREEN, Color.WHITE, e -> saveSettings());
                saveSettings.setPreferredSize(new Dimension(0, 55));

                center.add(saveSettings);

                JButton exit = actionButton("EXIT ADMIN", NAV_GRAY, DARK_GREEN, e -> confirmExit());
                exit.setPreferredSize(new Dimension(0, 55));

                JButton clearSalesButton = new JButton("CLEAR SALES HISTORY");
                JButton clearTransactionsButton = new JButton("Clear Transactions");

                clearSalesButton.addActionListener(e -> clearSales());
                clearTransactionsButton.addActionListener(e -> clearTransactions());

                center.add(clearSalesButton);
                center.add(clearTransactionsButton);
                center.add(exit);

                p.add(center, BorderLayout.CENTER);

                return p;
        }

        // ================================================================
        // INVENTORY ACTIONS
        // ================================================================

        private HigalaStore.Item selectedItem() {

                if (itemsTable == null) {
                return null;
                }

                int row =
                        itemsTable.getSelectedRow();

                if (row < 0) {

                info(
                        "Select an inventory item first."
                );

                return null;
                }

                int modelRow =
                        itemsTable.convertRowIndexToModel(
                                row
                        );

                String category =
                        String.valueOf(
                                itemsModel.getValueAt(
                                        modelRow,
                                        0
                                )
                        );

                String name =
                        String.valueOf(
                                itemsModel.getValueAt(
                                        modelRow,
                                        1
                                )
                        );

                for (HigalaStore.Item item : items) {

                if (safe(item.category).equals(category)
                        && safe(item.name).equals(name)) {

                        return item;
                }
                }

                return null;
        }

        private void addInventoryItem() {

                JTextField name =
                        new JTextField();

                JTextField price =
                        new JTextField();

                JTextField stock =
                        new JTextField("0");

                JComboBox<String> category =
                        new JComboBox<>(
                                inventoryCategories()
                        );

                JPanel form =
                        new JPanel(
                                new GridLayout(
                                        0,
                                        2,
                                        8,
                                        8
                                )
                        );

                form.add(new JLabel("Category:"));
                form.add(category);

                form.add(new JLabel("Item name:"));
                form.add(name);

                form.add(new JLabel("Price (PHP):"));
                form.add(price);

                form.add(new JLabel("Stock:"));
                form.add(stock);

                int result =
                        JOptionPane.showConfirmDialog(
                                this,
                                form,
                                "Add inventory item",
                                JOptionPane.OK_CANCEL_OPTION,
                                JOptionPane.PLAIN_MESSAGE
                        );

                if (result != JOptionPane.OK_OPTION) {
                return;
                }

                String itemName =
                        name.getText().trim();

                Double itemPrice =
                        parseMoney(price.getText());

                Integer itemStock =
                        parseInteger(stock.getText());

                if (itemName.isEmpty()) {
                warn("Please enter an item name.");
                return;
                }

                if (itemPrice == null) {
                warn("Please enter a valid price.");
                return;
                }

                if (itemStock == null || itemStock < 0) {
                warn("Please enter a valid stock quantity.");
                return;
                }

                String cat =
                        String.valueOf(
                                category.getSelectedItem()
                        );

                saveChange(
                        () -> store.updateItems(
                                list -> {

                                HigalaStore.Item existing =
                                        findItem(
                                                list,
                                                itemName
                                        );

                                if (existing != null) {
                                        throw new IllegalArgumentException(
                                                "An item named \""
                                                        + itemName
                                                        + "\" already exists."
                                        );
                                }

                                list.add(
                                        new HigalaStore.Item(
                                                cat,
                                                itemName,
                                                itemPrice,
                                                itemStock
                                        )
                                );
                                }
                        )
                );
        }

        private void editInventoryItem() {

                HigalaStore.Item old =
                        selectedItem();

                if (old == null) {
                return;
                }

                JTextField name =
                        new JTextField(old.name);

                JTextField price =
                        new JTextField(
                                String.format(
                                        "%.2f",
                                        old.price
                                )
                        );

                JTextField stock =
                        new JTextField(
                                String.valueOf(old.stock)
                        );

                JComboBox<String> category =
                        new JComboBox<>(
                                inventoryCategories()
                        );

                category.setSelectedItem(
                        old.category
                );

                JPanel form =
                        new JPanel(
                                new GridLayout(
                                        0,
                                        2,
                                        8,
                                        8
                                )
                        );

                form.add(new JLabel("Category:"));
                form.add(category);

                form.add(new JLabel("Item name:"));
                form.add(name);

                form.add(new JLabel("Price (PHP):"));
                form.add(price);

                form.add(new JLabel("Stock:"));
                form.add(stock);

                int result =
                        JOptionPane.showConfirmDialog(
                                this,
                                form,
                                "Edit inventory item",
                                JOptionPane.OK_CANCEL_OPTION,
                                JOptionPane.PLAIN_MESSAGE
                        );

                if (result != JOptionPane.OK_OPTION) {
                return;
                }

                String newName =
                        name.getText().trim();

                Double newPrice =
                        parseMoney(price.getText());

                Integer newStock =
                        parseInteger(stock.getText());

                if (newName.isEmpty()) {
                warn("Item name cannot be empty.");
                return;
                }

                if (newPrice == null) {
                warn("Please enter a valid price.");
                return;
                }

                if (newStock == null || newStock < 0) {
                warn("Please enter a valid stock quantity.");
                return;
                }

                String newCategory =
                        String.valueOf(
                                category.getSelectedItem()
                        );

                

saveChange(() -> {

    try {
        String categoryName = newCategory.trim();

        if (categoryName.equalsIgnoreCase("DESSERT")) {
            categoryName = "DESSERTS";
        }

        int newCategoryId = getCategoryId(categoryName);

        // Find the product's actual ID in MySQL
        int productId = getProductIdByName(old.name);

        // Update the product in MySQL
        updateDatabaseProduct(
                productId,
                newName,
                newPrice,
                newStock,
                newCategoryId
        );

    } catch (java.sql.SQLException ex) {
        throw new IllegalArgumentException(
                "Could not update product in MySQL:\n"
                        + ex.getMessage()
        );
    }

    // Update the shared store
    store.updateItems(list -> {

        for (HigalaStore.Item item : list) {
            if (!item.name.equalsIgnoreCase(old.name)
                    && item.name.equalsIgnoreCase(newName)) {
                throw new IllegalArgumentException(
                        "Another item named \"" + newName
                                + "\" already exists."
                );
            }
        }

        HigalaStore.Item target = findItem(list, old.name);

        if (target == null) {
            throw new IllegalArgumentException(
                    "The selected item no longer exists."
            );
        }

        target.category = newCategory;
        target.name = newName;
        target.price = newPrice;
        target.stock = newStock;
    });
});

}


        private void restockItem() {

                HigalaStore.Item item =
                        selectedItem();

                if (item == null) {
                return;
                }

                String s =
                        JOptionPane.showInputDialog(
                                this,
                                "Current stock: "
                                        + item.stock
                                        + "\nQuantity to add:",
                                "Restock " + item.name,
                                JOptionPane.QUESTION_MESSAGE
                        );

                if (s == null) {
                return;
                }

                Integer qty =
                        parseInteger(s);

                if (qty == null || qty <= 0) {
                warn(
                        "Please enter a positive whole number."
                );
                return;
                }

                saveChange(
                        () -> store.updateItems(
                                list -> {

                                HigalaStore.Item target =
                                        findItem(
                                                list,
                                                item.name
                                        );

                                if (target == null) {
                                        throw new IllegalArgumentException(
                                                "The selected item no longer exists."
                                        );
                                }

                                target.stock += qty;
                                }
                        )
                );
        }

        private void deleteInventoryItem() {

                HigalaStore.Item item =
                        selectedItem();

                if (item == null) {
                return;
                }

                int result =
                        JOptionPane.showConfirmDialog(
                                this,
                                "Delete \""
                                        + item.name
                                        + "\" from inventory?",
                                "Delete item",
                                JOptionPane.YES_NO_OPTION,
                                JOptionPane.WARNING_MESSAGE
                        );

                if (result != JOptionPane.YES_OPTION) {
                return;
                }

                saveChange(
                        () -> store.updateItems(
                                list -> {

                                HigalaStore.Item target =
                                        findItem(
                                                list,
                                                item.name
                                        );

                                if (target == null) {
                                        throw new IllegalArgumentException(
                                                "The selected item no longer exists."
                                        );
                                }

                                list.remove(target);
                                }
                        )
                );
        }

        private static HigalaStore.Item findItem(
                List<HigalaStore.Item> list,
                String name) {

                for (HigalaStore.Item item : list) {

                if (item.name != null
                        && item.name.equalsIgnoreCase(name)) {

                        return item;
                }
                }

                return null;
        }

        // ================================================================
        // STAFF ACTIONS (MySQL)
        // ================================================================

        private StaffManager.StaffAccount selectedStaff() {

                int row = staffTable.getSelectedRow();
                if (row < 0) {
                info("Select a staff account first.");
                return null;
                }

                int modelRow = staffTable.convertRowIndexToModel(row);
                String name = String.valueOf(staffModel.getValueAt(modelRow, 0));

                for (StaffManager.StaffAccount account : databaseStaff) {
                if (safe(account.cashierName).equals(name)) {
                        return account;
                }
                }

                info("The selected staff account was not found. Please refresh the list.");
                return null;
        }

        private void addStaff() {

                JTextField name = new JTextField();
                JPasswordField password = new JPasswordField();
                JTextField contact = new JTextField();

                JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
                form.add(new JLabel("Cashier username:"));
                form.add(name);
                form.add(new JLabel("Password (8+ characters):"));
                form.add(password);
                form.add(new JLabel("Contact (optional):"));
                form.add(contact);

                int result = JOptionPane.showConfirmDialog(
                        this, form, "Add Cashier Account",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result != JOptionPane.OK_OPTION) return;

                String username = name.getText().trim();
                String pass = new String(password.getPassword());
                String phone = contact.getText().trim();

                if (username.isEmpty()) {
                warn("Please enter a cashier username.");
                return;
                }
                if (pass.length() < 8) {
                warn("Password must contain at least 8 characters.");
                return;
                }

                runDatabaseChange(() -> {
                boolean added = staffManager.registerCashier(username, pass, phone);
                if (!added) {
                        throw new IllegalArgumentException(
                                "Could not add the account. The username may already exist.");
                }
                info("Cashier account added successfully.");
                });
        }

        private void editStaff() {

                StaffManager.StaffAccount old = selectedStaff();
                if (old == null) return;

                JTextField name = new JTextField(old.cashierName);
                JTextField contact = new JTextField(safe(old.contact));
                JLabel role = new JLabel(old.position);

                JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
                form.add(new JLabel("Cashier username:"));
                form.add(name);
                form.add(new JLabel("Role:"));
                form.add(role);
                form.add(new JLabel("Contact (optional):"));
                form.add(contact);

                int result = JOptionPane.showConfirmDialog(
                        this, form, "Edit Staff Account",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result != JOptionPane.OK_OPTION) return;

                String newName = name.getText().trim();
                String newContact = contact.getText().trim();
                if (newName.isEmpty()) {
                warn("Username cannot be empty.");
                return;
                }

                runDatabaseChange(() -> {
                boolean updated = staffManager.updateStaff(
                        old.staffId, newName, old.position, newContact);
                if (!updated) {
                        throw new IllegalArgumentException("No staff account was updated.");
                }
                info("Staff account updated successfully.");
                });
        }

        private void toggleStaff() {

                StaffManager.StaffAccount selected = selectedStaff();
                if (selected == null) return;

                boolean newActive = !selected.active;
                String action = newActive ? "activate" : "deactivate";

                int result = JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to " + action + " the account for \""
                                + selected.cashierName + "\"?",
                        "Confirm Account Status",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE);

                if (result != JOptionPane.YES_OPTION) return;

                runDatabaseChange(() -> {
                boolean updated = staffManager.setActive(selected.staffId, newActive);
                if (!updated) {
                        throw new IllegalArgumentException(
                                "The account could not be updated. Check that it is a Cashier account.");
                }
                info("Account is now " + (newActive ? "ACTIVE." : "INACTIVE."));
                });
        }

        private void removeStaff() {

                StaffManager.StaffAccount selected = selectedStaff();
                if (selected == null) return;

                int result = JOptionPane.showConfirmDialog(
                        this,
                        "Permanently remove the account for \""
                                + selected.cashierName + "\"?",
                        "Remove Staff Account",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);

                if (result != JOptionPane.YES_OPTION) return;

                runDatabaseChange(() -> {
                boolean removed = staffManager.removeStaff(selected.staffId);
                if (!removed) {
                        throw new IllegalArgumentException("The account was not removed.");
                }
                info("Staff account removed successfully.");
                });
        }

        private void runDatabaseChange(SqlAction operation) {
                try {
                operation.run();
                reloadFromStore();
                } catch (Exception ex) {
                String message = ex.getMessage();
                if (message == null || message.trim().isEmpty()) {
                        message = ex.getClass().getSimpleName();
                }
                warn("Could not save the staff account change:\n" + message);
                }
        }

        @FunctionalInterface
        private interface SqlAction {
                void run() throws Exception;
        }

        // ================================================================
        // SYSTEM ACTIONS
        // ================================================================

        private void saveSettings() {

                String name =
                        setName.getText().trim();

                Integer low =
                        parseInteger(
                                setLow.getText()
                        );

                if (name.isEmpty()) {
                warn(
                        "Business name cannot be empty."
                );
                return;
                }

                if (low == null || low < 0) {
                warn(
                        "Low-stock level must be a whole number."
                );
                return;
                }

                final String finalName =
                        name;

                final int finalLow =
                        low;

                try {

                Properties p =
                        store.loadSettings();

                p.setProperty(
                        "businessName",
                        finalName
                );

                p.setProperty(
                        "lowStockLevel",
                        String.valueOf(finalLow)
                );

                store.saveSettings(p);

                businessName =
                        finalName;

                lowStockLevel =
                        finalLow;

                info(
                        "System settings saved."
                );

                } catch (RuntimeException ex) {

                warn(
                        "Could not save settings:\n"
                                + ex.getMessage()
                );
                }
        }


private void clearSales() {
    int result = JOptionPane.showConfirmDialog(
            this,
            "Clear the sales history display?\n" +
            "Original customer transactions will be preserved.",
            "Clear Sales History",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (result != JOptionPane.YES_OPTION) {
        return;
    }

    try {
        // Clear walk-in sales from the store.
        store.clearSales();

        // Hide completed customer orders from sales history.
        String sql =
                "UPDATE customer_orders " +
                "SET hidden_from_sales = TRUE " +
                "WHERE order_status = 'Completed'";

        try (java.sql.Connection conn =
                     DatabaseConnection.getConnection()) {

            if (conn == null) {
                throw new java.sql.SQLException(
                        "Database connection failed."
                );
            }

            try (java.sql.PreparedStatement ps =
                         conn.prepareStatement(sql)) {
                ps.executeUpdate();
            }
        }

        reloadFromStore();
        info("Sales history cleared successfully.");

    } catch (Exception ex) {
        warn("Could not clear sales history:\n" + ex.getMessage());
    }
}

private void clearTransactions() {
    int result = JOptionPane.showConfirmDialog(
            this,
            "Permanently delete ALL customer transactions?\n\n" +
            "This includes their associated order items.",
            "Clear Transactions",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (result != JOptionPane.YES_OPTION) {
        return;
    }

    String confirmation = JOptionPane.showInputDialog(
            this,
            "Type DELETE to confirm:",
            "Confirm Deletion",
            JOptionPane.WARNING_MESSAGE
    );

    if (!"DELETE".equals(confirmation)) {
        return;
    }

    String deleteItems =
            "DELETE oi FROM order_items oi " +
            "INNER JOIN customer_orders co " +
            "ON oi.order_id = co.id";

    String deleteOrders =
            "DELETE FROM customer_orders";

    try (java.sql.Connection conn =
                 DatabaseConnection.getConnection()) {

        if (conn == null) {
            throw new java.sql.SQLException(
                    "Database connection failed."
            );
        }

        conn.setAutoCommit(false);

        try {
            try (java.sql.PreparedStatement ps =
                         conn.prepareStatement(deleteItems)) {
                ps.executeUpdate();
            }

            try (java.sql.PreparedStatement ps =
                         conn.prepareStatement(deleteOrders)) {
                ps.executeUpdate();
            }

            conn.commit();

        } catch (Exception ex) {
            conn.rollback();
            throw ex;

        } finally {
            conn.setAutoCommit(true);
        }

        reloadFromStore();
        info("Customer transactions cleared successfully.");

    } catch (Exception ex) {
        warn("Could not clear transactions:\n" + ex.getMessage());
    }
}


        // ================================================================
        // SALES EXPORT
        // ================================================================

        private void exportSales() {

                List<HigalaStore.Sale> exportList =
                        filteredSales();

                if (exportList.isEmpty()) {

                info(
                        "There are no sales to export for the selected period."
                );

                return;
                }

                JFileChooser chooser =
                        new JFileChooser();

                chooser.setSelectedFile(
                        new File(
                                "higala_sales_"
                                        + LocalDate.now()
                                        + ".csv"
                        )
                );

                int result =
                        chooser.showSaveDialog(this);

                if (result != JFileChooser.APPROVE_OPTION) {
                return;
                }

                File file =
                        chooser.getSelectedFile();

                try (
                        PrintWriter out =
                                new PrintWriter(
                                        new FileWriter(file)
                                )
                ) {

                out.println(
                        "Receipt #,Date & Time,Cashier,Items,Total,Payment,Status"
                );

                for (HigalaStore.Sale s :
                        exportList) {

                        out.println(
                                csv(s.receipt)
                                        + ","
                                        + csv(
                                                s.time.format(
                                                        DATE_FMT
                                                )
                                        )
                                        + ","
                                        + csv(s.cashier)
                                        + ","
                                        + csv(s.items)
                                        + ","
                                        + csv(
                                                String.format(
                                                        "%.2f",
                                                        s.total
                                                )
                                        )
                                        + ","
                                        + csv(s.method)
                                        + ","
                                        + csv(
                                                s.refunded
                                                        ? "Refunded"
                                                        : "Completed"
                                        )
                        );
                }

                info(
                        "Sales exported successfully:\n"
                                + file.getAbsolutePath()
                );

                } catch (IOException ex) {

                warn(
                        "Could not export sales:\n"
                                + ex.getMessage()
                );
                }
        }

        private static String csv(
                Object value) {

                String s =
                        String.valueOf(
                                value == null
                                        ? ""
                                        : value
                        );

                return "\""
                        + s.replace(
                                "\"",
                                "\"\""
                        )
                        + "\"";
        }

        // ================================================================
        // SALES FILTER
        // ================================================================

        private List<HigalaStore.Sale> filteredSales() {

                List<HigalaStore.Sale> result =
                        new ArrayList<>();

                String period =
                        periodBox == null
                                ? "All"
                                : String.valueOf(
                                        periodBox.getSelectedItem()
                                );

                LocalDate today =
                        LocalDate.now();

                for (HigalaStore.Sale s :
                        sales) {

                LocalDate date =
                        s.time.toLocalDate();

                boolean include;

                switch (period) {

                        case "Today":

                        include =
                                date.equals(today);

                        break;

                        case "This Week":

                        include =
                                !date.isBefore(
                                        today.minusDays(6)
                                );

                        break;

                        case "This Month":

                        include =
                                date.getYear()
                                        == today.getYear()
                                        && date.getMonth()
                                        == today.getMonth();

                        break;

                        default:

                        include = true;

                        break;
                }

                if (include) {
                        result.add(s);
                }
                }

                return result;
        }

private void refreshSalesPage() {

    if (salesTable == null) {
        return;
    }

    salesModel.setRowCount(0);

    // 1. Load walk-in sales
    List<HigalaStore.Sale> filtered = filteredSales();

    for (HigalaStore.Sale s : filtered) {

        salesModel.addRow(new Object[]{
            s.receipt,
            s.time.format(DATE_FMT),
            s.cashier,
            s.items,
            money(s.total),
            s.method,
            s.refunded ? "Refunded" : "Completed"
        });
    }

    // 2. Load completed customer orders from MySQL
    String sql =
        "SELECT order_number, customer_name, completed_by, " +
        "order_date, total_amount, payment_method, order_status " +
        "FROM customer_orders " +
        "WHERE order_status = 'Completed' " +
        "AND hidden_from_sales = FALSE " +      
        "ORDER BY order_date DESC";

    double customerSales = 0;
    int customerCount = 0;

    try (
        java.sql.Connection conn =
            DatabaseConnection.getConnection();
        java.sql.PreparedStatement ps =
            conn.prepareStatement(sql);
        java.sql.ResultSet rs = ps.executeQuery()
    ) {

        while (rs.next()) {

            String orderNumber = rs.getString("order_number");
            String customerName = rs.getString("customer_name");
            String cashierName = rs.getString("completed_by");
            java.sql.Timestamp orderDate =
                rs.getTimestamp("order_date");

            double amount = rs.getDouble("total_amount");
            String payment = rs.getString("payment_method");
            String status = rs.getString("order_status");

            salesModel.addRow(new Object[]{
                orderNumber,
                orderDate == null ? "" :
                    orderDate.toLocalDateTime().format(DATE_FMT),


                cashierName == null || cashierName.isBlank()
                        ? "Not Recorded" : cashierName,

                        
                "Customer Order",
                money(amount),
                payment == null ? "N/A" : payment,
                status
            });

            customerSales += amount;
            customerCount++;
        }

    } catch (java.sql.SQLException e) {
        e.printStackTrace();

        javax.swing.JOptionPane.showMessageDialog(
            this,
            "Unable to load customer transactions.\n" +
            e.getMessage()
        );
    }

    // 3. Calculate walk-in sales summaries
    double total = 0;
    double cash = 0;
    double card = 0;
    double gcash = 0;
    int count = 0;

    for (HigalaStore.Sale s : filtered) {

        if (s.refunded) {
            continue;
        }

        total += s.total;
        count++;

        if ("Cash".equalsIgnoreCase(s.method)) {
            cash += s.total;
        } else if ("Card".equalsIgnoreCase(s.method)) {
            card += s.total;
        } else if ("Gcash".equalsIgnoreCase(s.method)) {
            gcash += s.total;
        }
    }

    // 4. Update sales summaries
    sTotal.setText(money(total + customerSales));

    sOrders.setText(
        String.valueOf(count + customerCount)
    );

    sAvg.setText(
        money(
            (count + customerCount) == 0
                ? 0
                : (total + customerSales) / (count + customerCount)
        )
    );

    sCash.setText(money(cash));
    sCard.setText(money(card));
    sGcash.setText(money(gcash));
}

        // ================================================================
        // REFRESH
        // ================================================================

        private void refreshAll() {

                refreshInventory();
                refreshStaff();
                refreshSalesPage();
                refreshDashboard();
        }

        private void refreshInventory() {

                if (itemsTable == null) {
                return;
                }

                itemsModel.setRowCount(0);
                lowModel.setRowCount(0);

                int low = 0;
                int out = 0;

                for (HigalaStore.Item item :
                        items) {

                String status;

                if (item.stock <= 0) {

                        status = "OUT";
                        out++;

                } else if (item.stock <= lowStockLevel) {

                        status = "LOW";
                        low++;

                } else {

                        status = "OK";
                }

                itemsModel.addRow(
                        new Object[]{
                                item.category,
                                item.name,
                                money(item.price),
                                item.stock,
                                status
                        }
                );

                if (!"OK".equals(status)) {

                        lowModel.addRow(
                                new Object[]{
                                        item.name,
                                        item.category,
                                        item.stock,
                                        status
                                }
                        );
                }
                }

                dLow.setText(
                        String.valueOf(low)
                );

                dOut.setText(
                        String.valueOf(out)
                );
        }

        private void refreshStaff() {

                if (staffTable == null) return;

                staffModel.setRowCount(0);
                int active = 0;

                for (StaffManager.StaffAccount account : databaseStaff) {
                if (account.active) active++;

                staffModel.addRow(new Object[]{
                        account.cashierName,
                        account.position,
                        account.active ? "ACTIVE" : "INACTIVE"
                });
                }

                dStaff.setText(String.valueOf(active));
        }

private double getTodayCustomerSales() {
    double total = 0;

    String sql =
        "SELECT COALESCE(SUM(total_amount), 0) " +
        "FROM customer_orders " +
        "WHERE order_status = 'Completed' " +
        "AND DATE(order_date) = CURDATE()";

    try (
        java.sql.Connection conn =
            DatabaseConnection.getConnection();
        java.sql.PreparedStatement ps =
            conn.prepareStatement(sql);
        java.sql.ResultSet rs =
            ps.executeQuery()
    ) {
        if (rs.next()) {
            total = rs.getDouble(1);
        }
    } catch (java.sql.SQLException e) {
        e.printStackTrace();
    }

    return total;
}

private void refreshDashboard() {
    int itemCount = items.size();

    dItems.setText(String.valueOf(itemCount));

    double todaySales = 0;
    double weekSales = 0;

    LocalDate today = LocalDate.now();

    // Walk-in sales
    for (HigalaStore.Sale s : sales) {
        if (s.refunded) {
            continue;
        }

        LocalDate date = s.time.toLocalDate();

        if (date.equals(today)) {
            todaySales += s.total;
        }

        if (!date.isBefore(today.minusDays(6))) {
            weekSales += s.total;
        }
    }

    // Completed customer orders
    todaySales += getTodayCustomerSales();

    dToday.setText(money(todaySales));
    dWeek.setText(money(weekSales));
}

        // ================================================================
        // NAVIGATION
        // ================================================================

        private void showPage(
                String name) {

                cards.show(
                        pages,
                        name
                );

                for (Map.Entry<String, JButton> en :
                        navButtons.entrySet()) {

                boolean selected =
                        en.getKey().equals(name);

                en.getValue().setBackground(
                        selected
                                ? Color.WHITE
                                : NAV_GRAY
                );

                en.getValue().setForeground(
                        DARK_GREEN
                );
                }

                if ("SALES".equals(name)) {
                refreshSalesPage();
                }
        }

        // ================================================================
        // UI HELPERS
        // ================================================================

        private static JPanel page() {

                JPanel p =
                        new JPanel(
                                new BorderLayout()
                        );

                p.setBackground(
                        CONTENT_BG
                );

                p.setBorder(
                        BorderFactory.createEmptyBorder(
                                6,
                                14,
                                8,
                                14
                        )
                );

                return p;
        }

        private static JLabel pageTitle(
                String text) {

                JLabel l =
                        new JLabel(
                                text,
                                SwingConstants.CENTER
                        );

                l.setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                34
                        )
                );

                l.setForeground(
                        DARK_GREEN
                );

                l.setBorder(
                        BorderFactory.createEmptyBorder(
                                12,
                                0,
                                10,
                                0
                        )
                );

                return l;
        }

        private static JLabel centered(
                String text,
                int size,
                Color color) {

                JLabel l =
                        new JLabel(
                                text,
                                SwingConstants.CENTER
                        );

                l.setFont(
                        new Font(
                                "Arial",
                                Font.PLAIN,
                                size
                        )
                );

                l.setForeground(color);

                l.setAlignmentX(
                        Component.CENTER_ALIGNMENT
                );

                return l;
        }

        private static javax.swing.border.Border titled(
                String text) {

                return BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(
                                new Color(0xB0BEC5)
                        ),
                        text
                );
        }

        private static JButton button(
                String text,
                Color bg,
                Color fg,
                int size) {

                JButton b =
                        new JButton(text);

                b.setBackground(bg);
                b.setForeground(fg);

                b.setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                size
                        )
                );

                b.setFocusPainted(false);
                b.setOpaque(true);

                b.setCursor(
                        Cursor.getPredefinedCursor(
                                Cursor.HAND_CURSOR
                        )
                );

                return b;
        }

        private static JButton actionButton(
                String text,
                Color bg,
                Color fg,
                java.awt.event.ActionListener listener) {

                JButton b =
                        button(
                                text,
                                bg,
                                fg,
                                15
                        );

                b.addActionListener(listener);

                return b;
        }

        private static JLabel addStat(
                JPanel parent,
                String title,
                Color accent) {

                JPanel card =
                        new JPanel(
                                new BorderLayout()
                        );

                card.setBackground(
                        Color.WHITE
                );

                card.setBorder(
                        BorderFactory.createCompoundBorder(
                                BorderFactory.createMatteBorder(
                                        0,
                                        6,
                                        0,
                                        0,
                                        accent
                                ),
                                BorderFactory.createEmptyBorder(
                                        10,
                                        14,
                                        10,
                                        14
                                )
                        )
                );

                JLabel t =
                        new JLabel(title);

                t.setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                12
                        )
                );

                t.setForeground(MUTED);

                JLabel v =
                        new JLabel("-");

                v.setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                24
                        )
                );

                v.setForeground(DARK_GREEN);

                card.add(
                        t,
                        BorderLayout.NORTH
                );

                card.add(
                        v,
                        BorderLayout.CENTER
                );

                parent.add(card);

                return v;
        }

        private static void styleTable(
                JTable t) {

                t.setRowHeight(28);

                t.setFont(
                        new Font(
                                "Arial",
                                Font.PLAIN,
                                14
                        )
                );

                t.getTableHeader().setFont(
                        new Font(
                                "Arial",
                                Font.BOLD,
                                14
                        )
                );

                t.setSelectionMode(
                        ListSelectionModel.SINGLE_SELECTION
                );

                t.setFillsViewportHeight(true);
        }

        private static DefaultTableModel readOnlyModel(
                String... cols) {

                return new DefaultTableModel(
                        cols,
                        0
                ) {

                @Override
                public boolean isCellEditable(
                        int row,
                        int column) {

                        return false;
                }
                };
        }

        private static String money(
                double value) {

                return String.format(
                        "%s%,.2f",
                        CUR,
                        value
                );
        }

        private static Double parseMoney(
                String text) {

                try {

                double value =
                        Double.parseDouble(
                                text.trim()
                                        .replace(
                                                ",",
                                                ""
                                        )
                        );

                return value < 0
                        ? null
                        : value;

                } catch (
                        NumberFormatException |
                        NullPointerException e) {

                return null;
                }
        }

        private static Integer parseInteger(
                String text) {

                try {

                return Integer.parseInt(
                        text.trim()
                );

                } catch (
                        NumberFormatException |
                        NullPointerException e) {

                return null;
                }
        }

        private static String safe(
                String text) {

                return text == null
                        ? ""
                        : text;
        }

        private static String escapeHtml(
                String text) {

                if (text == null) {
                return "";
                }

                return text
                        .replace("&", "&amp;")
                        .replace("<", "&lt;")
                        .replace(">", "&gt;")
                        .replace("\"", "&quot;");
        }

        private void info(
                String msg) {

                JOptionPane.showMessageDialog(
                        this,
                        msg,
                        "Higala Ridge",
                        JOptionPane.INFORMATION_MESSAGE
                );
        }

        private void warn(
                String msg) {

                JOptionPane.showMessageDialog(
                        this,
                        msg,
                        "Higala Ridge",
                        JOptionPane.WARNING_MESSAGE
                );
        }

        // ================================================================
        // SAFE STORE CHANGE
        // ================================================================

        private void saveChange(
                Runnable operation) {

                try {

                operation.run();

                reloadFromStore();

                } catch (RuntimeException ex) {

                String message =
                        ex.getMessage();

                if (message == null ||
                        message.trim().isEmpty()) {

                        message =
                                ex.getClass()
                                        .getSimpleName();
                }

                warn(
                        "Could not save the change:\n"
                                + message
                );
                }
        }

        // ================================================================
        // CATEGORIES
        // ================================================================

        private String[] inventoryCategories() {

                return HigalaStore.CATEGORIES.clone();
        }

        // ================================================================
        // EXIT
        // ================================================================

        private void confirmExit() {

                int result =
                        JOptionPane.showConfirmDialog(
                                this,
                                "Exit the Higala Ridge Admin System?",
                                "Exit",
                                JOptionPane.YES_NO_OPTION,
                                JOptionPane.QUESTION_MESSAGE
                        );

                if (result ==
                        JOptionPane.YES_OPTION) {

                dispose();

                System.exit(0);
                }
        }

        // ================================================================
        // MAIN
        // ================================================================

        public static void main(
                String[] args) {

                try {

                UIManager.setLookAndFeel(
                        UIManager
                                .getCrossPlatformLookAndFeelClassName()
                );

                } catch (Exception ignored) {
                }

                SwingUtilities.invokeLater(
                        () -> {

                        HigalaAdminApp app =
                                new HigalaAdminApp();

                        app.setVisible(true);
                        }
                );
        }
        }