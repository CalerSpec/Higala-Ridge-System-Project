import java.awt.*;
import javax.swing.*;

public class Cart extends JFrame {

    private final Color FOREST_CODE = new Color(7, 94, 70);
    private final Color MINT_FOG = new Color(232, 255, 242);

    private JPanel cartPanel;
    private JLabel totalLabel;
    private JButton checkoutButton;

    public Cart() {

        setTitle("Shopping Cart");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_FOG);

        // Title
        JLabel title = new JLabel("MY CART");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(FOREST_CODE);
        title.setHorizontalAlignment(JLabel.CENTER);

        mainPanel.add(title, BorderLayout.NORTH);

        // Cart items
        cartPanel = new JPanel();
        cartPanel.setLayout(new BoxLayout(cartPanel, BoxLayout.Y_AXIS));
        cartPanel.setBackground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(cartPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // Bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBackground(MINT_FOG);

        totalLabel = new JLabel();
        totalLabel.setFont(new Font("Arial", Font.BOLD, 18));
        totalLabel.setForeground(FOREST_CODE);

        checkoutButton = new JButton("CHECKOUT");
        checkoutButton.setFont(new Font("Arial", Font.BOLD, 16));
        checkoutButton.setBackground(FOREST_CODE);
        checkoutButton.setForeground(MINT_FOG);
        checkoutButton.setFocusPainted(false);

        checkoutButton.addActionListener(e -> {
            if (CartManager.cartItems.isEmpty()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Cannot checkout, cart is empty."
                );
            } else {
                new Checkout();
                dispose();
            }
        });

        bottomPanel.add(totalLabel, BorderLayout.WEST);
        bottomPanel.add(checkoutButton, BorderLayout.EAST);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // Display items and total
        refreshCart();

        setVisible(true);
    }

    // Display cart items
    private void refreshCart() {

        cartPanel.removeAll();

        if (CartManager.cartItems.isEmpty()) {

            JLabel emptyLabel = new JLabel("Your cart is empty.");
            emptyLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            emptyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            cartPanel.add(Box.createVerticalStrut(30));
            cartPanel.add(emptyLabel);

        } else {

            for (int i = 0; i < CartManager.cartItems.size(); i++) {

                final int index = i;

                JPanel itemPanel = new JPanel(new BorderLayout(10, 0));
                itemPanel.setBackground(Color.WHITE);
                itemPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 55));
                itemPanel.setPreferredSize(new Dimension(450, 55));
                itemPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

                JLabel itemLabel = new JLabel(
                    CartManager.cartItems.get(i)
                );
                itemLabel.setFont(new Font("Arial", Font.PLAIN, 15));

                JButton removeButton = new JButton("REMOVE");
                removeButton.setForeground(Color.WHITE);
                removeButton.setBackground(FOREST_CODE);
                removeButton.setFocusPainted(false);  
                
                removeButton.setPreferredSize(new Dimension(100, 30));
                removeButton.setMinimumSize(new Dimension(100, 30));
                removeButton.setVisible(true);

                removeButton.addActionListener(e -> {

                    int confirm = JOptionPane.showConfirmDialog(
                        this,
                        "Remove this item from your cart?",
                        "Confirm Removal",
                        JOptionPane.YES_NO_OPTION
                    );

                    if (confirm == JOptionPane.YES_OPTION) {

                        CartManager.cartItems.remove(index);
                        CartManager.cartPrices.remove(index);

                        refreshCart();
                    }
                });

                itemPanel.add(itemLabel, BorderLayout.CENTER);
                itemPanel.add(removeButton, BorderLayout.EAST);

                cartPanel.add(itemPanel);
                cartPanel.add(
                    new JSeparator(SwingConstants.HORIZONTAL)
                );
            }
        }

        // Recalculate total
        double total = 0;

        for (double price : CartManager.cartPrices) {
            total += price;
        }

        totalLabel.setText(
            "Total: ₱" + String.format("%.2f", total)
        );

        cartPanel.revalidate();
        cartPanel.repaint();
    }
}