import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.function.Consumer;
import java.util.function.Supplier;


public final class HigalaStore {

    public static final String[] CATEGORIES = {"SNACKS", "DESSERT", "DRINKS"};
    public static final String[] ROLES = {"Admin", "Manager", "Cashier", "Kitchen"};

    // ---------- Records ----------
    
public static class Item {
    public int productId;
    public String category, name;
    public double price;
    public int stock;

    public Item(String category, String name, double price, int stock) {
        this.category = category;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }

    public Item(int productId, String category, String name, double price, int stock) {
        this.productId = productId;
        this.category = category;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }
}


    public static class Staff {
        public String name, role;
        public boolean active;
        public Staff(String name, String role, boolean active) { this.name = name; this.role = role; this.active = active; }
    }

    public static class Sale {
        public int receipt;                 // assigned by addSale()
        public LocalDateTime time;
        public String cashier, register, items, method;   // method: Cash / Card / GCash
        public double total;
        public boolean refunded;
        public Sale(LocalDateTime time, String cashier, String register, String items, double total, String method) {
            this.time = time; this.cashier = cashier; this.register = register;
            this.items = items; this.total = total; this.method = method;
        }
    }

    // ---------- Files ----------
    private static final Object JVM_LOCK = new Object();   // FileLock can't be shared by two channels in one JVM

    private final Path dir;
    private final Path itemsFile, staffFile, salesFile, lockFile;

    public HigalaStore() {
        this(Paths.get(System.getProperty("higala.data", System.getProperty("user.home") + "/HigalaRidgeData")));
    }

    public HigalaStore(Path dir) {
        this.dir = dir;
        this.itemsFile = dir.resolve("inventory.csv");
        this.staffFile = dir.resolve("staff.csv");
        this.salesFile = dir.resolve("sales.csv");
        this.lockFile = dir.resolve(".lock");
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        locked(() -> {
            if (!Files.exists(itemsFile)) writeItems(defaultItems());
            if (!Files.exists(staffFile)) writeStaff(defaultStaff());
            if (!Files.exists(salesFile)) writeSales(new ArrayList<>());
            return null;
        });
    }

    public Path dir() { return dir; }

    /** Changes whenever any of the files is changed by either app (used to refresh the screens). */
    public long stamp() {
        return modified(itemsFile) * 31 * 31 + modified(staffFile) * 31 + modified(salesFile);
    }

    private static long modified(Path p) {
        try {
            return Files.getLastModifiedTime(p).toMillis();
        } catch (IOException e) {
            return 0;
        }
    }

    // ---------- Locking ----------
    private <T> T locked(Supplier<T> action) {
        synchronized (JVM_LOCK) {
            try (FileChannel ch = FileChannel.open(lockFile, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                 FileLock ignored = ch.lock()) {
                return action.get();
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }
    }

    // ---------- Items ----------
    public List<Item> loadItems() { return locked(this::readItems); }

    public void saveItems(List<Item> items) { locked(() -> { writeItems(items); return null; }); }

    /** Reads the CURRENT inventory, lets you change it, and saves it, all in one locked step. */
    public void updateItems(Consumer<List<Item>> change) {
        locked(() -> {
            List<Item> items = readItems();
            change.accept(items);
            writeItems(items);
            return null;
        });
    }

    /**
     * Takes the given quantities (item name -> qty) out of stock, all or nothing.
     * Returns null when done, or a message saying why it could not be done.
     */
    public String deductStock(Map<String, Integer> qtyByName) {
        return locked(() -> {
            List<Item> items = readItems();
            for (Map.Entry<String, Integer> en : qtyByName.entrySet()) {
                Item it = find(items, en.getKey());
                if (it == null) return "\"" + en.getKey() + "\" is no longer on the menu.";
                if (it.stock < en.getValue()) {
                    return it.stock <= 0 ? it.name + " is sold out."
                            : "Only " + it.stock + " " + it.name + " left (you ordered " + en.getValue() + ").";
                }
            }
            for (Map.Entry<String, Integer> en : qtyByName.entrySet()) find(items, en.getKey()).stock -= en.getValue();
            writeItems(items);
            return null;
        });
    }

    private static Item find(List<Item> items, String name) {
        for (Item it : items) if (it.name.equalsIgnoreCase(name)) return it;
        return null;
    }

    // ---------- Staff ----------
    public List<Staff> loadStaff() { return locked(this::readStaff); }

    public void saveStaff(List<Staff> staff) { locked(() -> { writeStaff(staff); return null; }); }

    /** Same as updateItems, for the staff list. */
    public void updateStaff(Consumer<List<Staff>> change) {
        locked(() -> {
            List<Staff> staff = readStaff();
            change.accept(staff);
            writeStaff(staff);
            return null;
        });
    }

    // ---------- Settings (saved between runs) ----------
    public Properties loadSettings() {
        return locked(() -> {
            Properties p = new Properties();
            Path f = dir.resolve("settings.properties");
            if (Files.exists(f)) {
                try (java.io.Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                    p.load(r);
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            }
            return p;
        });
    }

    public void saveSettings(Properties p) {
        locked(() -> {
            try (java.io.Writer w = Files.newBufferedWriter(dir.resolve("settings.properties"), StandardCharsets.UTF_8)) {
                p.store(w, "Higala Ridge settings");
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
            return null;
        });
    }

    // ---------- Sales ----------
    public List<Sale> loadSales() { return locked(this::readSales); }

    /** Saves the sale with the next receipt number and returns that number. */
    public int addSale(Sale sale) {
        return locked(() -> {
            List<Sale> all = readSales();
            int next = 1001;
            for (Sale s : all) next = Math.max(next, s.receipt + 1);
            sale.receipt = next;
            all.add(sale);
            writeSales(all);
            return next;
        });
    }

    /** Marks a receipt as refunded. Returns false if the receipt does not exist. */
    public boolean markRefunded(int receipt) {
        return locked(() -> {
            List<Sale> all = readSales();
            for (Sale s : all) {
                if (s.receipt == receipt) {
                    s.refunded = true;
                    writeSales(all);
                    return true;
                }
            }
            return false;
        });
    }

    public void clearSales() { locked(() -> { writeSales(new ArrayList<>()); return null; }); }

    // ---------- Reading / writing (call only while locked) ----------
    private List<Item> readItems() {
        List<Item> out = new ArrayList<>();
        for (List<String> f : readCsv(itemsFile)) {
            if (f.size() < 4) continue;
            try {
                out.add(new Item(f.get(0), f.get(1), Double.parseDouble(f.get(2)), Integer.parseInt(f.get(3))));
            } catch (NumberFormatException ignored) { }
        }
        return out;
    }

    private void writeItems(List<Item> items) {
        List<String> lines = new ArrayList<>();
        lines.add("category,name,price,stock");
        for (Item it : items) {
            lines.add(csv(it.category, it.name, String.format(Locale.ROOT, "%.2f", it.price), String.valueOf(it.stock)));
        }
        writeLines(itemsFile, lines);
    }

    private List<Staff> readStaff() {
        List<Staff> out = new ArrayList<>();
        for (List<String> f : readCsv(staffFile)) {
            if (f.size() < 3) continue;
            out.add(new Staff(f.get(0), f.get(1), Boolean.parseBoolean(f.get(2))));
        }
        return out;
    }

    private void writeStaff(List<Staff> staff) {
        List<String> lines = new ArrayList<>();
        lines.add("name,role,active");
        for (Staff s : staff) lines.add(csv(s.name, s.role, String.valueOf(s.active)));
        writeLines(staffFile, lines);
    }

    private List<Sale> readSales() {
        List<Sale> out = new ArrayList<>();
        for (List<String> f : readCsv(salesFile)) {
            if (f.size() < 8) continue;
            try {
                Sale s = new Sale(LocalDateTime.parse(f.get(1)), f.get(2), f.get(3), f.get(4),
                        Double.parseDouble(f.get(5)), f.get(6));
                s.receipt = Integer.parseInt(f.get(0));
                s.refunded = f.get(7).equals("REFUNDED");
                out.add(s);
            } catch (RuntimeException ignored) { }
        }
        return out;
    }

    private void writeSales(List<Sale> sales) {
        List<String> lines = new ArrayList<>();
        lines.add("receipt,time,cashier,register,items,total,method,status");
        for (Sale s : sales) {
            lines.add(csv(String.valueOf(s.receipt), s.time.withNano(0).toString(), s.cashier, s.register, s.items,
                    String.format(Locale.ROOT, "%.2f", s.total), s.method, s.refunded ? "REFUNDED" : "PAID"));
        }
        writeLines(salesFile, lines);
    }

    private static List<List<String>> readCsv(Path file) {
        List<List<String>> rows = new ArrayList<>();
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            for (int i = 1; i < lines.size(); i++) {          // line 0 is the header
                if (!lines.get(i).trim().isEmpty()) rows.add(parseLine(lines.get(i)));
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return rows;
    }

    private static void writeLines(Path file, List<String> lines) {
        try {
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.write(tmp, lines, StandardCharsets.UTF_8);
            Files.move(tmp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    // ---------- CSV helpers (every field is quoted, so commas and quotes in names are safe) ----------
    private static String csv(String... fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            if (i > 0) sb.append(',');
            sb.append('"').append(fields[i].replace("\"", "\"\"")).append('"');
        }
        return sb.toString();
    }

    private static List<String> parseLine(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') { cur.append('"'); i++; }
                    else quoted = false;
                } else {
                    cur.append(c);
                }
            } else if (c == '"') {
                quoted = true;
            } else if (c == ',') {
                out.add(cur.toString());
                cur.setLength(0);
            } else {
                cur.append(c);
            }
        }
        out.add(cur.toString());
        return out;
    }

// ---------- First-run defaults ----------
    private static List<Item> defaultItems() {
        List<Item> l = new ArrayList<>();
        l.add(new Item("SNACKS", "Fries", 50, 40));
        l.add(new Item("SNACKS", "Burger", 50, 25));
        l.add(new Item("SNACKS", "Siomai", 30, 18));
        l.add(new Item("SNACKS", "Nachos", 85, 12));
        l.add(new Item("SNACKS", "Nova", 18, 60));
        l.add(new Item("SNACKS", "Nagaraya", 12, 60));
        l.add(new Item("SNACKS", "Doritos", 15, 60));
        l.add(new Item("SNACKS", "Prawn Crackers", 12, 60));
        l.add(new Item("SNACKS", "Cheese Ring", 15, 60));
        l.add(new Item("SNACKS", "Cracklings", 12, 60));
        l.add(new Item("SNACKS", "Cheetos", 12, 60));
        l.add(new Item("SNACKS", "Crispy Patata", 12, 30));
        l.add(new Item("SNACKS", "Mang Juan", 20, 60));
        l.add(new Item("SNACKS", "Potato Fries", 12, 60));
        l.add(new Item("SNACKS", "Pillows", 8, 60));
        l.add(new Item("SNACKS", "Piattos", 15, 60));
        l.add(new Item("DESSERT", "Selecta 100mL", 35, 30));
        l.add(new Item("DESSERT", "Selecta 1.3mL", 250, 20));
        l.add(new Item("DESSERT", "Selecta 750mL", 150, 22));
        l.add(new Item("DESSERT", "Cornetto", 30, 25));
        l.add(new Item("DESSERT", "Cornetto disc", 32, 14));
        l.add(new Item("DESSERT", "Boom Boom", 24, 35));
        l.add(new Item("DESSERT", "Boom Boom Max", 26, 35));
        l.add(new Item("DESSERT", "Milkbar", 20, 35));
        l.add(new Item("DRINKS", "Coke Mismo", 30, 80));
        l.add(new Item("DRINKS", "Sprite Mismo", 30, 50));
        l.add(new Item("DRINKS", "Royal Mismo", 30, 100));
        l.add(new Item("DRINKS", "Mountain Dew", 30, 45));
        l.add(new Item("DRINKS", "Coke 1.5L", 80, 20));
        l.add(new Item("DRINKS", "Sprite 1.5L", 80, 30));
        l.add(new Item("DRINKS", "Nature Spring 500mL", 10, 30));
        l.add(new Item("DRINKS", "Sting", 30, 30));
        l.add(new Item("DRINKS", "Cobra", 30, 30));
        l.add(new Item("DRINKS", "Royal 1.5L", 80, 30));
        l.add(new Item("DRINKS", "Nature Spring 1L", 25, 30));
        l.add(new Item("DRINKS", "C2 Apple", 20, 30));
        l.add(new Item("DRINKS", "Minute Maid Orange", 15, 30));
        l.add(new Item("DRINKS", "Minute Maid Apple", 15, 30));
        return l;
    }

    private static List<Staff> defaultStaff() {
        List<Staff> l = new ArrayList<>();
        l.add(new Staff("Admin", "Admin", true));
        l.add(new Staff("Cashier 1", "Cashier", true));
        return l;
    }

    /** Groups items by category, in menu order (used by the cashier to draw its tabs). */
    public static Map<String, List<Item>> byCategory(List<Item> items) {
        Map<String, List<Item>> map = new LinkedHashMap<>();
        for (String c : CATEGORIES) map.put(c, new ArrayList<>());
        for (Item it : items) map.computeIfAbsent(it.category, k -> new ArrayList<>()).add(it);
        return map;
    }
}
