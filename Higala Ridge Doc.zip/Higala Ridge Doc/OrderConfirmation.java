
import java.awt.*;
import java.util.List;
import javax.swing.*;

public class OrderConfirmation extends JFrame {

    private final Color FOREST_CODE = new Color(7, 94, 70);
    private final Color MINT_FOG = new Color(232, 255, 242);

    public OrderConfirmation(
            String orderNumber,
            String customerName,
            String paymentMethod,
            double total,
            List<String> items,
            List<Double> prices) {

        setTitle("Higala Ridge - Order Confirmation");
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(MINT_FOG);
        mainPanel.setBorder(
            BorderFactory.createEmptyBorder(25, 30, 25, 30)
        );

        // HEADER
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(FOREST_CODE);
        header.setBorder(
            BorderFactory.createEmptyBorder(20, 10, 20, 10)
        );

        JLabel checkLabel = new JLabel("✓");
        checkLabel.setFont(new Font("Arial", Font.BOLD, 42));
        checkLabel.setForeground(Color.WHITE);
        checkLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel title = new JLabel("ORDER CONFIRMED!");
        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel thankYou = new JLabel("Thank you for ordering at Higala Ridge");
        thankYou.setFont(new Font("Arial", Font.PLAIN, 14));
        thankYou.setForeground(Color.WHITE);
        thankYou.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(checkLabel);
        header.add(Box.createVerticalStrut(5));
        header.add(title);
        header.add(Box.createVerticalStrut(8));
        header.add(thankYou);

        mainPanel.add(header, BorderLayout.NORTH);

        // ORDER DETAILS
        JPanel detailsPanel = new JPanel();
        detailsPanel.setLayout(
            new BoxLayout(detailsPanel, BoxLayout.Y_AXIS)
        );
        detailsPanel.setBackground(MINT_FOG);

        JLabel orderLabel = new JLabel("YOUR ORDER NUMBER");
        orderLabel.setFont(new Font("Arial", Font.BOLD, 15));
        orderLabel.setForeground(FOREST_CODE);
        orderLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel numberLabel = new JLabel(orderNumber);
        numberLabel.setFont(new Font("Arial", Font.BOLD, 32));
        numberLabel.setForeground(FOREST_CODE);
        numberLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        detailsPanel.add(orderLabel);
        detailsPanel.add(Box.createVerticalStrut(5));
        detailsPanel.add(numberLabel);
        detailsPanel.add(Box.createVerticalStrut(20));

        JLabel summaryTitle = new JLabel("ORDER SUMMARY");
        summaryTitle.setFont(new Font("Arial", Font.BOLD, 18));
        summaryTitle.setForeground(FOREST_CODE);
        summaryTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        detailsPanel.add(summaryTitle);
        detailsPanel.add(Box.createVerticalStrut(10));

        JPanel itemsPanel = new JPanel();
        itemsPanel.setLayout(
            new BoxLayout(itemsPanel, BoxLayout.Y_AXIS)
        );
        itemsPanel.setBackground(Color.WHITE);
        itemsPanel.setBorder(
            BorderFactory.createEmptyBorder(12, 15, 12, 15)
        );

        for (int i = 0; i < items.size(); i++) {

            JPanel itemRow = new JPanel(new BorderLayout(10, 5));
            itemRow.setBackground(Color.WHITE);

            JLabel itemLabel = new JLabel(items.get(i));
            itemLabel.setFont(new Font("Arial", Font.PLAIN, 14));

            JLabel priceLabel = new JLabel(
                "₱" + String.format("%.2f", prices.get(i))
            );
            priceLabel.setFont(new Font("Arial", Font.BOLD, 14));

            itemRow.add(itemLabel, BorderLayout.CENTER);
            itemRow.add(priceLabel, BorderLayout.EAST);

            itemsPanel.add(itemRow);
            itemsPanel.add(Box.createVerticalStrut(8));
        }

        JScrollPane scrollPane = new JScrollPane(itemsPanel);

        scrollPane.setPreferredSize(new Dimension(450, 150));
        scrollPane.setMaximumSize(new Dimension(450, 150));
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Allow vertical scrolling only
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        // Keep the clean border
        scrollPane.setBorder(BorderFactory.createLineBorder(FOREST_CODE));

        detailsPanel.add(scrollPane);
        detailsPanel.add(Box.createVerticalStrut(15));

        JLabel customerLabel = new JLabel("Customer: " + customerName);
        customerLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel paymentLabel = new JLabel("Payment Method: " + paymentMethod);
        paymentLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel totalLabel = new JLabel(
            "TOTAL AMOUNT: ₱" + String.format("%.2f", total)
        );
        totalLabel.setFont(new Font("Arial", Font.BOLD, 22));
        totalLabel.setForeground(FOREST_CODE);

        JLabel statusLabel = new JLabel("Order Status: PENDING");
        statusLabel.setFont(new Font("Arial", Font.BOLD, 16));
        statusLabel.setForeground(FOREST_CODE);

        customerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        paymentLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        totalLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        detailsPanel.add(customerLabel);
        detailsPanel.add(Box.createVerticalStrut(7));
        detailsPanel.add(paymentLabel);
        detailsPanel.add(Box.createVerticalStrut(15));
        detailsPanel.add(totalLabel);
        detailsPanel.add(Box.createVerticalStrut(12));
        detailsPanel.add(statusLabel);

        mainPanel.add(detailsPanel, BorderLayout.CENTER);

        // DONE BUTTON
        JButton doneButton = new JButton("DONE - RETURN TO HOME");
        doneButton.setFont(new Font("Arial", Font.BOLD, 16));
        doneButton.setBackground(FOREST_CODE);
        doneButton.setForeground(MINT_FOG);
        doneButton.setFocusPainted(false);
        doneButton.setPreferredSize(new Dimension(300, 45));

        doneButton.addActionListener(e -> dispose());

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(MINT_FOG);
        bottomPanel.add(doneButton);

        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
        setVisible(true);
    }
}
