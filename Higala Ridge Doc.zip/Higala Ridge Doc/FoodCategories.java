import java.awt.*;
import javax.swing.*;

public class FoodCategories extends JFrame {

    private final Color FOREST_CODE = new Color(7, 94, 70);
    private final Color MINT_FOG = new Color(232, 255, 242);
    private final Color SEGE_GREEN = new Color(4, 145, 106);

    public FoodCategories() {
        setTitle("Food Categories");
        setSize(600, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(MINT_FOG);


        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(FOREST_CODE);
        headerPanel.setPreferredSize(new Dimension(900, 80));


        // ==========================================
        // HIGALA RIDGE LOGO
        // ==========================================

        ImageIcon logoIcon = new ImageIcon("C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Higala Ridge Logo.png");
        Image logoImage = logoIcon.getImage();
        Image logoResized = logoImage.getScaledInstance(60, 60, Image.SCALE_SMOOTH);

        ImageIcon newLogoIcon = new ImageIcon(logoResized);

        JLabel logoLabel = new JLabel(newLogoIcon);

        logoLabel.setBorder(
            BorderFactory.createEmptyBorder(
                5, 15, 5, 5
            )
        );

        headerPanel.add(
            logoLabel,
            BorderLayout.WEST
        );


        // ==========================================
        // HIGALA RIDGE TITLE
        // ==========================================

        JLabel headerTitle = new JLabel("HIGALA RIDGE");

        headerTitle.setFont(
            new Font("Arial", Font.BOLD, 28)
        );

        headerTitle.setForeground(MINT_FOG);

        headerTitle.setHorizontalAlignment(
            JLabel.CENTER
        );

        headerPanel.add(
            headerTitle,
            BorderLayout.CENTER
        );


        // Add header to main panel
        mainPanel.add(
            headerPanel,
            BorderLayout.NORTH
        );


        // ==========================================
        // BODY PANEL
        // ==========================================

        JPanel bodyPanel = new JPanel(new BorderLayout());
        bodyPanel.setBackground(MINT_FOG);

        JPanel navigationPanel = new JPanel();
        navigationPanel.setBackground(SEGE_GREEN);
        navigationPanel.setLayout(new BoxLayout(navigationPanel, BoxLayout.Y_AXIS));
        navigationPanel.setBorder(BorderFactory.createEmptyBorder(25, 15, 25, 15));
        navigationPanel.setPreferredSize(new Dimension(170, 0));


        // ==========================================
        // FOOD CATEGORIES TITLE
        // ==========================================

        JLabel categoryTitle = new JLabel("CATEGORIES");
        categoryTitle.setFont(new Font("Arial", Font.BOLD, 13));
        categoryTitle.setForeground(MINT_FOG);
        categoryTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        navigationPanel.add(categoryTitle);
        navigationPanel.add(Box.createVerticalStrut(30));

        // ==========================================
        // CATEGORY BUTTONS
        // ==========================================

        JButton snacksButton = new JButton("SNACKS");
        JButton dessertsButton = new JButton("DESSERTS");
        JButton drinksButton = new JButton("DRINKS");

        // ==========================================
        // BUTTON SIZE
        // ==========================================

        Dimension navButtonSize = new Dimension(135, 40);

        snacksButton.setMaximumSize(navButtonSize);
        dessertsButton.setMaximumSize(navButtonSize);
        drinksButton.setMaximumSize(navButtonSize);


        // ==========================================
        // BUTTON ALIGNMENT
        // ==========================================

        snacksButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        dessertsButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        drinksButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        // ==========================================
        // BUTTON DESIGN
        // ==========================================

        snacksButton.setFont(new Font("Arial", Font.BOLD, 14));
        dessertsButton.setFont(new Font("Arial", Font.BOLD, 14));
        drinksButton.setFont(new Font("Arial", Font.BOLD, 14));

        snacksButton.setBackground(MINT_FOG);
        dessertsButton.setBackground(MINT_FOG);
        drinksButton.setBackground(MINT_FOG);

        snacksButton.setForeground(FOREST_CODE);
        dessertsButton.setForeground(FOREST_CODE);
        drinksButton.setForeground(FOREST_CODE);

        snacksButton.setFocusPainted(false);
        dessertsButton.setFocusPainted(false);
        drinksButton.setFocusPainted(false);

        // ==========================================
        // ADD BUTTONS TO NAVIGATION
        // ==========================================

        navigationPanel.add(snacksButton);
        navigationPanel.add(Box.createVerticalStrut(15));
        navigationPanel.add(dessertsButton);
        navigationPanel.add(Box.createVerticalStrut(15));
        navigationPanel.add(drinksButton);
        navigationPanel.add(Box.createVerticalGlue());

        // ==========================================
        // BOTTOM DECORATION
        // ==========================================

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
        bottomPanel.setBackground(SEGE_GREEN);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(15, 5, 10, 5));

        JLabel leafLabel = new JLabel("❧");
        leafLabel.setFont(new Font("Serif", Font.PLAIN, 55));
        leafLabel.setForeground(MINT_FOG);
        leafLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel messageLabel = new JLabel("Fresh & Delicious");
        messageLabel.setFont(new Font("Arial", Font.BOLD, 12));
        messageLabel.setForeground(MINT_FOG);
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel brandLabel = new JLabel("HIGALA RIDGE");
        brandLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        brandLabel.setForeground(MINT_FOG);
        brandLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        bottomPanel.add(leafLabel);
        bottomPanel.add(Box.createVerticalStrut(5));
        bottomPanel.add(messageLabel);
        bottomPanel.add(Box.createVerticalStrut(5));
        bottomPanel.add(brandLabel);

        navigationPanel.add(bottomPanel);

        // ==========================================
        // CONTENT PANEL
        // ==========================================

        JPanel contentPanel = new JPanel(
            new BorderLayout()
        );

        contentPanel.setBackground(
            MINT_FOG
        );

        contentPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));


        // ==========================================
        // DEFAULT CONTENT
        // ==========================================

        // ==========================================
        // ADD NAVIGATION + CONTENT
        // ==========================================

        bodyPanel.add(navigationPanel, BorderLayout.WEST);
        bodyPanel.add(contentPanel, BorderLayout.CENTER);

        // Add body to main panel
        mainPanel.add(
            bodyPanel,
            BorderLayout.CENTER
        );


        // ==========================================
        // SNACKS BUTTON ACTION
        // ==========================================

        snacksButton.addActionListener(e -> {
            contentPanel.removeAll();

            Snacks snacksPanel = new Snacks();

            contentPanel.add(snacksPanel, BorderLayout.CENTER);
            contentPanel.revalidate();
            contentPanel.repaint();
        });


        // ==========================================
        // DESSERTS BUTTON ACTION
        // ==========================================

        dessertsButton.addActionListener(e -> {
            contentPanel.removeAll();

            Desserts dessertsPanel = new Desserts();

            contentPanel.add(dessertsPanel, BorderLayout.CENTER);
            contentPanel.revalidate();
            contentPanel.repaint();
        });


        // ==========================================
        // DRINKS BUTTON ACTION
        // ==========================================

        drinksButton.addActionListener(e -> {
            contentPanel.removeAll();

            Drinks drinksPanel = new Drinks();

            contentPanel.add(drinksPanel, BorderLayout.CENTER);
            contentPanel.revalidate();
            contentPanel.repaint();
        });

        // ==========================================
        // ADD MAIN PANEL TO WINDOW
        // ==========================================

        add(mainPanel);


        // ==========================================
        // SHOW WINDOW
        // ==========================================

        setVisible(true);
    }


    // ==========================================
    // MAIN METHOD
    // ==========================================

    public static void main(String[] args) {
        new FoodCategories();
    }
}