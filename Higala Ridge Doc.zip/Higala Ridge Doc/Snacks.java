
import java.awt.*;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

public class Snacks extends JPanel {

    private final Color FOREST_CODE = new Color(7, 94, 70);
    private final Color MINT_FOG = new Color(232, 255, 242);
    private final Color SOFT_CREAM = new Color(245, 245, 220);

    private JPanel productPanel;

    // Keep your existing local image files
    private final Map<Integer, String> productImages = new HashMap<>();

    public Snacks() {

        setLayout(new BorderLayout());
        setBackground(MINT_FOG);

        // PRODUCT IMAGES
        productImages.put(1,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\fries.png");

        productImages.put(2,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Nachos.png");

        productImages.put(3,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Siomai.png");

        productImages.put(4,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\burger.png");

        productImages.put(5,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Nova.png");

        productImages.put(6,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Nagaraya.png");

        productImages.put(7,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Doritos.png");

        productImages.put(8,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Prawn Crackers.png");

        productImages.put(9,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Cheese Ring.png");

        productImages.put(10,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Cracklings.png");

        productImages.put(11,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Cheetos.png");

        productImages.put(12,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Crispy Patata.png");

        productImages.put(13,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Mang Juan.png");

        productImages.put(14,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Potato Fries.png");

        productImages.put(15,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Pillows.png");

        productImages.put(16,
                "C:\\Users\\ginal\\OneDrive\\Desktop\\Higala Ridge Doc\\Pictures\\Piattos.png");

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(MINT_FOG);

        JLabel title = new JLabel("SNACKS");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(FOREST_CODE);
        title.setHorizontalAlignment(SwingConstants.CENTER);

        JButton cartButton = new JButton("CART");
        cartButton.setFont(new Font("Arial", Font.BOLD, 15));
        cartButton.setBackground(FOREST_CODE);
        cartButton.setForeground(Color.WHITE);
        cartButton.setFocusPainted(false);
        cartButton.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        cartButton.addActionListener(e -> new Cart());

        header.add(title, BorderLayout.CENTER);
        header.add(cartButton, BorderLayout.EAST);

        // PRODUCT PANEL
        productPanel = new JPanel(new GridLayout(0, 3, 15, 20));
        productPanel.setBackground(MINT_FOG);

        JScrollPane scrollPane = new JScrollPane(productPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        JPanel insidePanel = new JPanel(new BorderLayout(0, 15));
        insidePanel.setBackground(MINT_FOG);
        insidePanel.setBorder(
                BorderFactory.createEmptyBorder(20, 25, 20, 25)
        );

        insidePanel.add(header, BorderLayout.NORTH);
        insidePanel.add(scrollPane, BorderLayout.CENTER);

        add(insidePanel, BorderLayout.CENTER);

        // LOAD PRODUCTS FROM DATABASE
        loadProducts();
    }

    // =====================================================
    // LOAD PRODUCTS FROM MYSQL
    // =====================================================

    private void loadProducts() {

        productPanel.removeAll();

        String sql =
                "SELECT product_id, product_name, price, image_path " +
                "FROM products " +
                "WHERE category_id = ? " +
                "AND is_available = 1 " +
                "AND stock_quantity > 0 " +
                "ORDER BY product_id";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, 1); // Snacks category

            try (ResultSet rs = ps.executeQuery()) {

                boolean found = false;

                while (rs.next()) {

                    found = true;

                    int productId = rs.getInt("product_id");
                    String productName = rs.getString("product_name");
                    double productPrice = rs.getDouble("price");
                    String imagePath = rs.getString("image_path");

                    addProductCard(productId, productName, productPrice, imagePath);
                }

                if (!found) {
                    JLabel emptyLabel = new JLabel(
                            "No snacks are currently available.",
                            SwingConstants.CENTER
                    );

                    emptyLabel.setFont(
                            new Font("Arial", Font.PLAIN, 16)
                    );

                    productPanel.setLayout(new BorderLayout());
                    productPanel.add(emptyLabel, BorderLayout.CENTER);
                }
            }

        } catch (SQLException ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to load snacks from the database.\n"
                            + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        productPanel.revalidate();
        productPanel.repaint();
    }

    // =====================================================
    // PRODUCT CARD
    // =====================================================

    private void addProductCard(
            int productId,
            String productName,
            double productPrice,
            String imagePath) {

        JPanel productCard = new JPanel();

        productCard.setLayout(
                new BoxLayout(productCard, BoxLayout.Y_AXIS)
        );

        productCard.setBackground(SOFT_CREAM);

        productCard.setBorder(
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        );

        // IMAGE
        
        // IMAGE
        JLabel imageLabel = new JLabel();
        imageLabel.setPreferredSize(new Dimension(70, 70));
        imageLabel.setMinimumSize(new Dimension(70, 70));
        imageLabel.setMaximumSize(new Dimension(70, 70));
        imageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        if (imagePath != null && !imagePath.trim().isEmpty()) {

            ImageIcon icon = new ImageIcon(imagePath);

            if (icon.getIconWidth() > 0) {

                Image resized = icon.getImage().getScaledInstance(
                        70, 70, Image.SCALE_SMOOTH
                );

                imageLabel.setIcon(new ImageIcon(resized));

            } else {
                System.out.println(
                        "Image not found: " + imagePath
                );
            }
        }


        // NAME
        JLabel nameLabel = new JLabel(productName);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 12));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // PRICE
        JLabel priceLabel = new JLabel(
                String.format("₱%.2f", productPrice)
        );

        priceLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // ADD TO CART
        JButton addButton = new JButton("Add to Cart");

        addButton.setBackground(FOREST_CODE);
        addButton.setForeground(Color.WHITE);
        addButton.setFont(new Font("Arial", Font.BOLD, 11));
        addButton.setFocusPainted(false);
        addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        addButton.setCursor(
                Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
        );

        final String selectedName = productName;
        final double selectedPrice = productPrice;

        addButton.addActionListener(e -> {

            // Verify current stock and price before adding
            addProductToCart(
                    productId,
                    selectedName,
                    selectedPrice
            );
        });

        productCard.add(imageLabel);
        productCard.add(Box.createVerticalStrut(5));
        productCard.add(nameLabel);
        productCard.add(Box.createVerticalStrut(2));
        productCard.add(priceLabel);
        productCard.add(Box.createVerticalStrut(6));
        productCard.add(addButton);

        productPanel.add(productCard);
    }

    // =====================================================
    // CHECK CURRENT PRICE AND STOCK BEFORE ADDING
    // =====================================================

    private void addProductToCart(
            int productId,
            String productName,
            double displayedPrice) {

        String sql =
                "SELECT product_name, price, stock_quantity, is_available " +
                "FROM products WHERE product_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, productId);

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()
                        || rs.getInt("is_available") != 1
                        || rs.getInt("stock_quantity") <= 0) {

                    JOptionPane.showMessageDialog(
                            this,
                            "This product is no longer available."
                    );

                    loadProducts();
                    return;
                }

                // Use the latest database values
                String currentName = rs.getString("product_name");
                double currentPrice = rs.getDouble("price");

                if (!currentName.equals(productName)
                        || Double.compare(
                                currentPrice, displayedPrice) != 0) {

                    JOptionPane.showMessageDialog(
                            this,
                            "This product has been updated.\n"
                                    + "Please review the latest name and price."
                    );

                    loadProducts();
                    return;
                }

                showProductOptions(currentName, currentPrice);
            }

        } catch (SQLException ex) {

            ex.printStackTrace();

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to verify the product.\n"
                            + ex.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =====================================================
    // PRODUCT OPTIONS
    // =====================================================

    private void showProductOptions(
            String productName,
            double price) {

        JPanel panel = new JPanel();

        panel.setLayout(
                new BoxLayout(panel, BoxLayout.Y_AXIS)
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        );

        JLabel productLabel = new JLabel(productName);
        productLabel.setFont(new Font("Arial", Font.BOLD, 20));
        productLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(productLabel);
        panel.add(Box.createVerticalStrut(15));

        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JSpinner quantitySpinner = new JSpinner(
                new SpinnerNumberModel(1, 1, 99, 1)
        );

        quantitySpinner.setMaximumSize(new Dimension(100, 30));
        quantitySpinner.setAlignmentX(Component.CENTER_ALIGNMENT);

        panel.add(quantityLabel);
        panel.add(Box.createVerticalStrut(5));
        panel.add(quantitySpinner);

        JComboBox<String> flavorBox = null;

        if (productName.equalsIgnoreCase("French Fries")) {

            panel.add(Box.createVerticalStrut(15));

            JLabel flavorLabel = new JLabel("Flavor:");
            flavorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            flavorBox = new JComboBox<>(
                    new String[]{
                        "Cheese",
                        "Barbecue",
                        "Sour Cream",
                        "Original"
                    }
            );

            flavorBox.setMaximumSize(new Dimension(180, 30));
            flavorBox.setAlignmentX(Component.CENTER_ALIGNMENT);

            panel.add(flavorLabel);
            panel.add(Box.createVerticalStrut(5));
            panel.add(flavorBox);
        }

        int result = JOptionPane.showConfirmDialog(
                this,
                panel,
                "Add to Cart",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {

            int quantity = (Integer) quantitySpinner.getValue();

            String flavor = "";

            if (flavorBox != null) {
                flavor = flavorBox.getSelectedItem().toString();
            }

            CartManager.addItem(
                    productName,
                    price,
                    quantity,
                    flavor
            );

            JOptionPane.showMessageDialog(
                    this,
                    quantity + " x " + productName
                            + (flavor.isEmpty()
                            ? ""
                            : "\nFlavor: " + flavor)
                            + "\n\nAdded to cart!",
                    "Cart",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }
}
